# SPENTA — Run this locally

This is a ready-to-run project. In the Claude preview, some things are
sandboxed (external images, live currency/crypto data) — running it for
real, on your own machine or a real host, fixes all of that.

## Option 1 — Run on your own computer (fastest way to see everything work)

You need [Node.js](https://nodejs.org) installed (any recent version, 18+).

```bash
cd spenta-app
npm install
npm run dev
```

Then open the URL it prints (usually `http://localhost:5173`) in your
browser. Images, exchange rates, and crypto/gold prices will all load
normally because it's now running as a real website, not a sandboxed
preview.

## Option 2 — Put it online for free (to actually share a link)

The easiest free options, both deploy straight from GitHub:

1. Push this folder to a new GitHub repository.
2. Go to [vercel.com](https://vercel.com) or [netlify.com](https://netlify.com),
   sign in with GitHub, and "Import" that repository.
3. Framework preset: **Vite**. Leave build settings on default
   (`npm run build`, output folder `dist`). Click Deploy.
4. You'll get a real `https://...` link in a couple of minutes.

## What's real vs. simulated in this build

- **Real, live:** currency exchange rates, gold price, cryptocurrency
  prices (fetched from public APIs), all placeholder photos (picsum.photos).
- **Simulated / demo:** user accounts and login (stored only in this
  browser, not a real server), phone/ID verification, admin approval queue,
  the shared listings feed (starts from the built-in seed data). See
  `SPENTA-feature-overview.md` for the full breakdown of what a real
  backend would need to replace before a public launch.

## Project structure

```
spenta-app/
  src/
    App.jsx       ← the entire site (all pages, all components)
    main.jsx      ← app entry point + storage polyfill
    index.css     ← Tailwind setup
  index.html
  package.json
  vite.config.js
  tailwind.config.js
```
