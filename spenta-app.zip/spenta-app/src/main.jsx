import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "./index.css";

// -----------------------------------------------------------------------
// window.storage polyfill
// -----------------------------------------------------------------------
// The SPENTA component was originally built for the Claude Artifacts
// runtime, which injects a `window.storage` key-value API (used for the
// listings feed, wishlist, saved searches, credentials, etc). That API
// doesn't exist in a normal browser, so outside of Claude this shim
// re-implements the same interface on top of localStorage, matching the
// original semantics exactly:
//   - get(key, shared) resolves {key, value, shared} or THROWS if the key
//     doesn't exist (the app relies on this to detect "first run" state)
//   - set / delete / list behave the same way, just backed by localStorage
//     instead of Claude's server-side store.
//
// "shared" (cross-user) storage has no real equivalent outside Claude, so
// it's simply stored under its own key prefix on this device/browser only.
// If you want real multi-user shared data (e.g. one global listings feed
// everyone sees), replace this shim with calls to your own backend/API.
if (typeof window !== "undefined" && !window.storage) {
  const PREFIX = "spenta:";
  const fullKey = (key, shared) => `${PREFIX}${shared ? "shared:" : "private:"}${key}`;

  window.storage = {
    async get(key, shared = false) {
      const raw = localStorage.getItem(fullKey(key, shared));
      if (raw === null) throw new Error(`storage key not found: ${key}`);
      return { key, value: raw, shared };
    },
    async set(key, value, shared = false) {
      localStorage.setItem(fullKey(key, shared), value);
      return { key, value, shared };
    },
    async delete(key, shared = false) {
      localStorage.removeItem(fullKey(key, shared));
      return { key, deleted: true, shared };
    },
    async list(prefix = "", shared = false) {
      const base = fullKey("", shared);
      const keys = Object.keys(localStorage)
        .filter((k) => k.startsWith(base))
        .map((k) => k.slice(base.length))
        .filter((k) => k.startsWith(prefix));
      return { keys, prefix, shared };
    },
  };
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
