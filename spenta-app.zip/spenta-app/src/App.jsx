import React, { useState, useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import {
  Search, MapPin, Home as HomeIcon, Car, Bike, Briefcase, Package, Wrench,
  User, Plus, X, ChevronLeft, ChevronRight, Check, CreditCard, MessageCircle,
  Star, Clock, ShieldCheck, LogOut, SlidersHorizontal, Building2,
  Percent, Sparkles, Camera, Eye, Globe2, Zap, Loader2, ArrowLeft, ArrowUp,
  LifeBuoy, Phone, Send, ChevronDown, Mail, Scale, ExternalLink, Radio, Users, Heart, SlidersHorizontal as SlidersIcon, BadgeCheck, Info, Coins, Mic, Bell, Navigation, Sun, Moon, DollarSign, Image as ImageIcon, Share2, Flag, QrCode, BookOpen, ArrowRight, Copy, Pencil, Trash2, RefreshCw, Download, Cookie
} from "lucide-react";

/* ------------------------------------------------------------------ */
/*  Tokens                                                              */
/* ------------------------------------------------------------------ */

const FONT_IMPORT = `@import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800;900&family=Playfair+Display:wght@600;700;800;900&family=JetBrains+Mono:wght@400;500;700;800&display=swap');`;

/* Editorial / corporate palette — warm ivory page, white cards, muted gold accent */
const LIME = "#8A5C1E";         /* primary accent — antique gold (was neon lime) */
const CYAN = "#0E6B66";         /* secondary accent — deep teal (was neon cyan) */
const GOLD = "#E5B94E";         /* bright gold, reserved for the dark editorial section */
const INK = "#14181F";          /* ink navy — primary text & text-on-accent */
const PAGE_BG = "#F7F4EC";      /* warm ivory page background */
const SURFACE = "#EFEADC";      /* light warm gray — inputs / secondary chrome */
const CARD = "#FFFFFF";         /* elevated card background */
const SURFACE2 = "#EAE4D4";     /* hover / bubble background */
const BORDER = "#E1DBC8";       /* visible warm border */
const BORDER_SOFT = "rgba(20,24,31,.09)";
const CARD_SHADOW = "0 10px 28px -14px rgba(20,24,31,.14)";
const MUTED = "#585C66";
const PAPER = "#FFFFFF";
const SERIF = "'Playfair Display', Georgia, serif";

const CATS = {
  realestate:   { label: "Real Estate",         desc: "Buy, sell, and rent property worldwide", icon: Building2, color: "#A855F7", model: "commission", rate: "1.5% fee per deal" },
  vehicles:     { label: "Vehicles",          desc: "New and used vehicles, all brands",     icon: Car,       color: "#06B6D4", model: "commission", rate: "1% fee per deal" },
  motorcycles:  { label: "Motorcycles",     desc: "Motorcycles and two-wheeled vehicles",        icon: Bike,      color: "#F97316", model: "commission", rate: "1% fee per deal" },
  jobs:         { label: "Job opportunity",      desc: "On-site and remote job opportunities",           icon: Briefcase, color: "#22C55E", model: "fixed" },
  goods:        { label: "Goods & Tools",   desc: "New and secondhand goods, tools and supplies",      icon: Package,   color: "#F43F5E", model: "fixed" },
  services:     { label: "Services",          desc: "Specialized professional services",                  icon: Wrench,    color: "#EAB308", model: "fixed" },
};
const CAT_LIST = Object.entries(CATS).map(([id, v]) => ({ id, ...v }));
const catOf = (id) => ({ id, ...CATS[id] });

// Demo-only allowlist: hides the admin panel entry from ordinary visitors.
// This is NOT real access control (there is no backend/auth here) — anyone
// who knows this email can still type it in at signup. Before a real launch,
// admin approval must be moved behind real server-side authentication.
const ADMIN_EMAILS = ["admin@spenta.com"];
const isAdminUser = (user) => !!user && ADMIN_EMAILS.includes((user.email || "").trim().toLowerCase());

// New user-submitted ads auto-expire after this many days unless renewed.
// Seed/demo listings (no expiresAt field) are unaffected.
const AD_EXPIRY_DAYS = 30;
const AD_EXPIRY_MS = AD_EXPIRY_DAYS * 86400000;
const isExpired = (ad) => !!ad.expiresAt && Date.now() > ad.expiresAt;

// Full navigation taxonomy (groups + subcategories). Each subcategory maps to
// an existing listing category id so navigation works today; more granular
// data can be layered in later as each sub-market grows.
const NAV_GROUPS = [
  { emoji: "🏠", label: "Real Estate", color: "#A855F7", subs: [
      { label: "Buy a home", cat: "realestate" }, { label: "Sell a home", cat: "realestate" }, { label: "Rent", cat: "realestate" },
      { label: "Deposit", cat: "realestate" }, { label: "Land", cat: "realestate" }, { label: "Shop", cat: "realestate" },
      { label: "Office", cat: "realestate" }, { label: "Villa", cat: "realestate" },
  ] },
  { emoji: "🚗", label: "Vehicles", color: "#06B6D4", subs: [
      { label: "Vehicles", cat: "vehicles" }, { label: "Motorcycles", cat: "motorcycles" }, { label: "Heavy Vehicles", cat: "vehicles" },
      { label: "Parts", cat: "vehicles" }, { label: "Accessories", cat: "vehicles" },
  ] },
  { emoji: "💼", label: "Jobs & Hiring", color: "#22C55E", subs: [
      { label: "Hiring", cat: "jobs" }, { label: "Part-time work", cat: "jobs" }, { label: "Remote Work", cat: "jobs" },
      { label: "Project-based", cat: "jobs" }, { label: "Specialized services", cat: "services" },
  ] },
  { emoji: "📱", label: "Digital", color: "#3B82F6", subs: [
      { label: "Mobile Phones", cat: "goods" }, { label: "Laptops", cat: "goods" }, { label: "Computers", cat: "goods" },
      { label: "Console", cat: "goods" }, { label: "Accessories", cat: "goods" },
  ] },
  { emoji: "🛠", label: "Goods & Tools", color: "#F43F5E", subs: [
      { label: "Tools", cat: "goods" }, { label: "Home goods", cat: "goods" }, { label: "Industrial supplies", cat: "goods" },
      { label: "Sports equipment", cat: "goods" }, { label: "Clothing", cat: "goods" },
  ] },
  { emoji: "🧑‍🔧", label: "Services", color: "#EAB308", subs: [
      { label: "Repairs", cat: "services" }, { label: "Education", cat: "services" }, { label: "Design", cat: "services" },
      { label: "Programming", cat: "services" }, { label: "Transport", cat: "services" }, { label: "Cleaning", cat: "services" },
      { label: "Technical services", cat: "services" },
  ] },
];

/* ------------------------------------------------------------------ */
/*  Multi-language                                                     */
/* ------------------------------------------------------------------ */

const LANGS = [
  { code: "fa", label: "Persian", flag: "🇮🇷" },
  { code: "en", label: "English", flag: "🇬🇧" },
  { code: "de", label: "Deutsch", flag: "🇩🇪" },
  { code: "fr", label: "Français", flag: "🇫🇷" },
  { code: "es", label: "Español", flag: "🇪🇸" },
  { code: "tr", label: "Türkçe", flag: "🇹🇷" },
];

const CAT_I18N = {
  realestate: { en: "Real Estate", de: "Immobilien", fr: "Immobilier", es: "Inmuebles", tr: "Emlak" },
  vehicles: { en: "Vehicles", de: "Fahrzeuge", fr: "Véhicules", es: "Vehículos", tr: "Araçlar" },
  motorcycles: { en: "Motorcycles", de: "Motorräder", fr: "Motos", es: "Motos", tr: "Motosikletler" },
  jobs: { en: "Jobs", de: "Jobs", fr: "Emplois", es: "Empleos", tr: "İş İlanları" },
  goods: { en: "Goods & Tools", de: "Waren & Werkzeuge", fr: "Biens & Outils", es: "Bienes y Herramientas", tr: "Eşya ve Aletler" },
  services: { en: "Services", de: "Dienstleistungen", fr: "Services", es: "Servicios", tr: "Hizmetler" },
};

const I18N = {
  fa: {
    searchPlaceholder: "جستجو در SPENTA...", searchPlaceholderHero: "مثلا «BMW 2022 under $30k near Berlin»",
    postAd: "ثبت آگهی رایگان", login: "ورود", wishlist: "علاقه‌مندی‌ها", savedSearches: "جستجوهای ذخیره‌شده",
    categoriesEyebrow: "۰۱ — دسته‌بندی‌ها", categoriesTitle: "از کجا شروع کنیم؟",
    featuredEyebrow: "۰۲ — پیشنهاد SPENTA", featuredTitle: "آگهی‌های ویژه و تاییدشده",
    recentEyebrow: "۰۳ — تازه‌ترین", recentTitle: "جدیدترین آگهی‌ها",
    heroBadge: "بازار جهانی، بدون مرز", heroTitle: "", heroSub: "خانه، خودرو، موتور، فرصت شغلی، کالا و خدمات — همه در یک ویترین جهانی. آگهی بگذار، پیام بگیر، معامله کن.",
    searchBtn: "جستجو", statAds: "آگهی فعال", statCities: "شهر فعال", statUsers: "کاربر SPENTA",
    howEyebrow: "روند کار", howTitle: "SPENTA چطور کار می‌کنه؟",
    step1Title: "ثبت‌نام راحت", step1Desc: "در کمتر از یک دقیقه عضو SPENTA شو — بدون پیچیدگی، بدون مدرک اضافه.",
    step2Title: "آگهی سریع", step2Desc: "دسته رو انتخاب کن، جزئیات بنویس، همون لحظه رو ویترین جهانی منتشر شو.",
    step3Title: "معامله امن، کارمزد پایین", step3Desc: "فقط وقتی معامله واقعاً نهایی شد، یه کارمزد به‌صرفه کسر می‌شه — نه قبلش.",
    footerTagline: "ویترین جهانی برای هر چیز", footerVersion: "© تمامی حقوق محفوظ است",
    drawerAds: "آگهی‌ها", drawerOtherMarkets: "بازارهای دیگر", drawerComingSoon: "به‌زودی",
    drawerAbout: "درباره ما", drawerCareers: "همکاری با ما", drawerContact: "ارتباط با ما",
    drawerAccount: "مشاهده حساب کاربری", accountTitle: "حساب کاربری", drawerLoginSignup: "ورود یا ثبت‌نام", drawerLocation: "موقعیت مکانی", drawerLanguage: "زبان",
    viewDetails: "مشاهده جزئیات", negotiable: "توافقی",
    postAdTitle: "آگهی‌ت رو ثبت کن", postAdSubtitle: "ثبت آگهی کاملاً رایگانه. هر آگهی قبل از انتشار توسط تیم SPENTA بررسی می‌شه.",
    stepCategory: "دسته‌بندی", stepDetails: "جزئیات", stepReview: "ارسال برای بررسی",
    choosePrompt: "آگهی‌ت مربوط به کدوم دسته‌ست؟", continueBtn: "ادامه", backBtn: "بازگشت",
    titleLabel: "عنوان آگهی", descLabel: "توضیحات", priceLabel: "قیمت ($)", cityLabel: "شهر",
    submitReviewBtn: "ارسال برای بررسی", submittingBtn: "در حال ارسال...",
    doneTitle: "آگهی‌ت ثبت شد!", doneDesc: "آگهی‌ت الان تو صف بررسیه؛ بعد از تایید تیم SPENTA رو ویترین منتشر می‌شه.", viewStatusBtn: "مشاهده وضعیت آگهی",
    loginTab: "ورود", signupTab: "ثبت‌نام", fullNameLabel: "نام و نام‌خانوادگی", emailLabel: "ایمیل",
    phoneLabel: "شماره تماس", passwordLabel: "رمز عبور", loginSubmitBtn: "ورود به حساب", signupSubmitBtn: "ساخت حساب کاربری",
    logoutBtn: "خروج", editProfileBtn: "ویرایش پروفایل", saveChangesBtn: "ذخیره تغییرات", cancelBtn: "انصراف",
    myAdsTitle: "آگهی‌های من", newAdBtn: "آگهی جدید", noAdsYet: "هنوز آگهی‌ای ثبت نکردی.",
  },
  en: {
    searchPlaceholder: "Search on SPENTA...", searchPlaceholderHero: "e.g. «BMW 2022 under $30k near Berlin»",
    postAd: "Post a Free Ad", login: "Log in", wishlist: "Wishlist", savedSearches: "Saved Searches",
    categoriesEyebrow: "01 — Categories", categoriesTitle: "Where do we start?",
    featuredEyebrow: "02 — SPENTA Picks", featuredTitle: "Featured & Verified Listings",
    recentEyebrow: "03 — Newest", recentTitle: "Latest Listings",
    heroBadge: "A global market, no borders", heroTitle: "Find anything, anywhere.", heroSub: "Homes, cars, motorcycles, jobs, goods and services — all on one global marketplace. List it, get messages, close the deal.",
    searchBtn: "Search", statAds: "Active listings", statCities: "Active cities", statUsers: "SPENTA users",
    howEyebrow: "How it works", howTitle: "How does SPENTA work?",
    step1Title: "Easy sign-up", step1Desc: "Join SPENTA in under a minute — no hassle, no extra paperwork.",
    step2Title: "Fast listing", step2Desc: "Pick a category, add the details, and go live on the global showcase instantly.",
    step3Title: "Secure deal, low fees", step3Desc: "A fair fee is only charged once the deal actually closes — never before.",
    footerTagline: "The world's marketplace for everything", footerVersion: "© All rights reserved",
    drawerAds: "Listings", drawerOtherMarkets: "Other Markets", drawerComingSoon: "Coming soon",
    drawerAbout: "About us", drawerCareers: "Careers", drawerContact: "Contact us",
    drawerAccount: "View account", accountTitle: "Account", drawerLoginSignup: "Log in or sign up", drawerLocation: "Location", drawerLanguage: "Language",
    viewDetails: "View details", negotiable: "Negotiable",
    postAdTitle: "Post your ad", postAdSubtitle: "Posting is completely free. Every ad is reviewed by the SPENTA team before it goes live.",
    stepCategory: "Category", stepDetails: "Details", stepReview: "Submit for review",
    choosePrompt: "Which category does your ad belong to?", continueBtn: "Continue", backBtn: "Back",
    titleLabel: "Ad title", descLabel: "Description", priceLabel: "Price ($)", cityLabel: "City",
    submitReviewBtn: "Submit for review", submittingBtn: "Submitting...",
    doneTitle: "Your ad was submitted!", doneDesc: "It's now in the review queue — it'll go live once the SPENTA team approves it.", viewStatusBtn: "View ad status",
    loginTab: "Log in", signupTab: "Sign up", fullNameLabel: "Full name", emailLabel: "Email",
    phoneLabel: "Phone number", passwordLabel: "Password", loginSubmitBtn: "Log in", signupSubmitBtn: "Create account",
    logoutBtn: "Log out", editProfileBtn: "Edit profile", saveChangesBtn: "Save changes", cancelBtn: "Cancel",
    myAdsTitle: "My listings", newAdBtn: "New ad", noAdsYet: "You haven't posted anything yet.",
  },
  de: {
    searchPlaceholder: "Auf SPENTA suchen...", searchPlaceholderHero: "z. B. «BMW 2022 unter $30.000 in Berlin»",
    postAd: "Kostenlos inserieren", login: "Anmelden", wishlist: "Merkliste", savedSearches: "Gespeicherte Suchen",
    categoriesEyebrow: "01 — Kategorien", categoriesTitle: "Wo fangen wir an?",
    featuredEyebrow: "02 — SPENTA Empfehlungen", featuredTitle: "Ausgewählte & verifizierte Anzeigen",
    recentEyebrow: "03 — Neueste", recentTitle: "Neueste Anzeigen",
    heroBadge: "Ein globaler Markt, ohne Grenzen", heroTitle: "Finde alles, überall.", heroSub: "Wohnungen, Autos, Motorräder, Jobs, Waren und Dienstleistungen — alles auf einem globalen Marktplatz.",
    searchBtn: "Suchen", statAds: "Aktive Anzeigen", statCities: "Aktive Städte", statUsers: "SPENTA-Nutzer",
    howEyebrow: "So funktioniert's", howTitle: "Wie funktioniert SPENTA?",
    step1Title: "Einfache Anmeldung", step1Desc: "In weniger als einer Minute bei SPENTA dabei — unkompliziert, ohne Papierkram.",
    step2Title: "Schnell inserieren", step2Desc: "Kategorie wählen, Details eingeben, sofort weltweit sichtbar.",
    step3Title: "Sichere Deals, niedrige Gebühren", step3Desc: "Eine faire Gebühr fällt erst an, wenn der Deal wirklich abgeschlossen ist.",
    footerTagline: "Der globale Marktplatz für alles", footerVersion: "© Alle Rechte vorbehalten",
    drawerAds: "Anzeigen", drawerOtherMarkets: "Weitere Märkte", drawerComingSoon: "Demnächst",
    drawerAbout: "Über uns", drawerCareers: "Karriere", drawerContact: "Kontakt",
    drawerAccount: "Konto ansehen", accountTitle: "Konto", drawerLoginSignup: "Anmelden oder registrieren", drawerLocation: "Standort", drawerLanguage: "Sprache",
    viewDetails: "Details ansehen", negotiable: "Verhandelbar",
    postAdTitle: "Anzeige aufgeben", postAdSubtitle: "Das Inserieren ist völlig kostenlos. Jede Anzeige wird vom SPENTA-Team geprüft, bevor sie live geht.",
    stepCategory: "Kategorie", stepDetails: "Details", stepReview: "Zur Prüfung einreichen",
    choosePrompt: "Zu welcher Kategorie gehört deine Anzeige?", continueBtn: "Weiter", backBtn: "Zurück",
    titleLabel: "Titel der Anzeige", descLabel: "Beschreibung", priceLabel: "Preis ($)", cityLabel: "Stadt",
    submitReviewBtn: "Zur Prüfung einreichen", submittingBtn: "Wird gesendet...",
    doneTitle: "Deine Anzeige wurde eingereicht!", doneDesc: "Sie ist jetzt in der Prüfwarteschlange — sie geht live, sobald das SPENTA-Team sie freigibt.", viewStatusBtn: "Status ansehen",
    loginTab: "Anmelden", signupTab: "Registrieren", fullNameLabel: "Vollständiger Name", emailLabel: "E-Mail",
    phoneLabel: "Telefonnummer", passwordLabel: "Passwort", loginSubmitBtn: "Anmelden", signupSubmitBtn: "Konto erstellen",
    logoutBtn: "Abmelden", editProfileBtn: "Profil bearbeiten", saveChangesBtn: "Änderungen speichern", cancelBtn: "Abbrechen",
    myAdsTitle: "Meine Anzeigen", newAdBtn: "Neue Anzeige", noAdsYet: "Du hast noch nichts inseriert.",
  },
  fr: {
    searchPlaceholder: "Rechercher sur SPENTA...", searchPlaceholderHero: "ex. «BMW 2022 sous 30 000 $ près de Berlin»",
    postAd: "Publier une annonce gratuite", login: "Connexion", wishlist: "Favoris", savedSearches: "Recherches enregistrées",
    categoriesEyebrow: "01 — Catégories", categoriesTitle: "Par où commencer ?",
    featuredEyebrow: "02 — Sélection SPENTA", featuredTitle: "Annonces en vedette et vérifiées",
    recentEyebrow: "03 — Nouveautés", recentTitle: "Dernières annonces",
    heroBadge: "Un marché mondial, sans frontières", heroTitle: "Trouvez tout, partout.", heroSub: "Maisons, voitures, motos, emplois, biens et services — tout sur une seule place de marché mondiale.",
    searchBtn: "Rechercher", statAds: "Annonces actives", statCities: "Villes actives", statUsers: "Utilisateurs SPENTA",
    howEyebrow: "Comment ça marche", howTitle: "Comment fonctionne SPENTA ?",
    step1Title: "Inscription facile", step1Desc: "Rejoignez SPENTA en moins d'une minute — sans complications ni paperasse.",
    step2Title: "Annonce rapide", step2Desc: "Choisissez une catégorie, ajoutez les détails, et publiez instantanément.",
    step3Title: "Transaction sûre, frais réduits", step3Desc: "Des frais raisonnables ne sont prélevés qu'une fois la transaction réellement conclue.",
    footerTagline: "La place de marché mondiale pour tout", footerVersion: "© Tous droits réservés",
    drawerAds: "Annonces", drawerOtherMarkets: "Autres marchés", drawerComingSoon: "Bientôt",
    drawerAbout: "À propos", drawerCareers: "Carrières", drawerContact: "Nous contacter",
    drawerAccount: "Voir le compte", accountTitle: "Compte", drawerLoginSignup: "Connexion ou inscription", drawerLocation: "Emplacement", drawerLanguage: "Langue",
    viewDetails: "Voir les détails", negotiable: "Négociable",
    postAdTitle: "Publier votre annonce", postAdSubtitle: "La publication est entièrement gratuite. Chaque annonce est vérifiée par l'équipe SPENTA avant sa mise en ligne.",
    stepCategory: "Catégorie", stepDetails: "Détails", stepReview: "Envoyer pour vérification",
    choosePrompt: "À quelle catégorie appartient votre annonce ?", continueBtn: "Continuer", backBtn: "Retour",
    titleLabel: "Titre de l'annonce", descLabel: "Description", priceLabel: "Prix ($)", cityLabel: "Ville",
    submitReviewBtn: "Envoyer pour vérification", submittingBtn: "Envoi en cours...",
    doneTitle: "Votre annonce a été envoyée !", doneDesc: "Elle est maintenant en file d'attente — elle sera publiée dès que l'équipe SPENTA l'aura approuvée.", viewStatusBtn: "Voir le statut",
    loginTab: "Connexion", signupTab: "Inscription", fullNameLabel: "Nom complet", emailLabel: "E-mail",
    phoneLabel: "Numéro de téléphone", passwordLabel: "Mot de passe", loginSubmitBtn: "Se connecter", signupSubmitBtn: "Créer un compte",
    logoutBtn: "Déconnexion", editProfileBtn: "Modifier le profil", saveChangesBtn: "Enregistrer", cancelBtn: "Annuler",
    myAdsTitle: "Mes annonces", newAdBtn: "Nouvelle annonce", noAdsYet: "Vous n'avez encore rien publié.",
  },
  es: {
    searchPlaceholder: "Buscar en SPENTA...", searchPlaceholderHero: "ej. «BMW 2022 por menos de $30k cerca de Berlín»",
    postAd: "Publicar anuncio gratis", login: "Iniciar sesión", wishlist: "Favoritos", savedSearches: "Búsquedas guardadas",
    categoriesEyebrow: "01 — Categorías", categoriesTitle: "¿Por dónde empezamos?",
    featuredEyebrow: "02 — Selección SPENTA", featuredTitle: "Anuncios destacados y verificados",
    recentEyebrow: "03 — Recientes", recentTitle: "Últimos anuncios",
    heroBadge: "Un mercado global, sin fronteras", heroTitle: "Encuentra de todo, en todas partes.", heroSub: "Casas, autos, motos, empleos, artículos y servicios — todo en un solo mercado global.",
    searchBtn: "Buscar", statAds: "Anuncios activos", statCities: "Ciudades activas", statUsers: "Usuarios de SPENTA",
    howEyebrow: "Cómo funciona", howTitle: "¿Cómo funciona SPENTA?",
    step1Title: "Registro fácil", step1Desc: "Únete a SPENTA en menos de un minuto — sin complicaciones ni papeleo.",
    step2Title: "Publicación rápida", step2Desc: "Elige una categoría, añade los detalles y publica al instante.",
    step3Title: "Trato seguro, comisión baja", step3Desc: "Solo se cobra una comisión justa cuando el trato realmente se cierra.",
    footerTagline: "El mercado mundial para todo", footerVersion: "© Todos los derechos reservados",
    drawerAds: "Anuncios", drawerOtherMarkets: "Otros mercados", drawerComingSoon: "Próximamente",
    drawerAbout: "Sobre nosotros", drawerCareers: "Empleo", drawerContact: "Contacto",
    drawerAccount: "Ver cuenta", accountTitle: "Cuenta", drawerLoginSignup: "Iniciar sesión o registrarse", drawerLocation: "Ubicación", drawerLanguage: "Idioma",
    viewDetails: "Ver detalles", negotiable: "Negociable",
    postAdTitle: "Publica tu anuncio", postAdSubtitle: "Publicar es totalmente gratis. Cada anuncio es revisado por el equipo de SPENTA antes de publicarse.",
    stepCategory: "Categoría", stepDetails: "Detalles", stepReview: "Enviar para revisión",
    choosePrompt: "¿A qué categoría pertenece tu anuncio?", continueBtn: "Continuar", backBtn: "Atrás",
    titleLabel: "Título del anuncio", descLabel: "Descripción", priceLabel: "Precio ($)", cityLabel: "Ciudad",
    submitReviewBtn: "Enviar para revisión", submittingBtn: "Enviando...",
    doneTitle: "¡Tu anuncio fue enviado!", doneDesc: "Ahora está en la cola de revisión — se publicará en cuanto el equipo de SPENTA lo apruebe.", viewStatusBtn: "Ver estado",
    loginTab: "Iniciar sesión", signupTab: "Registrarse", fullNameLabel: "Nombre completo", emailLabel: "Correo electrónico",
    phoneLabel: "Número de teléfono", passwordLabel: "Contraseña", loginSubmitBtn: "Iniciar sesión", signupSubmitBtn: "Crear cuenta",
    logoutBtn: "Cerrar sesión", editProfileBtn: "Editar perfil", saveChangesBtn: "Guardar cambios", cancelBtn: "Cancelar",
    myAdsTitle: "Mis anuncios", newAdBtn: "Nuevo anuncio", noAdsYet: "Aún no has publicado nada.",
  },
  tr: {
    searchPlaceholder: "SPENTA'da ara...", searchPlaceholderHero: "örn. «Berlin yakınında $30k altı BMW 2022»",
    postAd: "Ücretsiz İlan Ver", login: "Giriş yap", wishlist: "Favoriler", savedSearches: "Kayıtlı Aramalar",
    categoriesEyebrow: "01 — Kategoriler", categoriesTitle: "Nereden başlayalım?",
    featuredEyebrow: "02 — SPENTA Seçkisi", featuredTitle: "Öne çıkan ve onaylı ilanlar",
    recentEyebrow: "03 — En yeniler", recentTitle: "En yeni ilanlar",
    heroBadge: "Sınırsız küresel bir pazar", heroTitle: "Her şeyi, her yerde bul.", heroSub: "Ev, araba, motosiklet, iş fırsatları, eşya ve hizmetler — hepsi tek bir küresel pazarda.",
    searchBtn: "Ara", statAds: "Aktif ilan", statCities: "Aktif şehir", statUsers: "SPENTA kullanıcısı",
    howEyebrow: "Nasıl çalışır", howTitle: "SPENTA nasıl çalışır?",
    step1Title: "Kolay kayıt", step1Desc: "Bir dakikadan kısa sürede SPENTA'ya katıl — zahmetsiz, ekstra evrak yok.",
    step2Title: "Hızlı ilan", step2Desc: "Kategori seç, detayları yaz, anında küresel vitrine çık.",
    step3Title: "Güvenli işlem, düşük komisyon", step3Desc: "Adil bir komisyon yalnızca işlem gerçekten tamamlandığında kesilir.",
    footerTagline: "Her şey için küresel pazar yeri", footerVersion: "© Tüm hakları saklıdır",
    drawerAds: "İlanlar", drawerOtherMarkets: "Diğer Pazarlar", drawerComingSoon: "Yakında",
    drawerAbout: "Hakkımızda", drawerCareers: "Kariyer", drawerContact: "Bize ulaşın",
    drawerAccount: "Hesabı görüntüle", accountTitle: "Hesap", drawerLoginSignup: "Giriş yap veya kaydol", drawerLocation: "Konum", drawerLanguage: "Dil",
    viewDetails: "Detayları gör", negotiable: "Pazarlık edilir",
    postAdTitle: "İlanını ver", postAdSubtitle: "İlan vermek tamamen ücretsizdir. Her ilan yayına girmeden önce SPENTA ekibi tarafından incelenir.",
    stepCategory: "Kategori", stepDetails: "Detaylar", stepReview: "İncelemeye gönder",
    choosePrompt: "İlanın hangi kategoriye ait?", continueBtn: "Devam et", backBtn: "Geri",
    titleLabel: "İlan başlığı", descLabel: "Açıklama", priceLabel: "Fiyat ($)", cityLabel: "Şehir",
    submitReviewBtn: "İncelemeye gönder", submittingBtn: "Gönderiliyor...",
    doneTitle: "İlanın gönderildi!", doneDesc: "Şu anda inceleme sırasında — SPENTA ekibi onayladığında yayına girecek.", viewStatusBtn: "Durumu görüntüle",
    loginTab: "Giriş yap", signupTab: "Kaydol", fullNameLabel: "Ad soyad", emailLabel: "E-posta",
    phoneLabel: "Telefon numarası", passwordLabel: "Şifre", loginSubmitBtn: "Giriş yap", signupSubmitBtn: "Hesap oluştur",
    logoutBtn: "Çıkış yap", editProfileBtn: "Profili düzenle", saveChangesBtn: "Değişiklikleri kaydet", cancelBtn: "Vazgeç",
    myAdsTitle: "İlanlarım", newAdBtn: "Yeni ilan", noAdsYet: "Henüz bir ilan vermedin.",
  },
};

const CURRENCIES = [
  { code: "USD", symbol: "$", rate: 1 },
  { code: "EUR", symbol: "€", rate: 0.92 },
  { code: "GBP", symbol: "£", rate: 0.79 },
  { code: "TRY", symbol: "₺", rate: 34.5 },
  { code: "AED", symbol: "AED", rate: 3.67 },
];
function convertPrice(usd, code) {
  const c = CURRENCIES.find((x) => x.code === code) || CURRENCIES[0];
  const val = usd * c.rate;
  const rounded = val >= 1000 ? Math.round(val) : Math.round(val * 100) / 100;
  return c.symbol + rounded.toLocaleString("en-US");
}

const LangContext = React.createContext({ lang: "fa", setLang: () => {}, t: (k) => I18N.fa[k] ?? k, currency: "USD", setCurrency: () => {}, fmt: (usd) => "$" + usd });
function useLang() { return React.useContext(LangContext); }
function catLabel(cat, lang) { return lang === "fa" ? cat.label : (CAT_I18N[cat.id]?.[lang] || cat.label); }

const CITIES = ["Tehran", "Dubai", "Istanbul", "London", "Berlin", "Vancouver", "Kuala Lumpur"];

const CITY_COORDS = {
  "Tehran": { lat: 35.6892, lng: 51.3890, country: "Iran" },
  "Dubai": { lat: 25.2048, lng: 55.2708, country: "United Arab Emirates" },
  "Istanbul": { lat: 41.0082, lng: 28.9784, country: "Turkey" },
  "London": { lat: 51.5074, lng: -0.1278, country: "United Kingdom" },
  "Berlin": { lat: 52.5200, lng: 13.4050, country: "Germany" },
  "Vancouver": { lat: 49.2827, lng: -123.1207, country: "Canada" },
  "Kuala Lumpur": { lat: 3.1390, lng: 101.6869, country: "Malaysia" },
};

const FIELDS_BY_CATEGORY = {
  realestate: [
    { key: "dealType", label: "Deal type", type: "select", options: ["Sale", "Rent"] },
    { key: "area", label: "Area (sqm)", type: "number" },
    { key: "rooms", label: "Number of rooms", type: "number" },
  ],
  vehicles: [
    { key: "brand", label: "Brand & model", type: "text" },
    { key: "year", label: "Year built", type: "number" },
    { key: "mileage", label: "Mileage (km)", type: "number" },
  ],
  motorcycles: [
    { key: "brand", label: "Brand & model", type: "text" },
    { key: "year", label: "Year built", type: "number" },
    { key: "cc", label: "Engine size (cc)", type: "number" },
  ],
  jobs: [
    { key: "role", label: "Job title", type: "text" },
    { key: "workType", label: "Work type", type: "select", options: ["On-site", "Remote", "Hybrid"] },
    { key: "salary", label: "Salary range (monthly, $)", type: "text" },
  ],
  goods: [
    { key: "condition", label: "Condition", type: "select", options: ["New", "Used"] },
    { key: "brand", label: "Brand / Item type", type: "text" },
  ],
  services: [
    { key: "serviceType", label: "Service type", type: "text" },
    { key: "experience", label: "Experience (yr)", type: "number" },
  ],
};

/* ------------------------------------------------------------------ */
/*  Seed data — 10 listings per category                               */
/* ------------------------------------------------------------------ */

const mkReviews = (avg, count, items) => ({ avg, count, items: items || [] });
const noReviews = mkReviews(0, 0, []);

// Cycling pool of seller names so demo listings don't all say "Demo".
const SELLER_POOL = [
  "Arman Rezaei", "Layla Haddad", "Deniz Kaya", "Sophie Lindqvist", "Marcus Weber",
  "Chloe Tan", "Omid Farhadi", "Amira Youssef", "Jack Whitfield", "Nadia Karimi",
  "Baran Salehi", "Elif Demir", "Lucas Fischer", "Wei Chen", "Reza Ahmadi",
  "Priya Nair", "Hugo Martins", "Sana Malik", "Tomas Novak", "Aylin Şahin",
];
const sellerFor = (idx) => SELLER_POOL[idx % SELLER_POOL.length];
const R = (avg, count, user, text) => mkReviews(avg, count, [{ id: "c" + Math.random().toString(36).slice(2), user, stars: Math.round(avg), text }]);

const RE_ROWS = [
  ["Two-bedroom apartment near city center", 185000, "Istanbul", "Sale", 95, 2, "verified", R(4.6, 12, "Sara", "I viewed it in person — exactly as pictured.")],
  ["Three-bedroom beachfront villa with pool", 640000, "Dubai", "Sale", 260, 3, "featured", R(5, 9, "Leila", "The build quality and materials are outstanding.")],
  ["Modern studio in a residential tower", 92000, "Kuala Lumpur", "Sale", 42, 1, null, noReviews],
  ["Penthouse with sea view", 480000, "Vancouver", "Sale", 180, 3, "featured", R(4.8, 6, "Nima", "The sea view is truly incredible.")],
  ["House with yard in a quiet neighborhood", 310000, "Tehran", "Sale", 210, 4, null, noReviews],
  ["One-bedroom apartment for rent", 1200, "London", "Rent", 55, 1, "verified", R(4.4, 7, "Kimia", "Being close to the metro is really convenient.")],
  ["Renovated duplex", 225000, "Berlin", "Sale", 130, 3, null, noReviews],
  ["Short-term furnished suite", 850, "Dubai", "Rent", 38, 1, null, noReviews],
  ["residential land, ready to build", 150000, "Istanbul", "Sale", 400, 0, null, noReviews],
  ["Mountain villa with private garden", 395000, "Vancouver", "Sale", 220, 4, "featured", R(4.9, 11, "Arash", "The quiet and natural surroundings are wonderful.")],
  ["Compact studio near the tech district", 78000, "Berlin", "Sale", 34, 1, null, noReviews],
  ["Family townhouse with private garage", 265000, "London", "Sale", 165, 3, "verified", R(4.5, 9, "Farrokh", "Exactly what we needed for the kids and the car.")],
  ["Furnished executive apartment, downtown", 2400, "Dubai", "Rent", 88, 2, "featured", R(4.7, 13, "Golnaz", "Move-in ready, spotless when we arrived.")],
  ["Traditional courtyard house, renovated", 275000, "Tehran", "Sale", 240, 4, null, R(4.3, 5, "Payam", "Beautiful old architecture, carefully restored.")],
  ["Waterfront condo with marina view", 520000, "Vancouver", "Sale", 145, 2, "featured", R(4.8, 16, "Selin", "Waking up to that view never gets old.")],
  ["Affordable studio for students", 620, "Istanbul", "Rent", 28, 1, null, noReviews],
  ["Loft-style apartment in a converted factory", 198000, "Berlin", "Sale", 110, 2, "verified", R(4.6, 8, "Kourosh", "So much character compared to a standard flat.")],
  ["Gated community villa with private pool", 710000, "Dubai", "Sale", 310, 5, "featured", R(4.9, 20, "Ariana", "Security and amenities are top-notch.")],
  ["Two-story office space, prime location", 3200, "London", "Rent", 140, 0, null, noReviews],
  ["Cozy one-bedroom near the beach", 145000, "Kuala Lumpur", "Sale", 58, 1, null, R(4.2, 4, "Behnam", "Short walk to the beach, quiet street.")],
  ["Large family home with orchard", 340000, "Tehran", "Sale", 380, 5, "verified", R(4.7, 7, "Neda", "The garden alone was worth it.")],
];

const VEH_ROWS = [
  ["high-end sedan, low mileage", 21500, "Dubai", "Toyota Camry", 2022, 18000, "featured", R(4.9, 27, "Reza", "I had it inspected — the mechanical condition was excellent.")],
  ["fully-loaded family SUV", 34500, "London", "Hyundai Palisade", 2021, 32000, null, R(4.2, 6, "Mina", "Great for a large family.")],
  ["economical hatchback, great for the city", 9800, "Istanbul", "Kia Rio", 2019, 54000, null, noReviews],
  ["2-door sport coupe", 28900, "Berlin", "BMW 430", 2020, 26000, "verified", R(4.7, 9, "Pouya", "Fun to drive, sounds amazing.")],
  ["well-maintained work pickup", 13200, "Tehran", "Toyota Hilux", 2017, 88000, null, noReviews],
  ["fuel-efficient hybrid crossover", 24700, "Vancouver", "Toyota RAV4 Hybrid", 2022, 15000, "featured", R(4.8, 14, "Shima", "Its fuel consumption is very low.")],
  ["luxury sedan, still under warranty", 41200, "Dubai", "Mercedes E200", 2023, 9000, "verified", R(5, 5, "Hamed", "brand new, full warranty.")],
  ["7-seat family van", 19800, "Kuala Lumpur", "Honda Odyssey", 2018, 67000, null, noReviews],
  ["emerging electric vehicle", 31500, "London", "Tesla Model 3", 2021, 21000, "featured", R(4.6, 19, "Elham", "Its autopilot gives a whole different experience.")],
  ["restored collector's classic", 52000, "Istanbul", "Ford Mustang 1967", 1967, 120000, null, noReviews],
  ["compact city car, low running costs", 8400, "Berlin", "Volkswagen Polo", 2020, 41000, null, noReviews],
  ["mid-size sedan, one owner", 17200, "Vancouver", "Honda Accord", 2021, 28000, "verified", R(4.6, 11, "Cyrus", "Full service history, drives like new.")],
  ["compact SUV with all-wheel drive", 22800, "Tehran", "Hyundai Tucson", 2020, 39000, null, R(4.3, 5, "Marjan", "Handles well on rougher roads.")],
  ["performance coupe, track-ready", 46500, "Dubai", "BMW M4", 2022, 12000, "featured", R(4.9, 18, "Yousef", "Insane power, still road-legal comfort.")],
  ["reliable diesel pickup truck", 24300, "Kuala Lumpur", "Ford Ranger", 2019, 62000, null, noReviews],
  ["hybrid sedan, excellent fuel economy", 19500, "Istanbul", "Toyota Corolla Hybrid", 2021, 33000, "verified", R(4.5, 9, "Ladan", "Barely spend anything on fuel.")],
  ["premium electric sedan, long range", 38900, "Berlin", "Tesla Model S", 2022, 18000, "featured", R(4.8, 14, "Siavash", "Range easily covers a week of driving.")],
  ["off-road capable 4x4", 27600, "Tehran", "Toyota Land Cruiser", 2018, 71000, null, noReviews],
  ["compact hatchback, first-car friendly", 7200, "Vancouver", "Honda Fit", 2018, 58000, null, noReviews],
  ["convertible sports car", 33400, "Dubai", "Ford Mustang GT", 2021, 20000, "featured", R(4.7, 10, "Roxana", "Turns heads every time.")],
  ["minivan with low mileage", 16800, "London", "Kia Carnival", 2020, 24000, null, noReviews],
];

const MOTO_ROWS = [
  ["restored classic motorcycle", 6200, "Vancouver", "Ducati Scrambler", 2019, 800, "featured", R(4.8, 15, "Kian", "The restoration quality is outstanding.")],
  ["fuel-efficient city scooter", 1450, "Tehran", "Honda PCX", 2021, 150, null, noReviews],
  ["professional motocross bike", 5300, "Dubai", "Kawasaki KX250", 2020, 250, null, noReviews],
  ["touring bike, great for long trips", 15800, "Berlin", "BMW R1250GS", 2022, 1250, "verified", R(4.9, 8, "Farzad", "It's perfect for long trips.")],
  ["naked street bike", 7600, "Istanbul", "Yamaha MT-07", 2021, 690, null, noReviews],
  ["light electric city motorcycle", 2100, "London", "under FXE", 2022, 0, "featured", R(4.5, 6, "Negar", "It's quiet and very agile.")],
  ["distinctive American chopper", 13400, "Vancouver", "Harley-Davidson Fat Boy", 2018, 1750, null, noReviews],
  ["light off-road motorcycle", 3200, "Tehran", "Honda CRF250", 2020, 250, null, noReviews],
  ["high-end sport model", 18900, "Dubai", "Kawasaki Ninja ZX-10R", 2023, 1000, "featured", R(4.7, 12, "Bardia", "Its acceleration is top-tier.")],
  ["rare Italian classic", 9800, "Berlin", "Moto Guzzi V7", 1978, 750, "verified", R(5, 4, "Soheil", "It's a piece of history, flawless.")],
  ["adventure touring bike", 11200, "Tehran", "Honda Africa Twin", 2021, 950, "featured", R(4.7, 9, "Delara", "Handles long dirt roads beautifully.")],
  ["beginner-friendly commuter bike", 3800, "Istanbul", "Yamaha YBR125", 2020, 180, null, noReviews],
  ["sport-touring hybrid", 8900, "Vancouver", "Kawasaki Versys 650", 2021, 620, "verified", R(4.6, 7, "Homan", "Comfortable enough for 300km days.")],
  ["retro-styled cafe racer", 6700, "London", "Triumph Street Twin", 2020, 410, "featured", R(4.8, 12, "Tara", "Looks incredible, sounds even better.")],
  ["compact scooter for city errands", 1150, "Kuala Lumpur", "Yamaha NMAX", 2022, 90, null, noReviews],
  ["cruiser with classic styling", 10400, "Dubai", "Indian Scout", 2019, 890, null, R(4.4, 5, "Bahram", "Smooth ride, great presence on the road.")],
  ["dirt bike for weekend trails", 2900, "Berlin", "Yamaha WR250F", 2019, 320, null, noReviews],
  ["flagship sport bike, track pedigree", 21500, "Istanbul", "Ducati Panigale V4", 2022, 500, "featured", R(4.9, 15, "Nastaran", "An absolute weapon on the track.")],
];

const JOB_ROWS = [
  ["Senior Product Designer — Remote", 0, "London", "Senior Product Designer", "Remote", "4500-6000", "verified", R(4.3, 8, "Maryam", "The interview process was clear and fast.")],
  ["Backend Developer — On-site", 0, "Berlin", "Backend Developer", "On-site", "3800-5200", null, noReviews],
  ["Digital Marketing Manager", 0, "Dubai", "Digital Marketing Manager", "Hybrid", "3000-4500", "featured", R(4.6, 5, "Aida", "The team is very professional and dynamic.")],
  ["International Sales Specialist", 0, "Istanbul", "Sales Specialist", "On-site", "2200-3500", null, noReviews],
  ["Data Engineer — Hybrid", 0, "Vancouver", "Data Engineer", "Hybrid", "5000-7000", "featured", R(4.9, 7, "Omid", "It has interesting technical challenges.")],
  ["Construction Project Manager", 0, "Tehran", "Project Manager", "On-site", "2800-4000", null, noReviews],
  ["Customer Support Specialist", 0, "Kuala Lumpur", "Support specialist", "Remote", "1500-2200", null, noReviews],
  ["Freelance Graphic Designer", 0, "London", "Graphic Designer", "Remote", "2000-3200", "verified", R(4.4, 6, "Parisa", "The collaboration was flexible and fair.")],
  ["Senior Corporate Accountant", 0, "Dubai", "Senior Accountant", "On-site", "3200-4800", null, noReviews],
  ["Fintech Product Manager", 0, "Berlin", "Product Manager", "Hybrid", "5500-7500", "featured", R(4.7, 9, "Ramin", "The work environment is very professional.")],
  ["DevOps Engineer — Remote", 0, "Vancouver", "DevOps Engineer", "Remote", "4800-6500", "verified", R(4.5, 6, "Foad", "Great tooling and a very responsive team.")],
  ["HR Business Partner", 0, "Dubai", "HR Business Partner", "On-site", "2600-3800", null, noReviews],
  ["UX Researcher — Hybrid", 0, "London", "UX Researcher", "Hybrid", "3600-5000", "featured", R(4.6, 8, "Setareh", "Really values user research in decision-making.")],
  ["Warehouse Operations Supervisor", 0, "Istanbul", "Operations Supervisor", "On-site", "1800-2600", null, noReviews],
  ["Content Marketing Writer — Remote", 0, "Kuala Lumpur", "Content Writer", "Remote", "1400-2100", null, R(4.2, 4, "Ehsan", "Flexible schedule, clear expectations.")],
  ["Mechanical Engineer, Manufacturing", 0, "Tehran", "Mechanical Engineer", "On-site", "2400-3600", "verified", R(4.4, 5, "Ghazal", "Solid engineering culture, good mentorship.")],
  ["QA Automation Engineer", 0, "Berlin", "QA Engineer", "Hybrid", "3400-4800", null, noReviews],
  ["Executive Assistant to CEO", 0, "Dubai", "Executive Assistant", "On-site", "2800-4000", "featured", R(4.8, 7, "Niloofar", "Fast-paced but incredibly well organized.")],
  ["Supply Chain Analyst", 0, "Vancouver", "Supply Chain Analyst", "Hybrid", "3200-4400", null, noReviews],
];

const GOODS_ROWS = [
  ["professional mirrorless camera, new", 1650, "Berlin", "New", "Sony Alpha", null, noReviews],
  ["handmade wooden desk", 340, "Kuala Lumpur", "New", "walnut wood", null, noReviews],
  ["used gaming laptop", 980, "Tehran", "Used", "Asus ROG", null, R(4.1, 3, "Babak", "It performs well for the price.")],
  ["6-seat living room set", 1200, "Istanbul", "New", "genuine leather", "featured", R(4.5, 5, "Nazanin", "The leather quality is excellent.")],
  ["genuine Swiss wristwatch", 3400, "Dubai", "Used", "Tag Heuer", "verified", R(4.8, 4, "Sam", "Its authenticity was verified — excellent.")],
  ["carbon mountain bike", 2100, "Vancouver", "New", "", null, noReviews],
  ["energy-efficient side-by-side fridge", 890, "London", "New", "Bosch", null, noReviews],
  ["collector's electric guitar", 1750, "Berlin", "Used", "Fender Stratocaster", "featured", R(4.9, 8, "Kaveh", "It has an incredible sound.")],
  ["complete power tool workshop set", 560, "Tehran", "Used", "professional Bosch", null, noReviews],
  ["55-inch smart TV", 620, "Istanbul", "New", "LG OLED", null, noReviews],
  ["standing desk with memory presets", 410, "Vancouver", "New", "Uplift", null, noReviews],
  ["vintage film camera, fully working", 280, "Berlin", "Used", "Canon AE-1", "verified", R(4.7, 6, "Arezoo", "Tested every setting — flawless mechanics.")],
  ["set of noise-cancelling headphones", 240, "Dubai", "New", "Sony WH-1000XM5", null, R(4.5, 9, "Kamran", "Silence on demand, worth every dollar.")],
  ["leather sectional sofa", 1450, "London", "Used", "West Elm", null, noReviews],
  ["road bike, carbon frame", 1900, "Istanbul", "New", "Specialized Tarmac", "featured", R(4.8, 7, "Mahtab", "Climbs like it weighs nothing.")],
  ["upright piano, recently tuned", 1100, "Tehran", "Used", "Yamaha U1", null, R(4.6, 3, "Ashkan", "Beautiful tone, well maintained.")],
  ["espresso machine, semi-automatic", 620, "Berlin", "New", "Breville", null, noReviews],
  ["kids' bunk bed with storage", 340, "Kuala Lumpur", "New", "IKEA", null, noReviews],
  ["designer handbag, authenticated", 890, "Dubai", "Used", "Louis Vuitton", "verified", R(4.9, 5, "Sepideh", "Came with the authenticity certificate.")],
  ["home gym power rack with weights", 780, "Vancouver", "Used", "Rogue", null, noReviews],
  ["professional drone with 4K camera", 1250, "London", "New", "DJI Mavic 3", "featured", R(4.7, 8, "Iman", "Footage quality is genuinely cinematic.")],
];

const SERV_ROWS = [
  ["Private garden design & installation", 0, "Tehran", "Landscape design", 7, null, R(4.1, 5, "Yasmin", "The result was very tastefully done.")],
  ["Contract legal consulting", 0, "London", "Legal consulting", 10, "verified", R(4.7, 11, "Farhad", "The description was clear and detailed.")],
  ["professional event photography", 0, "Dubai", "Event photography", 5, "featured", R(4.9, 14, "Donya", "The photos were extremely professional.")],
  ["Private English tutoring", 0, "Istanbul", "Language tutoring", 6, null, noReviews],
  ["Solar power system installation", 0, "Vancouver", "Solar energy", 4, null, noReviews],
  ["Home interior design", 0, "Berlin", "Interior Design", 8, "featured", R(4.8, 9, "Shadi", "Their design style is very modern.")],
  ["Business accounting & taxes", 0, "Kuala Lumpur", "Accounting", 12, null, noReviews],
  ["On-site car repair & maintenance", 0, "Tehran", "Car repair", 9, null, R(4.3, 6, "Vahid", "They came quickly and solved the problem.")],
  ["Online fitness consulting", 0, "Dubai", "Fitness coaching", 3, "verified", R(4.6, 7, "Raha", "The plan was fully personalized.")],
  ["Specialized document translation", 0, "London", "Specialized translation", 7, null, noReviews],
  ["Wedding & event planning", 0, "Dubai", "Event planning", 6, "featured", R(4.9, 12, "Roya", "Every detail was handled perfectly.")],
  ["Residential plumbing & repairs", 0, "Tehran", "Plumbing", 15, null, R(4.3, 9, "Alireza", "Fixed the leak fast, fair price.")],
  ["Professional resume & LinkedIn writing", 0, "Vancouver", "Career coaching", 5, "verified", R(4.6, 7, "Nasrin", "Got three interviews within a week.")],
  ["Full home renovation contracting", 0, "Berlin", "Renovation", 14, "featured", R(4.7, 10, "Kambiz", "On time, on budget, great communication.")],
  ["Pet grooming & boarding", 0, "Istanbul", "Pet care", 4, null, noReviews],
  ["Corporate video production", 0, "Dubai", "Video production", 8, "featured", R(4.8, 11, "Mahsa", "Delivered a polished video ahead of schedule.")],
  ["Math & science private tutoring", 0, "Kuala Lumpur", "Tutoring", 6, null, R(4.5, 6, "Peyman", "My daughter's grades improved noticeably.")],
  ["IT support & network setup for offices", 0, "London", "IT support", 9, "verified", R(4.4, 5, "Farideh", "Quick response time, explained everything clearly.")],
  ["Custom furniture making", 0, "Tehran", "Carpentry", 11, null, noReviews],
];

function buildRealestate() {
  return RE_ROWS.map((r, i) => ({
    id: "re" + i, category: "realestate", title: r[0], price: r[1], city: r[2], owner: sellerFor(i),
    img: `https://picsum.photos/seed/re${i}/800/560`,
    images: [`https://picsum.photos/seed/re${i}/800/560`, `https://picsum.photos/seed/re${i}b/800/560`, `https://picsum.photos/seed/re${i}c/800/560`],
    description: `${r[0]} in ${r[2]}, ready for an in-person viewing and direct negotiation with the seller.`,
    fields: { dealType: r[3], area: r[4], rooms: r[5] }, stamp: r[6], status: "approved", createdAt: Date.now() - i * 3600000, reviews: r[7],
  }));
}
function buildVehicles() {
  return VEH_ROWS.map((r, i) => ({
    id: "veh" + i, category: "vehicles", title: r[0], price: r[1], city: r[2], owner: sellerFor(i + 3),
    img: `https://picsum.photos/seed/veh${i}/800/560`,
    images: [`https://picsum.photos/seed/veh${i}/800/560`, `https://picsum.photos/seed/veh${i}b/800/560`, `https://picsum.photos/seed/veh${i}c/800/560`],
    description: `${r[3]} Model ${r[4]}, mileage ${r[5].toLocaleString("en-US")} km, insured, full documentation.`,
    fields: { brand: r[3], year: r[4], mileage: r[5] }, stamp: r[6], status: "approved", createdAt: Date.now() - i * 2900000, reviews: r[7],
  }));
}
function buildMoto() {
  return MOTO_ROWS.map((r, i) => ({
    id: "moto" + i, category: "motorcycles", title: r[0], price: r[1], city: r[2], owner: sellerFor(i + 6),
    img: `https://picsum.photos/seed/moto${i}/800/560`,
    images: [`https://picsum.photos/seed/moto${i}/800/560`, `https://picsum.photos/seed/moto${i}b/800/560`, `https://picsum.photos/seed/moto${i}c/800/560`],
    description: `${r[3]} Model ${r[4]}, regularly serviced and ready for delivery.`,
    fields: { brand: r[3], year: r[4], cc: r[5] }, stamp: r[6], status: "approved", createdAt: Date.now() - i * 2600000, reviews: r[7],
  }));
}
function buildJobs() {
  return JOB_ROWS.map((r, i) => ({
    id: "job" + i, category: "jobs", title: r[0], price: r[1], city: r[2], owner: sellerFor(i + 9),
    img: `https://picsum.photos/seed/job${i}/800/560`,
    images: [`https://picsum.photos/seed/job${i}/800/560`, `https://picsum.photos/seed/job${i}b/800/560`],
    description: `Job opportunity ${r[3]} in ${r[2]}, work type ${r[4]} with competitive pay.`,
    fields: { role: r[3], workType: r[4], salary: r[5] }, stamp: r[6], status: "approved", createdAt: Date.now() - i * 2300000, reviews: r[7],
  }));
}
function buildGoods() {
  return GOODS_ROWS.map((r, i) => ({
    id: "goods" + i, category: "goods", title: r[0], price: r[1], city: r[2], owner: sellerFor(i + 12),
    img: `https://picsum.photos/seed/goods${i}/800/560`,
    images: [`https://picsum.photos/seed/goods${i}/800/560`, `https://picsum.photos/seed/goods${i}b/800/560`, `https://picsum.photos/seed/goods${i}c/800/560`],
    description: `Condition ${r[3]}, brand ${r[4]}, ready for shipping or in-person pickup in ${r[2]}.`,
    fields: { condition: r[3], brand: r[4] }, stamp: r[5], status: "approved", createdAt: Date.now() - i * 2000000, reviews: r[6],
  }));
}
function buildServices() {
  return SERV_ROWS.map((r, i) => ({
    id: "serv" + i, category: "services", title: r[0], price: r[1], city: r[2], owner: sellerFor(i + 15),
    img: `https://picsum.photos/seed/serv${i}/800/560`,
    images: [`https://picsum.photos/seed/serv${i}/800/560`, `https://picsum.photos/seed/serv${i}b/800/560`],
    description: `${r[3]} with ${r[4]} years of experience, providing services in ${r[2]} and surrounding areas.`,
    fields: { serviceType: r[3], experience: r[4] }, stamp: r[5], status: "approved", createdAt: Date.now() - i * 1700000, reviews: r[6],
  }));
}

const SEED_LISTINGS = [
  ...buildRealestate(), ...buildVehicles(), ...buildMoto(), ...buildJobs(), ...buildGoods(), ...buildServices(),
].sort((a, b) => b.createdAt - a.createdAt);

const fmt = (n) => "$" + Number(n).toLocaleString("en-US");
function hashId(str) { let h = 0; for (let i = 0; i < str.length; i++) { h = (h << 5) - h + str.charCodeAt(i); h |= 0; } return Math.abs(h); }

// Fallback for when an external placeholder image (picsum.photos) fails to
// load — slow network, blocked domain, rate limiting, restrictive CSP, etc.
// Renders a plain styled element (no image request at all, so it always
// works) instead of swapping to another <img src>, which can itself fail
// under strict content-security-policies that block data: URIs.
function SmartImg({ src, alt = "", className = "", style = {}, onLoad, ...rest }) {
  const [broken, setBroken] = useState(false);
  if (broken || !src) {
    return (
      <div className={className} style={{ ...style, background: SURFACE, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <ImageIcon size={22} color="#8B8E99" strokeWidth={1.5} />
      </div>
    );
  }
  return <img src={src} alt={alt} className={className} style={style} onLoad={onLoad} onError={() => setBroken(true)} {...rest} />;
}

/* ------------------------------------------------------------------ */
/*  Smart search parser                                                */
/* ------------------------------------------------------------------ */

const CITY_ALIASES = { Tehran: "Tehran", Dubai: "Dubai", Istanbul: "Istanbul", London: "London", Berlin: "Berlin", Vancouver: "Vancouver", "Kuala Lumpur": "Kuala Lumpur" };

function parseSmartQuery(raw) {
  const q = (raw || "").trim();
  if (!q) return null;
  let text = q;
  const result = { maxPrice: null, year: null, city: null, keyword: "" };

  const priceMatch = text.match(/(?:under|under|under)\s*\$?\s*(\d+(?:\.\d+)?)\s*(k|thousand)?/i);
  if (priceMatch) {
    let n = parseFloat(priceMatch[1]);
    if (priceMatch[2]) n *= 1000;
    result.maxPrice = n;
    text = text.replace(priceMatch[0], " ");
  }

  const yearMatch = text.match(/\b(19|20)\d{2}\b/);
  if (yearMatch) { result.year = yearMatch[0]; text = text.replace(yearMatch[0], " "); }

  for (const [en, fa] of Object.entries(CITY_ALIASES)) {
    const re = new RegExp(`\\b${en}\\b`, "i");
    if (re.test(text) || text.includes(fa)) {
      result.city = fa;
      text = text.replace(re, " ").replace(fa, " ");
      break;
    }
  }
  text = text.replace(/\bnear\b|\bin\b/gi, " ").trim();
  result.keyword = text.replace(/\s+/g, " ").trim();
  return result;
}

/* ------------------------------------------------------------------ */
/*  Location / distance                                                */
/* ------------------------------------------------------------------ */

function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function listingCoords(ad) {
  const base = CITY_COORDS[ad.city];
  if (!base) return null;
  const h = hashId(ad.id);
  return { lat: base.lat + ((h % 100) - 50) / 5000, lng: base.lng + (((h >> 3) % 100) - 50) / 5000 };
}

function useGeolocation() {
  const [coords, setCoords] = useState(null);
  const [status, setStatus] = useState("idle");
  const request = () => {
    if (!navigator.geolocation) { setStatus("denied"); return; }
    setStatus("loading");
    navigator.geolocation.getCurrentPosition(
      (pos) => { setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude }); setStatus("granted"); },
      () => setStatus("denied"),
      { timeout: 8000 }
    );
  };
  return { coords, status, request };
}

function useLeaflet() {
  const [ready, setReady] = useState(typeof window !== "undefined" && !!window.L);
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (window.L) { setReady(true); return; }
    if (!document.getElementById("leaflet-css")) {
      const css = document.createElement("link");
      css.id = "leaflet-css";
      css.rel = "stylesheet";
      css.href = "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css";
      document.head.appendChild(css);
    }
    if (!document.getElementById("leaflet-js")) {
      const script = document.createElement("script");
      script.id = "leaflet-js";
      script.src = "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js";
      script.async = true;
      script.onload = () => setReady(true);
      document.body.appendChild(script);
    } else {
      document.getElementById("leaflet-js").addEventListener("load", () => setReady(true));
    }
  }, []);
  return ready;
}

function MapView({ items, setView, myLocation }) {
  const { fmt } = useLang();
  const ready = useLeaflet();
  const mapRef = useRef(null);
  const mapInstance = useRef(null);

  useEffect(() => {
    if (!ready || !mapRef.current || mapInstance.current || !window.L) return;
    const L = window.L;
    const center = myLocation || (items[0] && CITY_COORDS[items[0].city]) || { lat: 35.6892, lng: 51.389 };
    const map = L.map(mapRef.current).setView([center.lat, center.lng], myLocation ? 11 : 4);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "© OpenStreetMap" }).addTo(map);
    mapInstance.current = map;
    return () => { map.remove(); mapInstance.current = null; };
  }, [ready]);

  useEffect(() => {
    if (!mapInstance.current || !window.L) return;
    const L = window.L;
    const map = mapInstance.current;
    if (map._markerLayer) map._markerLayer.remove();
    const layer = L.layerGroup().addTo(map);
    map._markerLayer = layer;
    items.forEach((ad) => {
      const c = listingCoords(ad);
      if (!c) return;
      const cat = catOf(ad.category);
      const icon = L.divIcon({ html: `<div style="background:${cat.color};width:14px;height:14px;border-radius:50%;border:2px solid white;box-shadow:0 2px 6px rgba(0,0,0,.4)"></div>`, className: "", iconSize: [14, 14] });
      const marker = L.marker([c.lat, c.lng], { icon }).addTo(layer);
      marker.bindPopup(`<b>${ad.title}</b><br/>${ad.price ? fmt(ad.price) : "Negotiable"}`);
      marker.on("click", () => setView({ name: "detail", ad }));
    });
    if (myLocation) {
      const meIcon = L.divIcon({ html: `<div style="background:${LIME};width:16px;height:16px;border-radius:50%;border:3px solid white"></div>`, className: "", iconSize: [16, 16] });
      L.marker([myLocation.lat, myLocation.lng], { icon: meIcon }).addTo(layer).bindPopup("Your location");
    }
  }, [items, myLocation]);

  return (
    <div className="rounded-2xl overflow-hidden relative" style={{ border: `1px solid ${BORDER}`, height: 420, background: SURFACE }}>
      {!ready && <div className="absolute inset-0 flex items-center justify-center text-sm text-[#585C66]">Loading map...</div>}
      <div ref={mapRef} style={{ width: "100%", height: "100%" }} />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Scroll reveal helper                                               */
/* ------------------------------------------------------------------ */

function Reveal({ children, className, delay = 0 }) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) { setVisible(true); obs.unobserve(el); } });
    }, { threshold: 0.12 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(22px)",
        transition: `opacity .6s ease ${delay}ms, transform .6s ease ${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Shared bits                                                        */
/* ------------------------------------------------------------------ */

function Eyebrow({ color, children }) {
  return (
    <div className="flex items-center gap-2 mb-3">
      <span className="w-2 h-2 rounded-full" style={{ background: color || LIME, boxShadow: `0 0 8px ${color || LIME}` }} />
      <span className="text-[11px] font-extrabold tracking-[0.18em] uppercase" style={{ color: color || LIME, fontFamily: "JetBrains Mono" }}>
        {children}
      </span>
    </div>
  );
}

function Crumbs({ items, dark }) {
  const { lang } = useLang();
  const isRtl = lang === "fa";
  const linkColor = dark ? "rgba(247,244,236,.75)" : "#585C66";
  const linkHover = dark ? "#F7F4EC" : "#14181F";
  const currentColor = dark ? "#F7F4EC" : "#14181F";
  return (
    <div className="flex items-center gap-2 text-xs mb-5 flex-wrap" style={{ color: linkColor }}>
      {items.map((it, i) => (
        <React.Fragment key={i}>
          {i > 0 && (isRtl ? <ChevronLeft size={12} className="opacity-50" /> : <ChevronRight size={12} className="opacity-50" />)}
          {it.onClick ? (
            <button onClick={it.onClick} className="transition font-medium" style={{ color: linkColor }} onMouseEnter={(e) => { e.currentTarget.style.color = linkHover; }} onMouseLeave={(e) => { e.currentTarget.style.color = linkColor; }}>{it.label}</button>
          ) : (
            <span className="font-semibold" style={{ color: currentColor }}>{it.label}</span>
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

function Logo({ size = "md", tagline, beta }) {
  const big = size === "lg";
  return (
    <div className="flex items-center gap-2 select-none">
      <div className={`${big ? "w-12 h-12" : "w-9 h-9"} rounded-xl flex items-center justify-center font-black`} style={{ background: LIME, color: INK }}>
        <Zap size={big ? 22 : 17} fill={INK} />
      </div>
      <div>
        <div className="flex items-center gap-1.5">
          <span className={`text-[#14181F] leading-none ${big ? "text-3xl" : "text-xl"}`} style={{ fontFamily: SERIF, fontWeight: 800, letterSpacing: "0.04em" }}>SPENTA</span>
          {beta && (
            <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded" style={{ background: `${LIME}18`, color: LIME, letterSpacing: "0.06em", fontFamily: "JetBrains Mono" }}>BETA</span>
          )}
        </div>
        {tagline && (
          <div className="text-[10px] font-bold mt-1" style={{ color: LIME, fontFamily: "JetBrains Mono", direction: "ltr", letterSpacing: "0.04em" }}>Everything. Everywhere.</div>
        )}
      </div>
    </div>
  );
}

function CatIcon({ cat, size = 18, wrap = 36 }) {
  const Icon = cat.icon;
  return (
    <div className="rounded-xl flex items-center justify-center shrink-0" style={{ width: wrap, height: wrap, background: `${cat.color}22`, color: cat.color, border: `1px solid ${cat.color}55` }}>
      <Icon size={size} />
    </div>
  );
}

function Stars({ value, size = 13, interactive = false, onChange }) {
  const [hover, setHover] = useState(0);
  const shown = interactive ? (hover || value) : value;
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((n) => (
        <button key={n} type="button" disabled={!interactive}
          onMouseEnter={() => interactive && setHover(n)} onMouseLeave={() => interactive && setHover(0)}
          onClick={() => interactive && onChange && onChange(n)} className={interactive ? "cursor-pointer" : "cursor-default"}>
          <Star size={size} fill={n <= Math.round(shown) ? "#FBBF24" : "none"} color={n <= Math.round(shown) ? "#FBBF24" : "#D8D2C0"} />
        </button>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Trust score (display-only, mock)                                   */
/* ------------------------------------------------------------------ */

function trustProfile(owner) {
  const h = hashId(owner);
  const identity = h % 5 !== 0;
  const phone = h % 3 !== 0;
  const business = h % 4 === 0;
  const score = Math.min(99, 55 + (identity ? 18 : 0) + (phone ? 14 : 0) + (business ? 8 : 0) + (h % 6));
  return { score, identity, phone, business };
}

function useCountdown(endsAt) {
  const [remaining, setRemaining] = useState(Math.max(0, endsAt - Date.now()));
  useEffect(() => {
    const t = setInterval(() => setRemaining(Math.max(0, endsAt - Date.now())), 1000);
    return () => clearInterval(t);
  }, [endsAt]);
  const d = Math.floor(remaining / 86400000);
  const h = Math.floor((remaining % 86400000) / 3600000);
  const m = Math.floor((remaining % 3600000) / 60000);
  const s = Math.floor((remaining % 60000) / 1000);
  return { remaining, d, h, m, s, over: remaining <= 0 };
}

function TrustBadge({ owner, compact }) {
  const [open, setOpen] = useState(false);
  const t = trustProfile(owner);
  const items = [
    { label: "Identity verified", ok: t.identity },
    { label: "Verified phone number", ok: t.phone },
    { label: "Business account", ok: t.business },
  ];
  return (
    <div className="relative inline-block">
      <button onClick={(e) => { e.stopPropagation(); setOpen(!open); }} className="flex items-center gap-1 text-[11px] font-bold rounded-full px-2 py-1" style={{ background: `${LIME}18`, color: LIME }}>
        <Star size={11} fill={LIME} /> {t.score} Trust score
      </button>
      {open && !compact && (
        <div className="absolute z-20 top-full mt-1.5 right-0 w-52 rounded-xl p-3" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
          {items.map((it) => (
            <div key={it.label} className="flex items-center gap-2 text-[11px] py-1">
              <span className="w-2 h-2 rounded-full shrink-0" style={{ background: it.ok ? "#22C55E" : "#D8D2C0" }} />
              <span className={it.ok ? "text-[#14181F]" : "text-[#585C66]"}>{it.label}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PriceTrendChart({ ad, color, fmt }) {
  const data = useMemo(() => {
    if (!ad.price) return [];
    const seed = hashId(ad.id);
    const months = ["6mo ago", "5mo ago", "4mo ago", "3mo ago", "2mo ago", "1mo ago", "Now"];
    let val = ad.price * (0.88 + ((seed % 20) / 100));
    return months.map((m, i) => {
      if (i === months.length - 1) return { month: m, price: ad.price };
      const drift = (((seed >> (i * 3)) % 11) - 5) / 100; // deterministic -5%..+5%
      val = val * (1 + drift);
      return { month: m, price: Math.round(val) };
    });
  }, [ad.id, ad.price]);
  if (data.length === 0) return null;
  const min = Math.min(...data.map((d) => d.price));
  const max = Math.max(...data.map((d) => d.price));
  return (
    <div className="rounded-2xl p-5 mb-6" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
      <div className="flex items-center justify-between mb-1">
        <Eyebrow color={color}>Price trend</Eyebrow>
        <span title="Estimated trend based on similar listings — for reference only" className="text-[9px] font-bold px-2 py-0.5 rounded-full" style={{ background: SURFACE, color: "#8B8E99" }}>Estimated</span>
      </div>
      <p className="text-[11px] text-[#585C66] mb-3">Illustrative 6-month pricing trend for this category — not a guarantee of future value.</p>
      <div style={{ width: "100%", height: 120 }}>
        <ResponsiveContainer>
          <AreaChart data={data} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id={`priceGrad-${ad.id}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={color} stopOpacity={0.35} />
                <stop offset="100%" stopColor={color} stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="month" tick={{ fontSize: 9, fill: "#8B8E99" }} axisLine={false} tickLine={false} />
            <YAxis hide domain={[min * 0.9, max * 1.1]} />
            <Tooltip
              formatter={(v) => [fmt(v), "Price"]}
              contentStyle={{ fontSize: 11, borderRadius: 10, border: `1px solid ${BORDER}`, boxShadow: "0 8px 20px -8px rgba(0,0,0,.2)" }}
              labelStyle={{ fontSize: 10, color: "#585C66" }}
            />
            <Area type="monotone" dataKey="price" stroke={color} strokeWidth={2} fill={`url(#priceGrad-${ad.id})`} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function DashboardInsights({ listings }) {
  const [open, setOpen] = useState(true);
  const data = useMemo(() => {
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const seed = listings.reduce((h, l) => h + hashId(l.id), 0);
    return days.map((d, i) => {
      const base = 8 + (listings.length * 6);
      const wobble = ((seed >> (i * 3)) % 13) - 4;
      return { day: d, views: Math.max(1, base + wobble + i) };
    });
  }, [listings]);
  const totalViews = data.reduce((s, d) => s + d.views, 0);
  const avgPerListing = Math.round(totalViews / Math.max(1, listings.length));

  return (
    <div className="rounded-2xl p-5 mb-10" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
      <button onClick={() => setOpen(!open)} className="w-full flex items-center justify-between">
        <div className="flex items-center gap-1">
          <Eyebrow>Seller insights</Eyebrow>
          <span title="Estimated from simulated activity — for demo purposes" className="text-[9px] font-bold px-2 py-0.5 rounded-full ms-2" style={{ background: SURFACE, color: "#8B8E99" }}>Demo data</span>
        </div>
        <ChevronDown size={15} className="transition-transform" style={{ color: "#585C66", transform: open ? "rotate(180deg)" : "none" }} />
      </button>
      {open && (
        <div className="mt-4">
          <div className="flex items-center gap-6 mb-4">
            <div><div className="text-xl font-bold text-[#14181F]" style={{ fontFamily: SERIF }}>{totalViews}</div><div className="text-[10px] text-[#585C66] font-bold">views this week</div></div>
            <div><div className="text-xl font-bold text-[#14181F]" style={{ fontFamily: SERIF }}>{avgPerListing}</div><div className="text-[10px] text-[#585C66] font-bold">avg. per listing</div></div>
          </div>
          <div style={{ width: "100%", height: 110 }}>
            <ResponsiveContainer>
              <AreaChart data={data} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="viewsGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={LIME} stopOpacity={0.3} />
                    <stop offset="100%" stopColor={LIME} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="day" tick={{ fontSize: 9, fill: "#8B8E99" }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Tooltip formatter={(v) => [v, "Views"]} contentStyle={{ fontSize: 11, borderRadius: 10, border: `1px solid ${BORDER}` }} labelStyle={{ fontSize: 10, color: "#585C66" }} />
                <Area type="monotone" dataKey="views" stroke={LIME} strokeWidth={2} fill="url(#viewsGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
}

function Confetti({ onDone }) {
  const canvasRef = useRef(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const w = (canvas.width = window.innerWidth);
    const h = (canvas.height = window.innerHeight);
    const colors = [LIME, GOLD, "#22C55E", "#0E6B66", "#F7F4EC"];
    const pieces = Array.from({ length: 90 }, () => ({
      x: w / 2 + (Math.random() - 0.5) * 120,
      y: h * 0.35 + (Math.random() - 0.5) * 40,
      vx: (Math.random() - 0.5) * 9,
      vy: Math.random() * -9 - 3,
      size: 4 + Math.random() * 5,
      color: colors[Math.floor(Math.random() * colors.length)],
      rot: Math.random() * 360,
      vr: (Math.random() - 0.5) * 14,
      shape: Math.random() > 0.5 ? "rect" : "circle",
    }));
    let frame = 0;
    let raf;
    const tick = () => {
      frame++;
      ctx.clearRect(0, 0, w, h);
      pieces.forEach((p) => {
        p.vy += 0.28;
        p.x += p.vx;
        p.y += p.vy;
        p.rot += p.vr;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate((p.rot * Math.PI) / 180);
        ctx.fillStyle = p.color;
        if (p.shape === "rect") ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
        else { ctx.beginPath(); ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2); ctx.fill(); }
        ctx.restore();
      });
      if (frame < 110) raf = requestAnimationFrame(tick);
      else onDone && onDone();
    };
    tick();
    return () => cancelAnimationFrame(raf);
  }, []);
  return <canvas ref={canvasRef} className="fixed inset-0 z-[250] pointer-events-none" aria-hidden="true" />;
}

function SplashScreen({ visible }) {
  return (
    <div
      className="fixed inset-0 z-[400] flex items-center justify-center transition-opacity duration-500"
      style={{ background: INK, opacity: visible ? 1 : 0, pointerEvents: visible ? "auto" : "none" }}
    >
      <div className="text-center">
        <div className="font-black text-3xl mb-3" style={{ color: "#F7F4EC", fontFamily: SERIF, letterSpacing: "0.02em" }}>SPENTA</div>
        <div className="flex items-center justify-center gap-1.5">
          {[0, 1, 2].map((i) => (
            <span key={i} className="w-1.5 h-1.5 rounded-full" style={{ background: GOLD, animation: `splashDot 1s ${i * 0.15}s infinite ease-in-out` }} />
          ))}
        </div>
      </div>
    </div>
  );
}

function LiveViewers({ ad, color }) {
  const base = 3 + (hashId(ad.id) % 22);
  const [n, setN] = useState(base);
  useEffect(() => {
    const t = setInterval(() => {
      setN((v) => Math.max(2, Math.min(45, v + (Math.random() > 0.5 ? 1 : -1))));
    }, 3200 + (hashId(ad.id) % 900));
    return () => clearInterval(t);
  }, [ad.id]);
  return (
    <span title="Illustrative activity indicator — not live data" className="flex items-center gap-1 text-[10px] font-extrabold px-2 py-1 rounded-full" style={{ background: "rgba(0,0,0,.55)", color: "#fff" }}>
      <Radio size={10} color={color} className="animate-pulse" />
      {n} people viewing
    </span>
  );
}

function AdCard({ ad, onOpen, big, tilt, live, compareIds = [], onToggleCompare, wishlistIds = [], onToggleWishlist, imgHeightClass }) {
  const { t, lang, fmt } = useLang();
  const cat = catOf(ad.category);
  const [hov, setHov] = useState(false);
  const [rot, setRot] = useState({ x: 0, y: 0 });
  const [imgLoaded, setImgLoaded] = useState(false);
  const cardRef = useRef(null);
  const selected = compareIds.includes(ad.id);
  const saved = wishlistIds.includes(ad.id);
  const lotNo = String(ad.id).replace(/[^0-9]/g, "").slice(-4).padStart(4, "0");

  const onMove = (e) => {
    if (!tilt || !cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    const py = (e.clientY - rect.top) / rect.height - 0.5;
    setRot({ x: py * -8, y: px * 8 });
  };
  const onLeave = () => { setHov(false); if (tilt) setRot({ x: 0, y: 0 }); };

  return (
    <div
      ref={cardRef}
      onClick={() => onOpen(ad)}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={onLeave}
      onMouseMove={onMove}
      role="button" tabIndex={0}
      onKeyDown={(e) => { if (e.key === "Enter") onOpen(ad); }}
      className="lot-card text-start relative rounded-xl cursor-pointer overflow-hidden"
      style={{
        background: CARD,
        border: `1px solid ${hov ? `${GOLD}88` : BORDER_SOFT}`,
        transform: tilt
          ? `perspective(900px) rotateX(${rot.x}deg) rotateY(${rot.y}deg) scale(${hov ? 1.015 : 1})`
          : hov ? "translateY(-4px)" : "none",
        boxShadow: hov ? "0 20px 40px -16px rgba(20,24,31,.4)" : CARD_SHADOW,
        transition: tilt ? "transform .12s ease-out, box-shadow .25s ease, border-color .25s ease" : "transform .2s ease, box-shadow .25s ease, border-color .25s ease",
        willChange: "transform",
      }}
    >
      {/* signature: gallery-placard corner brackets, reveal on hover */}
      <span className="lot-corner lot-corner-tl" style={{ borderColor: GOLD, opacity: hov ? 1 : 0 }} />
      <span className="lot-corner lot-corner-tr" style={{ borderColor: GOLD, opacity: hov ? 1 : 0 }} />
      <span className="lot-corner lot-corner-bl" style={{ borderColor: GOLD, opacity: hov ? 1 : 0 }} />
      <span className="lot-corner lot-corner-br" style={{ borderColor: GOLD, opacity: hov ? 1 : 0 }} />

      <div className={big ? "p-3" : "p-2"}>
        <div className={`relative overflow-hidden rounded-lg ${imgHeightClass || (big ? "h-48" : "h-24")}`} style={{ background: `${cat.color}14` }}>
          {!imgLoaded && <div className="absolute inset-0 skeleton-pulse" style={{ background: `linear-gradient(90deg, ${cat.color}0f 25%, ${cat.color}22 37%, ${cat.color}0f 63%)`, backgroundSize: "400% 100%" }} />}
          <SmartImg src={ad.img} alt={ad.title || ""} onLoad={() => setImgLoaded(true)} loading="lazy" className="w-full h-full object-cover transition-transform duration-500" style={{ transform: hov ? "scale(1.06)" : "scale(1)", opacity: imgLoaded ? 1 : 0, transition: "opacity .35s ease, transform .5s ease" }} />

          {big && (
            <span className="absolute top-2 start-2 text-[9px] font-bold px-2 py-1 rounded tracking-wider" style={{ background: "rgba(20,24,31,.55)", color: "#F7F4EC", backdropFilter: "blur(4px)", fontFamily: "JetBrains Mono" }}>
              LOT {lotNo}
            </span>
          )}

          {ad.stamp && (
            <span
              className="absolute top-1.5 end-1.5 w-9 h-9 rounded-full flex flex-col items-center justify-center shadow"
              title={ad.stamp === "featured" ? "Featured" : "Verified"}
              style={{
                background: ad.stamp === "featured" ? `radial-gradient(circle at 35% 30%, ${GOLD}, ${LIME})` : "#fff",
                border: `2px solid ${ad.stamp === "featured" ? "#fff" : GOLD}`,
                boxShadow: `0 0 0 1px ${GOLD}55`,
              }}
            >
              <Sparkles size={13} color={ad.stamp === "featured" ? INK : GOLD} strokeWidth={2.5} />
            </span>
          )}
          {(onToggleCompare || onToggleWishlist) && (
            <div className="absolute top-2 start-2 flex flex-col gap-1.5 z-10" style={{ marginTop: big ? 30 : 0 }}>
              {onToggleWishlist && (
                <button onClick={(e) => { e.stopPropagation(); onToggleWishlist(ad); }} title="Add to wishlist" aria-label="Add to wishlist" aria-pressed={saved}
                  className="w-7 h-7 rounded-full flex items-center justify-center transition shadow"
                  style={saved ? { background: "#F43F5E", color: "#fff" } : { background: "rgba(8,9,13,.55)", color: "#fff", backdropFilter: "blur(4px)" }}>
                  <Heart size={11} fill={saved ? "#fff" : "none"} className={saved ? "heart-pop" : ""} />
                </button>
              )}
              {onToggleCompare && (
                <button onClick={(e) => { e.stopPropagation(); onToggleCompare(ad); }} title="Add to compare" aria-label="Add to compare" aria-pressed={selected}
                  className="w-7 h-7 rounded-full flex items-center justify-center transition shadow"
                  style={selected ? { background: LIME, color: "#fff" } : { background: "rgba(8,9,13,.55)", color: "#fff", backdropFilter: "blur(4px)" }}>
                  {selected ? <Check size={12} strokeWidth={3} /> : <Scale size={12} />}
                </button>
              )}
            </div>
          )}
          {live && <div className="absolute bottom-2 end-2"><LiveViewers ad={ad} color={cat.color} /></div>}

          {big && (
            <div className="absolute inset-0 flex items-center justify-center transition-opacity duration-300" style={{ opacity: hov ? 1 : 0, background: hov ? "rgba(8,9,13,.25)" : "transparent" }}>
              <span className="flex items-center gap-1.5 text-xs font-extrabold px-4 py-2 rounded-full" style={{ background: INK, color: "#fff" }}>
                <Eye size={13} /> Quick view
              </span>
            </div>
          )}
        </div>

        <div className={big ? "pt-3.5" : "pt-2.5"}>
          <div className={`flex items-center gap-1.5 font-bold uppercase ${big ? "text-[10px] mb-1.5" : "text-[8px] mb-1"}`} style={{ color: cat.color, letterSpacing: "0.08em" }}>
            <cat.icon size={big ? 12 : 10} />
            {catLabel(cat, lang)}
            <span className="text-[#8B8E99] font-normal normal-case" style={{ letterSpacing: 0 }}>· <MapPin size={10} className="inline -mt-0.5" /> {ad.city}</span>
          </div>
          <h3 className={`text-[#14181F] font-bold leading-snug line-clamp-2 ${big ? "text-lg mb-2" : "text-[12.5px] mb-1.5"}`}>{ad.title}</h3>
          {big && ad.description && <p className="text-[#585C66] text-xs mb-2.5 line-clamp-2">{ad.description}</p>}
          <div className="flex items-center justify-between pt-2" style={{ borderTop: `1px solid ${BORDER_SOFT}` }}>
            <span className={`font-bold text-[#14181F] ${big ? "text-2xl" : "text-[14px]"}`} style={{ fontFamily: SERIF }}>
              {ad.price ? fmt(ad.price) : t("negotiable")}
            </span>
            {big && <span className="flex items-center gap-1 text-[11px] font-bold" style={{ color: LIME }}>{t("viewDetails")} <ArrowLeft size={12} /></span>}
          </div>
        </div>
      </div>
    </div>
  );
}

function Toast({ text }) {
  if (!text) return null;
  return (
    <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[100] px-5 py-3 rounded-full text-sm shadow-2xl flex items-center gap-2 font-bold animate-[fadeIn_.2s_ease]" style={{ background: LIME, color: INK }}>
      <Check size={15} strokeWidth={3} />
      {text}
    </div>
  );
}

function Ticker({ listings, setView }) {
  const { fmt } = useLang();
  const feed = useMemo(() => [...listings].sort((a, b) => b.createdAt - a.createdAt).slice(0, 14), [listings]);
  if (feed.length === 0) return null;
  const row = [...feed, ...feed];
  return (
    <div className="ticker-wrap" style={{ background: SURFACE2, borderBottom: `1px solid ${BORDER}`, borderTop: `2px solid ${LIME}` }}>
      <div className="flex items-center">
        <div className="flex items-center gap-1.5 px-3 py-2.5 shrink-0 z-10" style={{ background: SURFACE2, borderInlineEnd: `1px solid ${BORDER}` }}>
          <span className="relative flex w-2 h-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75" style={{ background: LIME }} />
            <span className="relative inline-flex rounded-full w-2 h-2" style={{ background: LIME }} />
          </span>
          <span className="text-[10px] font-extrabold" style={{ color: LIME, fontFamily: "JetBrains Mono" }}>Live</span>
        </div>
        <div className="ticker-track">
          {row.map((ad, i) => {
            const cat = catOf(ad.category);
            return (
              <button key={i} onClick={() => setView({ name: "detail", ad })} className="flex items-center gap-2 text-xs shrink-0">
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: cat.color }} />
                <span className="text-[#585C66] font-medium">{cat.label}</span>
                <span className="text-[#14181F] font-semibold">{ad.title}</span>
                <span style={{ color: LIME, fontFamily: "JetBrains Mono" }} className="font-bold">{ad.price ? fmt(ad.price) : "Negotiable"}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Activity bar (social proof)                                        */
/* ------------------------------------------------------------------ */

function ActivityBar({ listings }) {
  const messages = useMemo(() => {
    const pool = [...listings].slice(0, 12);
    return pool.map((ad) => ({
      id: ad.id,
      text: `New listing: «${ad.title}» in ${ad.city}`,
    }));
  }, [listings]);
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setIdx((i) => (i + 1) % messages.length), 3800);
    return () => clearInterval(t);
  }, [messages.length]);
  if (messages.length === 0) return null;
  return (
    <div className="flex justify-center px-4 py-4">
      <div key={idx} className="activity-fade flex items-center gap-2.5 rounded-full px-4 py-2 max-w-full" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
        <span className="relative flex w-2 h-2 shrink-0">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-70" style={{ background: "#22C55E" }} />
          <span className="relative inline-flex rounded-full w-2 h-2" style={{ background: "#22C55E" }} />
        </span>
        <span className="text-[11px] md:text-xs text-[#2E3340] font-medium truncate">{messages[idx].text}</span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Typewriter + stats                                                 */
/* ------------------------------------------------------------------ */

function useTypewriter(words, speed = 95, pause = 1300) {
  const [index, setIndex] = useState(0);
  const [sub, setSub] = useState("");
  const [deleting, setDeleting] = useState(false);
  useEffect(() => {
    const current = words[index % words.length];
    let t;
    if (!deleting && sub.length < current.length) t = setTimeout(() => setSub(current.slice(0, sub.length + 1)), speed);
    else if (!deleting && sub.length === current.length) t = setTimeout(() => setDeleting(true), pause);
    else if (deleting && sub.length > 0) t = setTimeout(() => setSub(current.slice(0, sub.length - 1)), speed / 2);
    else { setDeleting(false); setIndex((index + 1) % words.length); }
    return () => clearTimeout(t);
  }, [sub, deleting, index]);
  return sub;
}

function CountUp({ value, duration = 1200, format }) {
  const [n, setN] = useState(0);
  const ref = useRef(null);
  const started = useRef(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting && !started.current) {
          started.current = true;
          const start = performance.now();
          const tick = (now) => {
            const p = Math.min(1, (now - start) / duration);
            const eased = 1 - Math.pow(1 - p, 3);
            setN(Math.round(value * eased));
            if (p < 1) requestAnimationFrame(tick);
          };
          requestAnimationFrame(tick);
          obs.unobserve(el);
        }
      });
    }, { threshold: 0.4 });
    obs.observe(el);
    return () => obs.disconnect();
  }, [value, duration]);
  return <span ref={ref}>{format ? format(n) : n.toLocaleString("en-US")}</span>;
}

function StatsBar({ listings }) {
  const { t } = useLang();
  const cities = new Set(listings.map((l) => l.city)).size;
  const users = 8600 + listings.length * 47;
  const stats = [
    { label: t("statAds"), value: listings.length, icon: Package },
    { label: t("statCities"), value: cities, icon: Globe2 },
    { label: t("statUsers"), value: users, icon: Users, format: (n) => n.toLocaleString("en-US") + "+" },
  ];
  return (
    <div className="flex items-center justify-center gap-6 md:gap-10 flex-wrap px-4">
      {stats.map((s) => (
        <div key={s.label} className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: `${LIME}18`, color: LIME }}>
            <s.icon size={16} />
          </div>
          <div className="text-start">
            <div className="text-lg font-black text-[#14181F]" style={{ fontFamily: "JetBrains Mono" }}>
              <CountUp value={s.value} format={s.format} />
            </div>
            <div className="text-[10px] text-[#585C66] font-bold">{s.label}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Orbit showcase — two rings (decorative)                            */
/* ------------------------------------------------------------------ */

const ORBIT_SIZE = 320;
const ORBIT_OUTER_R = 148;
const ORBIT_INNER_R = 84;

function OrbitShowcase({ listings, setView }) {
  const innerItems = useMemo(() => listings.slice(0, 8), [listings]);
  if (innerItems.length === 0) return null;
  const outerN = CAT_LIST.length;
  const innerN = innerItems.length;
  return (
    <section className="max-w-6xl mx-auto px-4 py-8 flex flex-col items-center">
      <Eyebrow>Live showcase</Eyebrow>
      <p className="text-xs text-[#585C66] mb-6">SPENTA categories and listings, live right now</p>
      <div className="orbit-outer" style={{ width: ORBIT_SIZE, height: ORBIT_SIZE }}>
        <div className="orbit-center">
          <div className="w-12 h-12 rounded-full flex items-center justify-center mb-1.5" style={{ background: `${LIME}22`, border: `1px dashed ${LIME}88` }}>
            <Globe2 size={20} color={LIME} />
          </div>
          <span className="text-[11px] font-extrabold text-[#14181F]">Global marketplace</span>
        </div>

        <div className="orbit-ring orbit-ring-outer">
          {CAT_LIST.map((c, i) => {
            const angle = (360 / outerN) * i;
            const Icon = c.icon;
            return (
              <div key={c.id} className="orbit-item" style={{ transform: `rotate(${angle}deg) translate(${ORBIT_OUTER_R}px) rotate(${-angle}deg)` }}>
                <div className="orbit-counter-outer">
                  <button onClick={() => setView({ name: "category", category: c.id })} className="orbit-chip" style={{ background: `${c.color}22`, borderColor: c.color, color: c.color }} title={c.label}>
                    <Icon size={16} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="orbit-ring orbit-ring-inner">
          {innerItems.map((ad, i) => {
            const angle = (360 / innerN) * i;
            const cat = catOf(ad.category);
            return (
              <div key={ad.id} className="orbit-item" style={{ transform: `rotate(${angle}deg) translate(${ORBIT_INNER_R}px) rotate(${-angle}deg)` }}>
                <div className="orbit-counter-inner">
                  <button onClick={() => setView({ name: "detail", ad })} className="orbit-thumb" style={{ borderColor: cat.color }} title={ad.title}>
                    <SmartImg src={ad.img} alt="" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  How it works                                                       */
/* ------------------------------------------------------------------ */

function ScrollStep({ index, total, icon: Icon, title, desc, onActive }) {
  const { lang } = useLang();
  const ref = useRef(null);
  const [active, setActive] = useState(index === 1);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([entry]) => {
      setActive(entry.isIntersecting);
      if (entry.isIntersecting) onActive(index);
    }, { rootMargin: "-42% 0px -42% 0px", threshold: 0 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return (
    <div ref={ref} className="min-h-[46vh] flex items-center justify-center text-center px-4">
      <div
        style={{
          transform: active ? "scale(1)" : "scale(0.78)",
          opacity: active ? 1 : 0.4,
          transition: "transform .5s cubic-bezier(.16,1,.3,1), opacity .5s ease",
          transformOrigin: "center center",
        }}
      >
        <div className="text-[11px] font-black mb-3 tracking-[0.2em] transition-colors duration-500" style={{ color: active ? GOLD : "#5b5d66", fontFamily: "JetBrains Mono" }}>{lang === "fa" ? `step ${index} / ${total}` : `STEP ${index} / ${total}`}</div>
        <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-5 mx-auto transition-colors duration-500" style={{ background: active ? `${GOLD}22` : "rgba(255,255,255,.04)", border: `1px solid ${active ? GOLD + "55" : "rgba(255,255,255,.08)"}`, color: active ? GOLD : "#5b5d66" }}>
          <Icon size={28} />
        </div>
        <h3 className="font-black transition-colors duration-500" style={{ fontSize: "clamp(1.4rem,4vw,2.15rem)", color: active ? "#fff" : "#6b6f80", fontFamily: "Vazirmatn", textShadow: active ? `0 0 30px ${GOLD}44` : "none" }}>
          {title}
        </h3>
        <p className="mt-3 max-w-md leading-relaxed mx-auto transition-colors duration-500" style={{ fontSize: "0.92rem", color: active ? "#D3D4DA" : "#55575f" }}>
          {desc}
        </p>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Interactive 3D globe (signature showcase)                          */
/* ------------------------------------------------------------------ */

function latLngToVector3(lat, lng, radius) {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lng + 180) * (Math.PI / 180);
  return new THREE.Vector3(
    -radius * Math.sin(phi) * Math.cos(theta),
    radius * Math.cos(phi),
    radius * Math.sin(phi) * Math.sin(theta)
  );
}

function GlobeShowcase({ listings, onSelectCity }) {
  const mountRef = useRef(null);
  const popupElRef = useRef(null);
  const [hoverCity, setHoverCity] = useState(null);
  const [selected, setSelected] = useState(null); // { city, stats }
  const selectedRef = useRef(null);

  const cityStats = useMemo(() => {
    const map = {};
    Object.keys(CITY_COORDS).forEach((city) => {
      const inCity = listings.filter((l) => l.city === city);
      const catCounts = {};
      inCity.forEach((l) => { catCounts[l.category] = (catCounts[l.category] || 0) + 1; });
      const topCatId = Object.entries(catCounts).sort((a, b) => b[1] - a[1])[0]?.[0];
      map[city] = { count: inCity.length, topCat: topCatId ? catOf(topCatId) : null };
    });
    return map;
  }, [listings]);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    let width = mount.clientWidth || 340;
    let height = mount.clientHeight || 340;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.z = 5.6;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.domElement.style.cursor = "grab";
    mount.appendChild(renderer.domElement);

    const group = new THREE.Group();
    scene.add(group);

    const radius = 2;
    const sphereGeo = new THREE.SphereGeometry(radius, 28, 20);
    const wireGeo = new THREE.WireframeGeometry(sphereGeo);
    const wireMat = new THREE.LineBasicMaterial({ color: 0x8a5c1e, transparent: true, opacity: 0.3 });
    group.add(new THREE.LineSegments(wireGeo, wireMat));

    const coreMat = new THREE.MeshBasicMaterial({ color: 0x14181f, transparent: true, opacity: 0.035 });
    group.add(new THREE.Mesh(new THREE.SphereGeometry(radius * 0.995, 32, 32), coreMat));

    const glowMat = new THREE.MeshBasicMaterial({ color: 0xe5b94e, transparent: true, opacity: 0.06, side: THREE.BackSide });
    const glowMesh = new THREE.Mesh(new THREE.SphereGeometry(radius * 1.18, 32, 32), glowMat);
    group.add(glowMesh);

    // faint latitude rings for a data-grid feel
    for (let lat = -60; lat <= 60; lat += 30) {
      const ringPts = [];
      for (let d = 0; d <= 360; d += 6) {
        ringPts.push(latLngToVector3(lat, d - 180, radius * 1.001));
      }
      const ringGeo = new THREE.BufferGeometry().setFromPoints(ringPts);
      group.add(new THREE.Line(ringGeo, new THREE.LineBasicMaterial({ color: 0x8a5c1e, transparent: true, opacity: 0.12 })));
    }

    const cityEntries = Object.entries(CITY_COORDS);
    const countByCity = {};
    listings.forEach((l) => { countByCity[l.city] = (countByCity[l.city] || 0) + 1; });

    const markers = [];
    cityEntries.forEach(([city, coord], idx) => {
      const pos = latLngToVector3(coord.lat, coord.lng, radius * 1.02);
      const count = countByCity[city] || 0;
      const size = 0.032 + Math.min(count, 12) * 0.0038;
      const dotMat = new THREE.MeshBasicMaterial({ color: 0xc8a24a });
      const dot = new THREE.Mesh(new THREE.SphereGeometry(size, 14, 14), dotMat);
      dot.position.copy(pos);
      group.add(dot);

      const halo = new THREE.Mesh(new THREE.SphereGeometry(size * 2.6, 12, 12), new THREE.MeshBasicMaterial({ color: 0xe6c789, transparent: true, opacity: 0.22 }));
      halo.position.copy(pos);
      group.add(halo);

      // invisible larger hit-target so clicking/tapping near a marker is forgiving
      // Fixed, generous hit-radius for every marker regardless of listing count —
      // previously this scaled with the (often tiny) visual dot size, making
      // low-activity markets very hard to click.
      const hitDot = new THREE.Mesh(new THREE.SphereGeometry(0.16, 10, 10), new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false }));
      hitDot.position.copy(pos);
      hitDot.userData = { city, idx, visualDot: dot };
      group.add(hitDot);
      markers.push(hitDot);
    });

    const arcLines = [];
    for (let i = 0; i < cityEntries.length; i++) {
      const [, coordA] = cityEntries[i];
      const [, coordB] = cityEntries[(i + 1) % cityEntries.length];
      const pA = latLngToVector3(coordA.lat, coordA.lng, radius);
      const pB = latLngToVector3(coordB.lat, coordB.lng, radius);
      const mid = pA.clone().add(pB).multiplyScalar(0.5).normalize().multiplyScalar(radius * 1.32);
      const curve = new THREE.QuadraticBezierCurve3(pA, mid, pB);
      const geo = new THREE.BufferGeometry().setFromPoints(curve.getPoints(40));
      const line = new THREE.Line(geo, new THREE.LineBasicMaterial({ color: 0xc8a24a, transparent: true, opacity: 0.38 }));
      group.add(line);

      const pulse = new THREE.Mesh(new THREE.SphereGeometry(0.022, 8, 8), new THREE.MeshBasicMaterial({ color: 0xfff0cf }));
      group.add(pulse);
      arcLines.push({ curve, pulse, offset: i / cityEntries.length });
    }

    let dragging = false, moved = false, lastX = 0, lastY = 0;
    let rotY = 0.4, rotX = -0.3;
    group.rotation.set(rotX, rotY, 0);

    const onDown = (e) => { dragging = true; moved = false; lastX = e.clientX; lastY = e.clientY; renderer.domElement.style.cursor = "grabbing"; };
    const onMove = (e) => {
      if (!dragging) return;
      const dx = e.clientX - lastX, dy = e.clientY - lastY;
      if (Math.abs(dx) > 4 || Math.abs(dy) > 4) moved = true;
      rotY += dx * 0.005;
      rotX = Math.max(-1.1, Math.min(1.1, rotX + dy * 0.005));
      lastX = e.clientX; lastY = e.clientY;
    };
    const onUp = () => { dragging = false; renderer.domElement.style.cursor = "grab"; };

    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    let hoveredIdx = -1;
    const onClick = (e) => {
      if (moved) return;
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouse, camera);
      const hits = raycaster.intersectObjects(markers);
      if (hits.length) {
        const city = hits[0].object.userData.city;
        const idx = hits[0].object.userData.idx;
        selectedRef.current = { city, idx };
        setSelected({ city, stats: cityStats[city] });
      } else {
        selectedRef.current = null;
        setSelected(null);
      }
    };
    const onMoveHover = (e) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouse, camera);
      const hits = raycaster.intersectObjects(markers);
      hoveredIdx = hits.length ? hits[0].object.userData.idx : -1;
      setHoverCity(hits.length ? hits[0].object.userData.city : null);
      renderer.domElement.style.cursor = hits.length ? "pointer" : (dragging ? "grabbing" : "grab");
    };

    renderer.domElement.addEventListener("pointerdown", onDown);
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    renderer.domElement.addEventListener("click", onClick);
    renderer.domElement.addEventListener("pointermove", onMoveHover);

    const worldPos = new THREE.Vector3();
    let raf;
    const clock = new THREE.Clock();
    const animate = () => {
      const t = clock.getElapsedTime();
      if (!dragging) rotY += 0.0009;
      group.rotation.set(rotX, rotY, 0);
      markers.forEach((m, i) => {
        const isHover = i === hoveredIdx;
        const isSelected = selectedRef.current && selectedRef.current.idx === i;
        const pulse = 1 + Math.sin(t * 2 + i) * 0.18;
        const visualDot = m.userData.visualDot;
        visualDot.scale.setScalar(isHover || isSelected ? pulse * 1.6 : pulse);
        visualDot.material.color.setHex(isHover || isSelected ? 0xfff0cf : 0xc8a24a);
      });
      arcLines.forEach((a) => a.pulse.position.copy(a.curve.getPointAt((t * 0.15 + a.offset) % 1)));

      if (selectedRef.current && popupElRef.current) {
        const marker = markers[selectedRef.current.idx];
        marker.getWorldPosition(worldPos);
        const projected = worldPos.clone().project(camera);
        const facingAway = worldPos.clone().normalize().dot(camera.position.clone().normalize()) < 0.12;
        const x = (projected.x * 0.5 + 0.5) * width;
        const y = (-projected.y * 0.5 + 0.5) * height;
        popupElRef.current.style.transform = `translate(-50%, calc(-100% - 14px)) translate(${x}px, ${y}px)`;
        popupElRef.current.style.opacity = facingAway ? "0" : "1";
        popupElRef.current.style.pointerEvents = facingAway ? "none" : "auto";
      }

      renderer.render(scene, camera);
      raf = requestAnimationFrame(animate);
    };
    animate();

    const onResize = () => {
      width = mount.clientWidth || 340; height = mount.clientHeight || 340;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      renderer.domElement.removeEventListener("pointerdown", onDown);
      renderer.domElement.removeEventListener("click", onClick);
      renderer.domElement.removeEventListener("pointermove", onMoveHover);
      renderer.dispose();
      if (mount.contains(renderer.domElement)) mount.removeChild(renderer.domElement);
    };
  }, [listings]);

  const totalListings = listings.length;
  const activeCities = Object.values(cityStats).filter((s) => s.count > 0).length;

  return (
    <section className="max-w-6xl mx-auto px-4 py-8 flex flex-col items-center">
      <Eyebrow>Live showcase</Eyebrow>
      <h2 className="font-black text-xl mb-1.5" style={{ color: "#14181F", fontFamily: SERIF }}>The SPENTA Globe</h2>
      <p className="text-xs text-[#585C66] mb-5">Drag to rotate. Click a market to see its stats.</p>

      <div className="flex items-center justify-center gap-5 mb-4">
        <div className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: "#22C55E" }} />
          <span className="text-[10px] font-bold" style={{ color: "#8B8E99" }}>LIVE</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-bold" style={{ color: LIME, fontFamily: "JetBrains Mono" }}>{totalListings}</span>
          <span className="text-[10px] text-[#585C66]">listings</span>
        </div>
        <span className="w-px h-3" style={{ background: BORDER }} />
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-bold" style={{ color: LIME, fontFamily: "JetBrains Mono" }}>{activeCities}</span>
          <span className="text-[10px] text-[#585C66]">markets</span>
        </div>
      </div>

      <div className="relative">
          <div ref={mountRef} style={{ width: 340, height: 340 }} />
          {hoverCity && !selected && (
            <div className="absolute top-3 left-1/2 -translate-x-1/2 text-xs font-bold px-3 py-1.5 rounded-full pointer-events-none" style={{ background: INK, color: "#F7F4EC" }}>
              {hoverCity}
            </div>
          )}
          <div
            ref={popupElRef}
            className="absolute top-0 start-0 z-20 transition-opacity duration-150"
            style={{ opacity: 0, pointerEvents: "none", width: 200 }}
          >
            {selected && (
              <div className="rounded-xl p-3.5 relative" style={{ background: "#181C24", border: `1px solid rgba(229,185,78,.35)`, boxShadow: "0 16px 32px -10px rgba(0,0,0,.6)" }}>
                <button onClick={() => { selectedRef.current = null; setSelected(null); }} aria-label="Close" className="absolute top-2 end-2 w-5 h-5 rounded-full flex items-center justify-center" style={{ color: "rgba(247,244,236,.5)" }}><X size={11} /></button>
                <div className="text-[9px] font-bold uppercase mb-1" style={{ color: GOLD, letterSpacing: "0.1em" }}>{selected.stats?.count > 0 ? "Active market" : "Market"}</div>
                <div className="text-sm font-bold mb-0.5" style={{ color: "#F7F4EC", fontFamily: SERIF }}>{selected.city}</div>
                <div className="text-[11px] mb-2.5" style={{ color: "rgba(247,244,236,.5)" }}>{CITY_COORDS[selected.city]?.country}</div>
                <div className="flex items-center justify-between text-[11px] mb-1" style={{ color: "rgba(247,244,236,.75)" }}>
                  <span>Active listings</span>
                  <span className="font-bold" style={{ fontFamily: "JetBrains Mono" }}>{selected.stats?.count ?? 0}</span>
                </div>
                {selected.stats?.topCat && (
                  <div className="flex items-center justify-between text-[11px] mb-3" style={{ color: "rgba(247,244,236,.75)" }}>
                    <span>Top category</span>
                    <span className="font-bold" style={{ color: selected.stats.topCat.color }}>{catLabel(selected.stats.topCat, "en")}</span>
                  </div>
                )}
                <button
                  onClick={() => { onSelectCity && onSelectCity(selected.city); selectedRef.current = null; setSelected(null); }}
                  className="w-full text-[11px] font-extrabold py-2 rounded-full"
                  style={{ background: GOLD, color: "#14181F" }}
                >
                  Browse listings
                </button>
                <div className="absolute left-1/2 -translate-x-1/2" style={{ bottom: -6, width: 0, height: 0, borderLeft: "6px solid transparent", borderRight: "6px solid transparent", borderTop: "6px solid #181C24" }} />
              </div>
            )}
          </div>
      </div>
    </section>
  );
}

function HowItWorks() {
  const { t } = useLang();
  const [activeIndex, setActiveIndex] = useState(1);
  const steps = [
    { icon: User, title: t("step1Title"), desc: t("step1Desc") },
    { icon: Zap, title: t("step2Title"), desc: t("step2Desc") },
    { icon: ShieldCheck, title: t("step3Title"), desc: t("step3Desc") },
  ];
  return (
    <section className="relative overflow-hidden" style={{ background: "radial-gradient(ellipse at 50% 115%, #12233d 0%, #05060A 55%, #05060A 100%)" }}>
      <div className="absolute inset-0 pointer-events-none" style={{
        backgroundImage:
          "radial-gradient(1.5px 1.5px at 12% 22%, #fff, transparent), radial-gradient(1px 1px at 28% 68%, #fff, transparent), radial-gradient(1px 1px at 45% 15%, #fff, transparent), radial-gradient(1.5px 1.5px at 62% 40%, #fff, transparent), radial-gradient(1px 1px at 78% 75%, #fff, transparent), radial-gradient(1px 1px at 88% 25%, #fff, transparent), radial-gradient(1.5px 1.5px at 8% 85%, #fff, transparent), radial-gradient(1px 1px at 95% 55%, #fff, transparent)",
        opacity: 0.5,
      }} />
      <div className="absolute bottom-0 right-0 w-full h-52 pointer-events-none" style={{ background: `radial-gradient(ellipse at 85% 100%, ${GOLD}33, transparent 62%)` }} />
      <div className="absolute bottom-0 left-0 w-2/3 h-40 pointer-events-none" style={{ background: "radial-gradient(ellipse at 10% 100%, rgba(56,120,200,.28), transparent 65%)" }} />

      <div className="relative max-w-3xl mx-auto px-4 py-16 flex gap-8">
        <div className="hidden lg:flex flex-col items-center gap-6 sticky self-start shrink-0" style={{ top: "44vh" }}>
          {steps.map((_, i) => (
            <React.Fragment key={i}>
              <span className="rounded-full transition-all duration-500" style={{ width: activeIndex === i + 1 ? 10 : 6, height: activeIndex === i + 1 ? 10 : 6, background: activeIndex === i + 1 ? GOLD : "#3a3d48", boxShadow: activeIndex === i + 1 ? `0 0 14px ${GOLD}` : "none" }} />
              {i < steps.length - 1 && <span className="w-px h-14" style={{ background: "#232631" }} />}
            </React.Fragment>
          ))}
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-center mb-6">
            <Eyebrow color={GOLD}>{t("howEyebrow")}</Eyebrow>
            <h2 className="text-[#F7F4EC] font-black text-xl" style={{ fontFamily: "Vazirmatn" }}>{t("howTitle")}</h2>
          </div>
          {steps.map((s, i) => <ScrollStep key={s.title} index={i + 1} total={steps.length} icon={s.icon} title={s.title} desc={s.desc} onActive={setActiveIndex} />)}
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  Header                                                              */
/* ------------------------------------------------------------------ */

function MenuButton({ open, onClick }) {
  return (
    <button
      onClick={onClick} aria-label="Menu"
      className="relative w-10 h-10 rounded-xl flex flex-col items-center justify-center gap-[5px] shrink-0 transition-colors duration-200"
      style={{ background: open ? LIME : SURFACE, border: `1px solid ${open ? LIME : BORDER}` }}
    >
      <span className="block rounded-full transition-all duration-300" style={{ height: 2, width: 18, background: open ? INK : "#fff", transform: open ? "translateY(7px) rotate(45deg)" : "none" }} />
      <span className="block rounded-full transition-all duration-300" style={{ height: 2, width: 12, background: open ? INK : "#fff", opacity: open ? 0 : 1 }} />
      <span className="block rounded-full transition-all duration-300" style={{ height: 2, width: open ? 18 : 9, background: open ? INK : "#fff", transform: open ? "translateY(-7px) rotate(-45deg)" : "none" }} />
    </button>
  );
}

function DrawerLink({ icon: Icon, label, onClick, disabled, badge, color }) {
  return (
    <button
      onClick={disabled ? undefined : onClick}
      className={`w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-start transition ${disabled ? "opacity-45 cursor-not-allowed" : "hover:bg-black/[0.04]"}`}
    >
      <span className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ background: color ? `${color}22` : SURFACE2, color: color || "#585C66" }}>
        <Icon size={15} />
      </span>
      <span className="text-sm text-[#14181F] font-medium flex-1">{label}</span>
      {badge ? (
        <span className="text-[9px] font-extrabold px-2 py-0.5 rounded-full" style={{ background: BORDER, color: "#585C66" }}>{badge}</span>
      ) : (
        <ChevronLeft size={13} className="text-[#585C66]" />
      )}
    </button>
  );
}

function DrawerLinkDark({ icon: Icon, label, onClick, disabled, badge, gold }) {
  return (
    <button
      onClick={disabled ? undefined : onClick}
      className={`w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-start transition ${disabled ? "opacity-40 cursor-not-allowed" : ""}`}
      style={{ background: "transparent" }}
      onMouseEnter={(e) => { if (!disabled) e.currentTarget.style.background = "rgba(247,244,236,.06)"; }}
      onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; }}
    >
      <span className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ background: gold ? "rgba(229,185,78,.15)" : "rgba(247,244,236,.08)", color: gold ? GOLD : "rgba(247,244,236,.7)" }}>
        <Icon size={15} />
      </span>
      <span className="text-sm font-medium flex-1" style={{ color: "#F7F4EC" }}>{label}</span>
      {badge ? (
        <span className="text-[9px] font-extrabold px-2 py-0.5 rounded-full" style={{ background: "rgba(247,244,236,.1)", color: "rgba(247,244,236,.5)" }}>{badge}</span>
      ) : (
        <ChevronLeft size={13} style={{ color: "rgba(247,244,236,.4)" }} />
      )}
    </button>
  );
}

function LanguagePicker() {
  const { lang, setLang, t } = useLang();
  const [open, setOpen] = useState(false);
  const current = LANGS.find((l) => l.code === lang);
  return (
    <div className="relative mb-5">
      <button onClick={() => setOpen(!open)} className="w-full flex items-center gap-2.5 rounded-xl px-3.5 py-3 text-start" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
        <span className="text-base shrink-0">{current.flag}</span>
        <span className="text-sm text-[#14181F] font-bold flex-1 truncate">{current.label}</span>
        <ChevronDown size={14} className="text-[#585C66] transition-transform shrink-0" style={{ transform: open ? "rotate(180deg)" : "none" }} />
      </button>
      {open && (
        <div className="mt-1.5 rounded-xl overflow-hidden max-h-60 overflow-y-auto" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
          {LANGS.map((l) => (
            <button key={l.code} onClick={() => { setLang(l.code); setOpen(false); }} className="w-full flex items-center gap-2.5 text-start px-3.5 py-2.5 text-sm hover:bg-black/[0.04] transition" style={{ color: lang === l.code ? LIME : INK, fontWeight: lang === l.code ? 800 : 500 }}>
              <span className="text-base">{l.flag}</span> {l.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function CurrencyPicker() {
  const { currency, setCurrency } = useLang();
  const [open, setOpen] = useState(false);
  const current = CURRENCIES.find((c) => c.code === currency);
  return (
    <div className="relative mb-5">
      <button onClick={() => setOpen(!open)} className="w-full flex items-center gap-2.5 rounded-xl px-3.5 py-3 text-start" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
        <span className="w-6 h-6 rounded-full flex items-center justify-center text-[11px] font-black shrink-0" style={{ background: `${LIME}18`, color: LIME }}>{current.symbol}</span>
        <span className="text-sm text-[#14181F] font-bold flex-1 truncate">{current.code}</span>
        <ChevronDown size={14} className="text-[#585C66] transition-transform shrink-0" style={{ transform: open ? "rotate(180deg)" : "none" }} />
      </button>
      {open && (
        <div className="mt-1.5 rounded-xl overflow-hidden" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
          {CURRENCIES.map((c) => (
            <button key={c.code} onClick={() => { setCurrency(c.code); setOpen(false); }} className="w-full flex items-center gap-2.5 text-start px-3.5 py-2.5 text-sm hover:bg-black/[0.04] transition" style={{ color: currency === c.code ? LIME : INK, fontWeight: currency === c.code ? 800 : 500 }}>
              <span className="w-5 text-center">{c.symbol}</span> {c.code}
            </button>
          ))}
          <div className="px-3.5 pb-2.5 pt-1 text-[10px] text-[#585C66]">Rates are approximate, for display only</div>
        </div>
      )}
    </div>
  );
}

function LocationPicker({ value, onChange }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative mb-5">
      <button onClick={() => setOpen(!open)} className="w-full flex items-center gap-2.5 rounded-xl px-3.5 py-3 text-start" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
        <MapPin size={16} color={LIME} className="shrink-0" />
        <span className="text-sm text-[#14181F] font-bold flex-1 truncate">{value}</span>
        <ChevronDown size={14} className="text-[#585C66] transition-transform shrink-0" style={{ transform: open ? "rotate(180deg)" : "none" }} />
      </button>
      {open && (
        <div className="mt-1.5 rounded-xl overflow-hidden max-h-52 overflow-y-auto" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
          {["All cities", ...CITIES].map((c) => (
            <button key={c} onClick={() => { onChange(c); setOpen(false); }} className="w-full text-start px-3.5 py-2.5 text-sm hover:bg-black/[0.04] transition" style={{ color: value === c ? LIME : INK, fontWeight: value === c ? 800 : 500 }}>{c}</button>
          ))}
        </div>
      )}
    </div>
  );
}

const ROMAN = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII"];

function NavGroup({ group, index, expanded, onToggle, go }) {
  return (
    <div style={{ borderBottom: `1px solid rgba(247,244,236,.12)` }}>
      <button onClick={onToggle} className="w-full flex items-center gap-4 sm:gap-6 py-4 sm:py-5 text-start group">
        <span className="text-[11px] sm:text-xs font-bold shrink-0 w-6 sm:w-8" style={{ color: expanded ? GOLD : "rgba(247,244,236,.4)", fontFamily: "JetBrains Mono" }}>{ROMAN[index]}</span>
        <span className="text-2xl sm:text-4xl flex-1 font-bold transition-colors" style={{ color: expanded ? GOLD : "#F7F4EC", fontFamily: SERIF }}>{group.label}</span>
        <span className="text-[10px] sm:text-xs shrink-0 hidden sm:inline" style={{ color: "rgba(247,244,236,.35)" }}>{String(group.subs.length).padStart(2, "0")} sections</span>
        <ChevronDown size={18} className="shrink-0 transition-transform" style={{ color: expanded ? GOLD : "rgba(247,244,236,.4)", transform: expanded ? "rotate(180deg)" : "none" }} />
      </button>
      <div className="overflow-hidden transition-all duration-300" style={{ maxHeight: expanded ? 200 : 0, opacity: expanded ? 1 : 0 }}>
        <div className="flex flex-wrap gap-2 pb-5">
          {group.subs.map((s) => (
            <button
              key={s.label}
              onClick={() => go({ name: "category", category: s.cat })}
              className="text-xs sm:text-sm font-medium rounded-full px-3.5 py-1.5 transition"
              style={{ border: `1px solid rgba(247,244,236,.2)`, color: "rgba(247,244,236,.8)" }}
              onMouseEnter={(e) => { e.currentTarget.style.borderColor = GOLD; e.currentTarget.style.color = GOLD; }}
              onMouseLeave={(e) => { e.currentTarget.style.borderColor = "rgba(247,244,236,.2)"; e.currentTarget.style.color = "rgba(247,244,236,.8)"; }}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

const ONBOARDING_SLIDES = [
  { icon: Globe2, title: "Welcome to SPENTA", desc: "The global marketplace for everything — Homes, cars, motorcycles, jobs, goods and services — all in one showcase." },
  { icon: Search, title: "Smart search", desc: "Just type what you're looking for, in plain language — for example «BMW 2022 under $30k near Berlin»." },
  { icon: Scale, title: "Compare & Wishlist", desc: "Put a few similar listings side by side, or save your favorites for later." },
  { icon: Plus, title: "Post a Free Ad", desc: "Publish your listing in minutes — completely free, with a quick review from the SPENTA team." },
];

function OnboardingTour({ onClose }) {
  const [i, setI] = useState(0);
  const slide = ONBOARDING_SLIDES[i];
  const last = i === ONBOARDING_SLIDES.length - 1;
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4" style={{ background: "rgba(8,9,13,.75)" }}>
      <div
        key={i}
        className="w-full max-w-sm rounded-2xl p-8 text-center relative overflow-hidden"
        style={{ background: `radial-gradient(ellipse 140% 100% at 30% -20%, #1E2430 0%, ${INK} 60%)`, boxShadow: "0 40px 80px -20px rgba(0,0,0,.5)", animation: "popIn .3s cubic-bezier(.22,1,.36,1)" }}
      >
        <span className="lot-corner lot-corner-tl" style={{ borderColor: GOLD, opacity: 1, top: 14, insetInlineStart: 14 }} />
        <span className="lot-corner lot-corner-tr" style={{ borderColor: GOLD, opacity: 1, top: 14, insetInlineEnd: 14 }} />
        <span className="lot-corner lot-corner-bl" style={{ borderColor: GOLD, opacity: 1, bottom: 14, insetInlineStart: 14 }} />
        <span className="lot-corner lot-corner-br" style={{ borderColor: GOLD, opacity: 1, bottom: 14, insetInlineEnd: 14 }} />

        <div className="flex justify-between items-center mb-6">
          <span className="text-[10px] font-bold" style={{ color: "rgba(247,244,236,.4)", fontFamily: "JetBrains Mono" }}>{String(i + 1).padStart(2, "0")} / {String(ONBOARDING_SLIDES.length).padStart(2, "0")}</span>
          <button onClick={onClose} className="text-xs font-bold" style={{ color: "rgba(247,244,236,.5)" }}>Dismiss</button>
        </div>
        <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6" style={{ border: `1px solid rgba(229,185,78,.4)`, color: GOLD }}>
          <slide.icon size={26} />
        </div>
        <h2 className="text-2xl font-bold mb-3" style={{ fontFamily: SERIF, color: "#F7F4EC" }}>{slide.title}</h2>
        <p className="text-sm leading-relaxed mb-8" style={{ color: "rgba(247,244,236,.6)" }}>{slide.desc}</p>
        <div className="flex items-center justify-center gap-1.5 mb-7">
          {ONBOARDING_SLIDES.map((_, idx) => (
            <span key={idx} className="rounded-full transition-all" style={{ width: idx === i ? 18 : 6, height: 6, background: idx === i ? GOLD : "rgba(247,244,236,.2)" }} />
          ))}
        </div>
        <button onClick={() => (last ? onClose() : setI(i + 1))} className="w-full font-extrabold text-sm py-3.5 rounded-full" style={{ background: GOLD, color: INK }}>
          {last ? "Let's get started" : "Next"}
        </button>
      </div>
    </div>
  );
}

function SideDrawer({ open, onClose, setView, user, selectedCity, onSelectCity }) {
  const [expandedGroup, setExpandedGroup] = useState(null);
  const { t, lang } = useLang();
  const isRtl = lang === "fa";
  const go = (v) => { setView(v); onClose(); };
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  return (
    <>
      <div
        onClick={onClose}
        className="fixed inset-0 z-40 transition-opacity duration-300"
        style={{ background: "rgba(0,0,0,.6)", opacity: open ? 1 : 0, pointerEvents: open ? "auto" : "none" }}
      />
      <div
        className="fixed top-0 start-0 h-full w-full z-50 flex flex-col transition-transform duration-[400ms]"
        style={{
          background: `radial-gradient(ellipse 120% 90% at 20% -10%, #1E2430 0%, ${INK} 55%)`,
          transform: open ? "translateX(0)" : (isRtl ? "translateX(100%)" : "translateX(-100%)"),
          transitionTimingFunction: "cubic-bezier(.22,1,.36,1)",
        }}
      >
        <div className="max-w-3xl w-full mx-auto flex flex-col h-full px-5 sm:px-8">
          <div className="flex items-center justify-between py-5 sm:py-7 shrink-0">
            <span className="font-black text-lg tracking-tight" style={{ color: "#F7F4EC", fontFamily: SERIF }}>SPENTA</span>
            <button onClick={onClose} aria-label="Close menu" className="w-10 h-10 rounded-full flex items-center justify-center transition" style={{ border: `1px solid rgba(247,244,236,.25)`, color: "#F7F4EC" }}>
              <X size={17} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto pb-8">
            <div className="text-[10px] font-bold uppercase mb-1" style={{ color: GOLD, letterSpacing: "0.18em" }}>Directory</div>
            <div>
              {NAV_GROUPS.map((g, i) => (
                <div key={g.label} style={{ animation: open ? `dirRow .5s cubic-bezier(.22,1,.36,1) both` : "none", animationDelay: `${i * 45}ms` }}>
                  <NavGroup group={g} index={i} expanded={expandedGroup === g.label} onToggle={() => setExpandedGroup(expandedGroup === g.label ? null : g.label)} go={go} />
                </div>
              ))}
            </div>

            <button onClick={() => go({ name: "post" })} className="w-full flex items-center justify-center gap-2 font-extrabold text-sm py-3.5 rounded-full mt-6 mb-8" style={{ background: GOLD, color: INK }}>
              <Plus size={16} strokeWidth={3} /> {t("postAd")}
            </button>

            <div className="grid sm:grid-cols-3 gap-3 mb-8">
              <div className="rounded-xl p-3" style={{ background: "rgba(247,244,236,.06)" }}>
                <div className="text-[9px] font-bold uppercase mb-1.5" style={{ color: "rgba(247,244,236,.45)", letterSpacing: "0.1em" }}>{t("drawerLanguage")}</div>
                <LanguagePicker />
              </div>
              <div className="rounded-xl p-3" style={{ background: "rgba(247,244,236,.06)" }}>
                <div className="text-[9px] font-bold uppercase mb-1.5" style={{ color: "rgba(247,244,236,.45)", letterSpacing: "0.1em" }}>Currency</div>
                <CurrencyPicker />
              </div>
              <div className="rounded-xl p-3" style={{ background: "rgba(247,244,236,.06)" }}>
                <div className="text-[9px] font-bold uppercase mb-1.5" style={{ color: "rgba(247,244,236,.45)", letterSpacing: "0.1em" }}>{t("drawerLocation")}</div>
                <LocationPicker value={selectedCity} onChange={onSelectCity} />
              </div>
            </div>

            {user ? (
              <button onClick={() => go({ name: "dashboard" })} className="w-full flex items-center gap-3 rounded-2xl p-3.5 mb-5 text-start" style={{ background: "rgba(247,244,236,.06)", border: `1px solid rgba(247,244,236,.12)` }}>
                <span className="w-11 h-11 rounded-full flex items-center justify-center font-extrabold shrink-0" style={{ background: GOLD, color: INK }}>{user.name.slice(0, 1)}</span>
                <div className="flex-1 min-w-0"><div className="text-sm font-bold truncate" style={{ color: "#F7F4EC" }}>{user.name}</div><div className="text-[11px]" style={{ color: "rgba(247,244,236,.5)" }}>{t("drawerAccount")}</div></div>
                <ChevronLeft size={15} style={{ color: "rgba(247,244,236,.5)" }} />
              </button>
            ) : (
              <button onClick={() => go({ name: "auth" })} className="w-full flex items-center gap-3 rounded-2xl p-3.5 mb-5 text-start" style={{ background: "rgba(247,244,236,.06)", border: `1px solid rgba(247,244,236,.12)` }}>
                <span className="w-11 h-11 rounded-full flex items-center justify-center shrink-0" style={{ background: "rgba(229,185,78,.15)", color: GOLD }}><User size={18} /></span>
                <div className="flex-1 min-w-0"><div className="text-sm font-bold" style={{ color: "#F7F4EC" }}>{t("accountTitle")}</div><div className="text-[11px]" style={{ color: "rgba(247,244,236,.5)" }}>{t("drawerLoginSignup")}</div></div>
                <ChevronLeft size={15} style={{ color: "rgba(247,244,236,.5)" }} />
              </button>
            )}

            <div className="text-[10px] font-bold uppercase mb-2" style={{ color: "rgba(247,244,236,.4)", letterSpacing: "0.14em" }}>{t("drawerOtherMarkets")}</div>
            <div className="space-y-1 mb-6">
              <DrawerLinkDark icon={Coins} label="Currency & Gold Market" onClick={() => go({ name: "market" })} />
            </div>

            <div className="text-[10px] font-bold uppercase mb-2" style={{ color: "rgba(247,244,236,.4)", letterSpacing: "0.14em" }}>SPENTA</div>
            <div className="space-y-1">
              <DrawerLinkDark icon={Info} label={t("drawerAbout")} onClick={() => go({ name: "about" })} />
              <DrawerLinkDark icon={Briefcase} label={t("drawerCareers")} onClick={() => go({ name: "careers" })} />
              <DrawerLinkDark icon={BookOpen} label="SPENTA Magazine" onClick={() => go({ name: "magazine" })} />
              <DrawerLinkDark icon={Package} label="Live market stats" onClick={() => go({ name: "stats" })} />
              <DrawerLinkDark icon={Mail} label={t("drawerContact")} onClick={() => go({ name: "support" })} />
              <DrawerLinkDark icon={Scale} label="Terms & Conditions" onClick={() => go({ name: "terms" })} />
              <DrawerLinkDark icon={ShieldCheck} label="Privacy" onClick={() => go({ name: "privacy" })} />
              {isAdminUser(user) && <DrawerLinkDark icon={ShieldCheck} label="Admin panel" gold onClick={() => go({ name: "admin" })} />}
            </div>

            <div className="pt-8 pb-2 text-[10px] text-center" style={{ color: "rgba(247,244,236,.3)" }}>© SPENTA</div>
          </div>
        </div>
      </div>
    </>
  );
}

function Header({ setView, user, query, setQuery, wishlistCount, menuOpen, onMenuClick, newMatchesCount, themeMode, onToggleTheme, savedSearches = [], recomputeMatches, onOpenSearch, listings = [], onOpenPalette }) {
  const { t } = useLang();
  const [notifOpen, setNotifOpen] = useState(false);
  const [suggestOpen, setSuggestOpen] = useState(false);
  const notifRef = useRef(null);
  useEffect(() => {
    const onClick = (e) => { if (notifRef.current && !notifRef.current.contains(e.target)) setNotifOpen(false); };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);
  const suggestions = useMemo(() => {
    if (!query.trim() || query.trim().length < 2) return [];
    const q = query.trim().toLowerCase();
    const titleMatches = listings.filter((l) => l.title.toLowerCase().includes(q)).slice(0, 5);
    const catMatches = CAT_LIST.filter((c) => catLabel(c, "en").toLowerCase().includes(q)).slice(0, 2);
    return { titleMatches, catMatches };
  }, [query, listings]);
  const runSearch = () => {
    setView({ name: "home" });
    setTimeout(() => {
      const el = document.getElementById("results");
      if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 60);
  };
  return (
    <header className="sticky top-0 z-40 backdrop-blur" style={{ background: `${PAGE_BG}EE`, borderBottom: `1px solid ${BORDER}` }}>
      <div className="max-w-6xl mx-auto px-4 py-3.5 flex items-center gap-4">
        <MenuButton open={menuOpen} onClick={onMenuClick} />
        <button onClick={() => setView({ name: "home" })}><Logo beta /></button>
        <div className="flex-1 hidden md:block relative max-w-md mx-auto">
          <div className="flex items-center gap-2 rounded-full px-4 py-2.5" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
            <button onClick={runSearch} aria-label="Search" className="shrink-0"><Search size={16} className="text-[#585C66]" /></button>
            <input
              value={query}
              onChange={(e) => { setQuery(e.target.value); setSuggestOpen(true); }}
              onFocus={() => setSuggestOpen(true)}
              onBlur={() => setTimeout(() => setSuggestOpen(false), 150)}
              onKeyDown={(e) => { if (e.key === "Enter") { runSearch(); setSuggestOpen(false); } }}
              placeholder={t("searchPlaceholder")}
              role="combobox" aria-expanded={suggestOpen} aria-autocomplete="list"
              className="bg-transparent outline-none text-sm text-[#14181F] placeholder:text-[#585C66] flex-1"
            />
            <button onClick={onOpenPalette} className="hidden lg:flex items-center gap-0.5 text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0" style={{ background: CARD, border: `1px solid ${BORDER}`, color: "#8B8E99", fontFamily: "JetBrains Mono" }}>⌘K</button>
          </div>
          {suggestOpen && query.trim().length >= 2 && (suggestions.titleMatches?.length > 0 || suggestions.catMatches?.length > 0) && (
            <div className="absolute top-full inset-x-0 mt-2 rounded-2xl overflow-hidden z-50" style={{ background: CARD, border: `1px solid ${BORDER}`, boxShadow: "0 20px 40px -16px rgba(20,24,31,.25)" }}>
              {suggestions.catMatches?.map((c) => (
                <button key={c.id} onMouseDown={() => { setView({ name: "category", category: c.id }); setSuggestOpen(false); }} className="w-full flex items-center gap-2.5 px-4 py-2.5 text-start hover:bg-black/[0.03]">
                  <c.icon size={14} style={{ color: c.color }} />
                  <span className="text-sm text-[#14181F] font-bold">{catLabel(c, "en")}</span>
                  <span className="text-[10px] font-bold ms-auto" style={{ color: "#8B8E99" }}>Category</span>
                </button>
              ))}
              {suggestions.titleMatches?.map((l) => (
                <button key={l.id} onMouseDown={() => { setView({ name: "detail", ad: l }); setSuggestOpen(false); }} className="w-full flex items-center gap-2.5 px-4 py-2.5 text-start hover:bg-black/[0.03]" style={{ borderTop: `1px solid ${BORDER_SOFT}` }}>
                  <SmartImg src={l.img} alt="" className="w-8 h-8 rounded-md object-cover shrink-0" />
                  <span className="text-sm text-[#14181F] truncate">{l.title}</span>
                </button>
              ))}
            </div>
          )}
        </div>
        <button onClick={onToggleTheme} title={themeMode === "dark" ? "Light mode" : "Dark mode"} className="hidden sm:flex items-center justify-center w-10 h-10 rounded-full shrink-0" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
          {themeMode === "dark" ? <Sun size={16} color={LIME} /> : <Moon size={16} color="#585C66" />}
        </button>
        <div className="hidden sm:block relative" ref={notifRef}>
          <button onClick={() => setNotifOpen((v) => !v)} title={t("savedSearches")} aria-label="Notifications" aria-expanded={notifOpen} className="relative flex items-center justify-center w-10 h-10 rounded-full shrink-0" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
            <Bell size={16} color={newMatchesCount > 0 ? LIME : "#585C66"} />
            {newMatchesCount > 0 && (
              <span className="absolute -top-1 -left-1 min-w-[16px] h-4 px-1 rounded-full text-[9px] font-extrabold flex items-center justify-center" style={{ background: LIME, color: "#fff" }}>{newMatchesCount}</span>
            )}
          </button>
          {notifOpen && (
            <div className="absolute top-full end-0 mt-2 w-80 max-w-[85vw] rounded-2xl overflow-hidden z-50" style={{ background: CARD, border: `1px solid ${BORDER}`, boxShadow: "0 20px 40px -16px rgba(20,24,31,.25)" }}>
              <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: `1px solid ${BORDER_SOFT}` }}>
                <span className="text-sm font-bold text-[#14181F]">Notifications</span>
                <button onClick={() => { setNotifOpen(false); setView({ name: "saved-searches" }); }} className="text-[11px] font-bold" style={{ color: LIME }}>See all</button>
              </div>
              <div className="max-h-80 overflow-y-auto">
                {savedSearches.length === 0 ? (
                  <div className="px-4 py-8 text-center">
                    <p className="text-xs text-[#585C66]">No saved searches yet. Save one from any category page to get notified.</p>
                  </div>
                ) : (() => {
                  const withCounts = savedSearches.map((s) => ({ s, count: recomputeMatches ? recomputeMatches(s) : s.seenCount }));
                  const withNew = withCounts.filter(({ s, count }) => count > s.seenCount);
                  const rest = withCounts.filter(({ s, count }) => count <= s.seenCount);
                  const ordered = [...withNew, ...rest].slice(0, 6);
                  return ordered.map(({ s, count }) => {
                    const cat = catOf(s.categoryId);
                    const hasNew = count > s.seenCount;
                    return (
                      <button key={s.id} onClick={() => { onOpenSearch && onOpenSearch(s.id); setNotifOpen(false); setView({ name: "category", category: s.categoryId }); }} className="w-full flex items-center gap-3 px-4 py-3 text-start hover:bg-black/[0.03]" style={{ borderBottom: `1px solid ${BORDER_SOFT}` }}>
                        <CatIcon cat={cat} size={14} wrap={32} />
                        <div className="flex-1 min-w-0">
                          <div className="text-[13px] text-[#14181F] font-bold truncate">{s.label}</div>
                          <div className="text-[11px] text-[#585C66]">{hasNew ? <span style={{ color: LIME, fontWeight: 700 }}>{count - s.seenCount} new match{count - s.seenCount > 1 ? "es" : ""}</span> : `${count} matching listing${count === 1 ? "" : "s"}`}</div>
                        </div>
                        {hasNew && <span className="w-2 h-2 rounded-full shrink-0" style={{ background: "#F43F5E" }} />}
                      </button>
                    );
                  });
                })()}
              </div>
            </div>
          )}
        </div>
        <button onClick={() => setView({ name: "wishlist" })} title={t("wishlist")} className="relative flex items-center justify-center w-10 h-10 rounded-full shrink-0" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
          <Heart size={16} color={wishlistCount > 0 ? "#F43F5E" : "#585C66"} fill={wishlistCount > 0 ? "#F43F5E" : "none"} />
          {wishlistCount > 0 && (
            <span className="absolute -top-1 -left-1 min-w-[16px] h-4 px-1 rounded-full text-[9px] font-extrabold flex items-center justify-center" style={{ background: "#F43F5E", color: "#fff" }}>{wishlistCount}</span>
          )}
        </button>
        <button onClick={() => setView({ name: "post" })} className="hidden sm:flex items-center gap-1.5 font-extrabold text-sm px-4 py-2.5 rounded-full hover:brightness-110 transition" style={{ background: LIME, color: INK }}>
          <Plus size={16} strokeWidth={3} /> {t("postAd")}
        </button>
        {user ? (
          <button onClick={() => setView({ name: "dashboard" })} className="flex items-center gap-2 rounded-full ps-3 pe-1 py-1 text-sm text-[#14181F] font-semibold" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
            <span className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-extrabold" style={{ background: LIME, color: INK }}>{user.name.slice(0, 1)}</span>
            {user.name}
          </button>
        ) : (
          <button onClick={() => setView({ name: "auth" })} className="flex items-center gap-1.5 text-sm text-[#14181F] font-semibold rounded-full px-4 py-2.5 hover:brightness-125 transition" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
            <User size={15} /> {t("login")}
          </button>
        )}
      </div>
    </header>
  );
}

/* ------------------------------------------------------------------ */
/*  Home                                                                */
/* ------------------------------------------------------------------ */

function Home({ listings, setView, query, setQuery, compareIds, onToggleCompare, wishlistIds, onToggleWishlist, selectedCity, onSelectCity, recentIds = [] }) {
  const { t, lang, fmt } = useLang();
  const word = useTypewriter(lang === "fa" ? ["خونه", "خودرو", "موتور", "شغل", "کالا", "خدمت"] : ["home", "vehicle", "job", "goods", "service"]);
  const parsedQuery = useMemo(() => parseSmartQuery(query), [query]);
  const smartActive = !!(parsedQuery && (parsedQuery.maxPrice || parsedQuery.year || parsedQuery.city));

  const filtered = useMemo(() => {
    let arr = listings;
    if (selectedCity && selectedCity !== "All cities") arr = arr.filter((l) => l.city === selectedCity);
    if (query) {
      if (smartActive) {
        arr = arr.filter((l) => {
          if (parsedQuery.maxPrice && l.price > 0 && l.price > parsedQuery.maxPrice) return false;
          if (parsedQuery.city && l.city !== parsedQuery.city) return false;
          if (parsedQuery.year) {
            const yf = l.fields?.year ? String(l.fields.year) : "";
            if (yf !== parsedQuery.year && !l.title.includes(parsedQuery.year)) return false;
          }
          if (parsedQuery.keyword) {
            const kw = parsedQuery.keyword.toLowerCase();
            const hay = (l.title + " " + (l.fields?.brand || "")).toLowerCase();
            if (!hay.includes(kw)) return false;
          }
          return true;
        });
      } else {
        arr = arr.filter((l) => l.title.includes(query) || l.city.includes(query));
      }
    }
    return arr;
  }, [listings, query, selectedCity, smartActive, parsedQuery]);

  const scrollToResults = () => {
    const el = document.getElementById("results");
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const featured = filtered.filter((l) => l.stamp);
  const spotlight = featured[0];
  const sideFeatured = featured.slice(1, 3);
  const recent = [...filtered].sort((a, b) => b.createdAt - a.createdAt).slice(0, 15);
  const heights = ["h-28", "h-36", "h-44", "h-32"];
  const recentlyViewed = useMemo(() => recentIds.map((id) => listings.find((l) => l.id === id)).filter(Boolean), [recentIds, listings]);

  const heroImages = useMemo(() => {
    const seen = new Set();
    const picks = [];
    for (const l of listings) {
      if (picks.length >= 5) break;
      if (seen.has(l.category)) continue;
      seen.add(l.category);
      picks.push(l);
    }
    return picks;
  }, [listings]);
  const [heroTilt, setHeroTilt] = useState({ x: 0, y: 0 });
  const heroRef = useRef(null);
  const onHeroMove = (e) => {
    if (!heroRef.current) return;
    const rect = heroRef.current.getBoundingClientRect();
    setHeroTilt({ x: ((e.clientX - rect.left) / rect.width - 0.5) * 2, y: ((e.clientY - rect.top) / rect.height - 0.5) * 2 });
  };
  const HERO_LAYOUT = [
    { top: "8%", start: "3%", rot: -9, size: 92, depth: 0.5, delay: "0s" },
    { top: "58%", start: "1%", rot: 6, size: 74, depth: 0.8, delay: "1.1s" },
    { top: "4%", end: "2%", rot: 8, size: 84, depth: 0.6, delay: "0.5s" },
    { top: "56%", end: "4%", rot: -7, size: 96, depth: 0.4, delay: "1.7s" },
    { top: "80%", start: "24%", rot: 4, size: 64, depth: 0.9, delay: "2.3s" },
  ];

  return (
    <div>
      <section ref={heroRef} onMouseMove={onHeroMove} className="relative overflow-hidden" style={{ borderBottom: `1px solid ${BORDER}` }}>
        <div className="absolute top-0 inset-x-0 h-px" style={{ background: `linear-gradient(90deg, transparent, ${LIME}88, transparent)` }} />
        <div className="absolute -top-56 left-1/2 -translate-x-1/2 w-[900px] h-96 rounded-full blur-[140px] opacity-[0.07] pointer-events-none" style={{ background: LIME }} />

        <div className="hidden lg:block absolute inset-0 pointer-events-none">
          {heroImages.map((ad, i) => {
            const pos = HERO_LAYOUT[i];
            if (!pos) return null;
            return (
              <div
                key={ad.id}
                className="absolute rounded-xl overflow-hidden hero-float"
                style={{
                  top: pos.top, left: pos.start, right: pos.end,
                  width: pos.size, height: pos.size * 1.15,
                  transform: `rotate(${pos.rot}deg) translate(${heroTilt.x * pos.depth * -14}px, ${heroTilt.y * pos.depth * -14}px)`,
                  transition: "transform .25s ease-out",
                  border: `3px solid #fff`,
                  boxShadow: "0 16px 32px -10px rgba(20,24,31,.25)",
                  animationDelay: pos.delay,
                  opacity: 0.92,
                }}
              >
                <SmartImg src={ad.img} alt="" className="w-full h-full object-cover" />
              </div>
            );
          })}
        </div>

        <div className="max-w-6xl mx-auto px-4 pt-14 md:pt-20 pb-8 relative text-center">
          <div className="flex justify-center mb-5">
            <div className="flex items-center gap-1.5 text-xs font-extrabold rounded-full px-3.5 py-1.5" style={{ background: `${LIME}18`, color: LIME, border: `1px solid ${LIME}55` }}>
              <Zap size={12} /> {t("heroBadge")}
            </div>
          </div>
          {lang === "fa" ? (
            <h1 className="font-black text-[#14181F] text-3xl md:text-5xl leading-[1.15] mb-4 tracking-tight" style={{ fontFamily: "Vazirmatn" }}>
              هر <span style={{ color: CYAN }}>{word}</span><span className="type-cursor">|</span>ی که دنبالشی،
              <br />
              <span style={{ color: LIME }}>یکجا</span> پیدا کن
            </h1>
          ) : (
            <h1 className="text-[#14181F] text-3xl md:text-5xl leading-[1.15] mb-4 tracking-tight" style={{ fontFamily: SERIF, fontWeight: 800 }}>{t("heroTitle")}</h1>
          )}
          <p className="text-[#585C66] text-sm md:text-base max-w-xl mx-auto mb-7 leading-relaxed">
            {t("heroSub")}
          </p>
          <form onSubmit={(e) => { e.preventDefault(); scrollToResults(); }} className="flex items-center gap-2 rounded-full px-4 py-2.5 max-w-lg mx-auto" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
            <Search size={16} className="text-[#585C66] shrink-0" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t("searchPlaceholderHero")} className="bg-transparent outline-none text-sm text-[#14181F] placeholder:text-[#585C66] flex-1 min-w-0" style={{ direction: "auto" }} />
            <button type="submit" className="font-extrabold text-xs px-4 py-2 rounded-full shrink-0" style={{ background: LIME, color: INK }}>{t("searchBtn")}</button>
          </form>
          {smartActive && (
            <div className="flex items-center justify-center gap-1.5 flex-wrap mt-3">
              <span className="text-[10px] text-[#585C66] font-bold">Detected:</span>
              {parsedQuery.keyword && <span className="text-[10px] font-bold px-2 py-1 rounded-full" style={{ background: `${LIME}18`, color: LIME }}>{parsedQuery.keyword}</span>}
              {parsedQuery.year && <span className="text-[10px] font-bold px-2 py-1 rounded-full" style={{ background: `${CYAN}18`, color: CYAN }}>yr {parsedQuery.year}</span>}
              {parsedQuery.maxPrice && <span className="text-[10px] font-bold px-2 py-1 rounded-full" style={{ background: `${LIME}18`, color: LIME }}>Max {fmt(parsedQuery.maxPrice)}</span>}
              {parsedQuery.city && <span className="text-[10px] font-bold px-2 py-1 rounded-full flex items-center gap-1" style={{ background: `${CYAN}18`, color: CYAN }}><MapPin size={10} /> {parsedQuery.city}</span>}
            </div>
          )}
        </div>
        <StatsBar listings={listings} />
        <ActivityBar listings={listings} />
      </section>

      <GlobeShowcase listings={listings} onSelectCity={(city) => { if (onSelectCity) onSelectCity(city); scrollToResults(); }} />

      <Reveal>
        <section className="max-w-6xl mx-auto px-4 py-12">
          <Eyebrow>{t("categoriesEyebrow")}</Eyebrow>
          <h2 className="text-[#14181F] font-black text-2xl mb-7" style={{ fontFamily: SERIF }}>{t("categoriesTitle")}</h2>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-px" style={{ background: BORDER_SOFT, border: `1px solid ${BORDER_SOFT}` }}>
            {CAT_LIST.map((c, i) => {
              const Icon = c.icon;
              const count = listings.filter((l) => l.category === c.id).length;
              return (
                <button key={c.id} onClick={() => setView({ name: "category", category: c.id })}
                  className="flex items-start gap-4 p-5 text-start transition group relative"
                  style={{ background: CARD }}
                  onMouseEnter={(e) => { e.currentTarget.style.background = SURFACE2; }}
                  onMouseLeave={(e) => { e.currentTarget.style.background = CARD; }}>
                  <span className="text-[10px] font-bold shrink-0 mt-1" style={{ color: c.color, fontFamily: "JetBrains Mono" }}>{String(i + 1).padStart(2, "0")}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2.5 mb-1">
                      <Icon size={15} style={{ color: c.color }} />
                      <span className="text-[15px] font-bold" style={{ color: "#14181F", fontFamily: SERIF }}>{catLabel(c, lang)}</span>
                    </div>
                    <p className="text-[11.5px] text-[#585C66] line-clamp-1 mb-2.5">{c.desc}</p>
                    <div className="flex items-center gap-1.5">
                      <span className="w-5 h-px" style={{ background: c.color }} />
                      <span className="text-[10px] font-bold" style={{ color: c.color }}>{count} listed</span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </section>
      </Reveal>

      <HowItWorks />

      {recentlyViewed.length > 0 && (
        <section className="max-w-6xl mx-auto px-4 py-6">
          <Eyebrow>Just for you</Eyebrow>
          <h2 className="text-[#14181F] font-black text-xl mb-4" style={{ fontFamily: SERIF }}>Recently viewed</h2>
          <div className="flex gap-4 overflow-x-auto pb-2 -mx-4 px-4" style={{ scrollSnapType: "x mandatory" }}>
            {recentlyViewed.map((ad) => (
              <div key={ad.id} className="shrink-0 w-40 sm:w-48" style={{ scrollSnapAlign: "start" }}>
                <AdCard ad={ad} onOpen={(ad) => setView({ name: "detail", ad })} compareIds={compareIds} onToggleCompare={onToggleCompare} wishlistIds={wishlistIds} onToggleWishlist={onToggleWishlist} />
              </div>
            ))}
          </div>
        </section>
      )}

      {spotlight && (
        <Reveal>
          <section className="max-w-6xl mx-auto px-4 py-8">
            <Eyebrow>{t("featuredEyebrow")}</Eyebrow>
            <h2 className="text-[#14181F] font-black text-xl mb-5" style={{ fontFamily: "Vazirmatn" }}>{t("featuredTitle")}</h2>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="md:col-span-2">
                <AdCard ad={spotlight} onOpen={(ad) => setView({ name: "detail", ad })} big tilt live compareIds={compareIds} onToggleCompare={onToggleCompare} wishlistIds={wishlistIds} onToggleWishlist={onToggleWishlist} />
              </div>
              <div className="grid grid-rows-2 gap-4">
                {sideFeatured.map((ad) => <AdCard key={ad.id} ad={ad} onOpen={(ad) => setView({ name: "detail", ad })} live compareIds={compareIds} onToggleCompare={onToggleCompare} wishlistIds={wishlistIds} onToggleWishlist={onToggleWishlist} />)}
              </div>
            </div>
          </section>
        </Reveal>
      )}

      <section id="results" className="max-w-6xl mx-auto px-4 py-8 pb-24 scroll-mt-20">
        <Eyebrow>{t("recentEyebrow")}</Eyebrow>
        <div className="flex items-center gap-2.5 flex-wrap mb-5">
          <h2 className="text-[#14181F] font-black text-xl" style={{ fontFamily: "Vazirmatn" }}>{t("recentTitle")}</h2>
          {selectedCity && selectedCity !== "All cities" && (
            <span className="flex items-center gap-1.5 text-[11px] font-bold px-2.5 py-1 rounded-full" style={{ background: `${LIME}18`, color: LIME }}>
              <MapPin size={11} /> {selectedCity}
            </span>
          )}
        </div>
        {recent.length === 0 ? (
          <div className="text-center py-16 rounded-2xl" style={{ border: `1px dashed ${BORDER}` }}>
            <p className="text-[#585C66] text-sm mb-4">
              {query ? <>No listings found for “{query}”{selectedCity && selectedCity !== "All cities" ? ` in ${selectedCity}` : ""}.</> : "No listings found for this search."}
            </p>
            {(query || (selectedCity && selectedCity !== "All cities")) && (
              <button onClick={() => { setQuery(""); onSelectCity("All cities"); }} className="text-xs font-extrabold px-4 py-2 rounded-full" style={{ background: LIME, color: "#fff" }}>Clear search & filters</button>
            )}
          </div>
        ) : (
          <div className="masonry">
            {recent.map((ad, i) => (
              <div key={ad.id} className="masonry-item">
                <Reveal delay={(i % 5) * 70}>
                  <AdCard ad={ad} onOpen={(ad) => setView({ name: "detail", ad })} imgHeightClass={heights[hashId(ad.id) % heights.length]} compareIds={compareIds} onToggleCompare={onToggleCompare} wishlistIds={wishlistIds} onToggleWishlist={onToggleWishlist} />
                </Reveal>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Category browse                                                    */
/* ------------------------------------------------------------------ */

function CategoryView({ categoryId, listings, setView, compareIds, onToggleCompare, wishlistIds, onToggleWishlist, initialCity, onSaveSearch }) {
  const { fmt } = useLang();
  const cat = catOf(categoryId);
  const [city, setCity] = useState(initialCity || "All");
  const [sort, setSort] = useState("new");
  const [fieldFilters, setFieldFilters] = useState({});
  const [showMap, setShowMap] = useState(false);
  const [radiusKm, setRadiusKm] = useState(50);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [saveSearchOpen, setSaveSearchOpen] = useState(false);
  const [searchLabel, setSearchLabel] = useState("");
  const geo = useGeolocation();

  const catAll = useMemo(() => listings.filter((l) => l.category === categoryId), [listings, categoryId]);
  const priceCeil = useMemo(() => Math.max(0, ...catAll.map((l) => l.price)), [catAll]);
  const [priceMin, setPriceMin] = useState(0);
  const [priceMax, setPriceMax] = useState(priceCeil);
  useEffect(() => { setPriceMax(priceCeil); setPriceMin(0); }, [priceCeil]);

  const fieldDefs = FIELDS_BY_CATEGORY[categoryId] || [];
  const distinctValues = (key) => [...new Set(catAll.map((l) => l.fields?.[key]).filter(Boolean))];

  const activeFilterCount =
    (city !== "All" ? 1 : 0) +
    (priceMax < priceCeil ? 1 : 0) +
    (priceMin > 0 ? 1 : 0) +
    Object.values(fieldFilters).filter((v) => v && v !== "All").length +
    (geo.coords ? 1 : 0);

  const clearFilters = () => {
    setCity("All"); setPriceMin(0); setPriceMax(priceCeil); setFieldFilters({});
  };

  const items = useMemo(() => {
    let arr = catAll;
    if (city !== "All") arr = arr.filter((l) => l.city === city);
    if (priceCeil > 0) arr = arr.filter((l) => l.price === 0 || (l.price <= priceMax && l.price >= priceMin));
    fieldDefs.forEach((f) => {
      const val = fieldFilters[f.key];
      if (val && val !== "All") arr = arr.filter((l) => l.fields?.[f.key] === val);
    });
    if (geo.coords) {
      arr = arr.filter((l) => {
        const c = listingCoords(l);
        if (!c) return false;
        return haversine(geo.coords.lat, geo.coords.lng, c.lat, c.lng) <= radiusKm;
      });
    }
    if (sort === "new") arr = [...arr].sort((a, b) => b.createdAt - a.createdAt);
    if (sort === "priceAsc") arr = [...arr].sort((a, b) => a.price - b.price);
    if (sort === "priceDesc") arr = [...arr].sort((a, b) => b.price - a.price);
    return arr;
  }, [catAll, city, sort, priceMax, priceMin, priceCeil, fieldFilters, fieldDefs, geo.coords, radiusKm]);

  return (
    <div>
      <div className="relative h-44 md:h-56 overflow-hidden" style={{ borderBottom: `1px solid ${BORDER}` }}>
        <SmartImg src={`https://picsum.photos/seed/cat-${categoryId}/1600/500`} alt="" role="presentation" className="absolute inset-0 w-full h-full object-cover" style={{ filter: "saturate(0.7)" }} />
        <div className="absolute inset-0" style={{ background: `linear-gradient(180deg, rgba(20,24,31,.35) 0%, rgba(20,24,31,.75) 100%)` }} />
        <div className="absolute inset-0" style={{ background: `linear-gradient(90deg, ${cat.color}33, transparent 60%)` }} />
        <div className="relative h-full max-w-6xl mx-auto px-4 flex flex-col justify-end pb-6">
          <Crumbs items={[{ label: "Home", onClick: () => setView({ name: "home" }) }, { label: cat.label }]} dark />
          <div className="flex items-center gap-4">
            <span className="w-14 h-14 rounded-2xl flex items-center justify-center shrink-0" style={{ background: "rgba(247,244,236,.12)", backdropFilter: "blur(6px)", border: `1px solid rgba(247,244,236,.2)` }}>
              <cat.icon size={24} color="#F7F4EC" />
            </span>
            <div>
              <h1 className="text-2xl md:text-4xl font-bold" style={{ color: "#F7F4EC", fontFamily: SERIF }}>{cat.label}</h1>
              <p className="text-sm mt-1" style={{ color: "rgba(247,244,236,.75)" }}>{items.length} Active listing {cat.model === "commission" ? `· ${cat.rate}` : "· flat subscription"}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8 pb-24">
        <div className="flex items-center justify-between flex-wrap gap-2 mb-5">
          <div className="flex items-center gap-2 flex-wrap">
            <button onClick={() => setFiltersOpen(!filtersOpen)} className="flex items-center gap-1.5 text-xs font-bold px-3.5 py-1.5 rounded-full transition"
              style={filtersOpen || activeFilterCount > 0 ? { background: INK, color: "#fff" } : { background: SURFACE, color: "#585C66", border: `1px solid ${BORDER}` }}>
              <SlidersHorizontal size={12} /> Filters {activeFilterCount > 0 && <span className="rounded-full w-4 h-4 flex items-center justify-center text-[9px]" style={{ background: GOLD, color: INK }}>{activeFilterCount}</span>}
            </button>
            {[["new", "Newest"], ["priceAsc", "Cheapest"], ["priceDesc", "Most expensive"]].map(([v, l]) => (
              <button key={v} onClick={() => setSort(v)} className="text-xs font-bold px-3.5 py-1.5 rounded-full transition"
                style={sort === v ? { background: cat.color, color: "#fff" } : { background: SURFACE, color: "#585C66", border: `1px solid ${BORDER}` }}>{l}</button>
            ))}
            <button onClick={() => setShowMap(!showMap)} className="flex items-center gap-1.5 text-xs font-bold px-3.5 py-1.5 rounded-full transition"
              style={showMap ? { background: INK, color: "#fff" } : { background: SURFACE, color: "#585C66", border: `1px solid ${BORDER}` }}>
              <MapPin size={12} /> {showMap ? "List view" : "Show on map"}
            </button>
          </div>
          {onSaveSearch && (
            <button onClick={() => { setSearchLabel(`${cat.label}${city !== "All" ? " · " + city : ""}`); setSaveSearchOpen(true); }} className="flex items-center gap-1.5 text-xs font-bold px-3.5 py-1.5 rounded-full" style={{ background: `${cat.color}18`, color: cat.color }}>
              <Bell size={12} /> Save this search
            </button>
          )}
        </div>

        {saveSearchOpen && (
          <div role="dialog" aria-modal="true" aria-label="Name this search" className="fixed inset-0 z-[100] flex items-center justify-center p-4" style={{ background: "rgba(8,9,13,.6)" }} onClick={() => setSaveSearchOpen(false)}>
            <div className="w-full max-w-xs rounded-2xl p-6" style={{ background: CARD, boxShadow: "0 30px 60px -20px rgba(0,0,0,.4)" }} onClick={(e) => e.stopPropagation()}>
              <h3 className="text-base font-bold text-[#14181F] mb-1" style={{ fontFamily: SERIF }}>Name this search</h3>
              <p className="text-xs text-[#585C66] mb-4">We'll notify you when a matching new listing appears</p>
              <input autoFocus value={searchLabel} onChange={(e) => setSearchLabel(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && searchLabel.trim()) { onSaveSearch({ categoryId, city, priceMax, matchCount: items.length, label: searchLabel.trim() }); setSaveSearchOpen(false); } }} placeholder="e.g. Two-bedroom apartment, city center" className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none mb-4" style={{ background: SURFACE, border: `1px solid ${BORDER}` }} />
              <div className="flex gap-2">
                <button onClick={() => setSaveSearchOpen(false)} className="flex-1 text-[#14181F] text-sm font-bold py-2.5 rounded-full" style={{ border: `1px solid ${BORDER}` }}>Cancel</button>
                <button onClick={() => { if (!searchLabel.trim()) return; onSaveSearch({ categoryId, city, priceMax, matchCount: items.length, label: searchLabel.trim() }); setSaveSearchOpen(false); }} disabled={!searchLabel.trim()} className="flex-1 font-extrabold text-sm py-2.5 rounded-full disabled:opacity-30" style={{ background: cat.color, color: "#fff" }}>Save</button>
              </div>
            </div>
          </div>
        )}

        {filtersOpen && (
          <div className="rounded-2xl p-5 mb-6" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold" style={{ color: "#14181F" }}>Filters</span>
              {activeFilterCount > 0 && <button onClick={clearFilters} className="text-[11px] font-bold" style={{ color: cat.color }}>Clear all</button>}
            </div>

            <button onClick={geo.request} disabled={geo.status === "loading"} className="flex items-center gap-1.5 text-xs font-bold px-3.5 py-1.5 rounded-full transition mb-4"
              style={geo.coords ? { background: LIME, color: "#fff" } : { background: SURFACE, color: "#585C66", border: `1px solid ${BORDER}` }}>
              <Navigation size={12} /> {geo.status === "loading" ? "Finding your location..." : geo.coords ? "Near me is active" : "Near me"}
            </button>
            {geo.coords && (
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-[#585C66]">within a radius of</span>
                  <span className="text-sm font-black" style={{ color: cat.color, fontFamily: "JetBrains Mono" }}>{radiusKm} km away</span>
                </div>
                <input type="range" min={5} max={500} step={5} value={radiusKm} onChange={(e) => setRadiusKm(Number(e.target.value))} className="w-full" style={{ accentColor: cat.color }} />
              </div>
            )}
            {geo.status === "denied" && <p className="text-xs text-[#585C66] mb-4">Location access was denied or is unavailable.</p>}

            <div className="text-xs font-bold text-[#585C66] mb-2">Filter by city</div>
            <div className="flex flex-wrap gap-2 mb-5">
              {["All", ...CITIES].map((c) => (
                <button key={c} onClick={() => setCity(c)} className="text-xs font-bold px-3.5 py-1.5 rounded-full transition"
                  style={city === c ? { background: cat.color, color: "#fff" } : { background: SURFACE, color: "#585C66", border: `1px solid ${BORDER}` }}>{c}</button>
              ))}
            </div>

            {fieldDefs.filter((f) => f.type !== "number").map((f) => {
              const options = f.type === "select" ? f.options : distinctValues(f.key);
              if (options.length === 0) return null;
              return (
                <div key={f.key} className="mb-5">
                  <div className="text-xs font-bold text-[#585C66] mb-2">{f.label}</div>
                  <div className="flex flex-wrap gap-2">
                    <button onClick={() => setFieldFilters({ ...fieldFilters, [f.key]: "All" })} className="text-xs font-bold px-3.5 py-1.5 rounded-full transition"
                      style={!fieldFilters[f.key] || fieldFilters[f.key] === "All" ? { background: INK, color: "#fff" } : { background: SURFACE, color: "#585C66", border: `1px solid ${BORDER}` }}>All</button>
                    {options.map((o) => (
                      <button key={o} onClick={() => setFieldFilters({ ...fieldFilters, [f.key]: o })} className="text-xs font-bold px-3.5 py-1.5 rounded-full transition"
                        style={fieldFilters[f.key] === o ? { background: cat.color, color: "#fff" } : { background: SURFACE, color: "#585C66", border: `1px solid ${BORDER}` }}>{o}</button>
                    ))}
                  </div>
                </div>
              );
            })}

            {priceCeil > 0 && (
              <div>
                <div className="flex items-center justify-between mb-2.5">
                  <span className="text-xs font-bold text-[#585C66]">Price range</span>
                  <span className="text-sm font-black" style={{ color: cat.color, fontFamily: "JetBrains Mono" }}>
                    {fmt(priceMin)} – {priceMax >= priceCeil ? "Unlimited" : fmt(priceMax)}
                  </span>
                </div>
                <div className="relative h-6 flex items-center">
                  <div className="absolute inset-x-0 h-1 rounded-full" style={{ background: BORDER }} />
                  <div className="absolute h-1 rounded-full" style={{ background: cat.color, insetInlineStart: `${(priceMin / priceCeil) * 100}%`, insetInlineEnd: `${100 - (priceMax / priceCeil) * 100}%` }} />
                  <input
                    type="range" min={0} max={priceCeil} step={Math.max(1, Math.round(priceCeil / 200))}
                    value={priceMin} onChange={(e) => setPriceMin(Math.min(Number(e.target.value), priceMax))}
                    className="dual-range" style={{ accentColor: cat.color }}
                  />
                  <input
                    type="range" min={0} max={priceCeil} step={Math.max(1, Math.round(priceCeil / 200))}
                    value={priceMax} onChange={(e) => setPriceMax(Math.max(Number(e.target.value), priceMin))}
                    className="dual-range" style={{ accentColor: cat.color }}
                  />
                </div>
                <div className="flex items-center justify-between text-[10px] text-[#585C66] mt-1" style={{ fontFamily: "JetBrains Mono" }}>
                  <span>$0</span>
                  <span>{fmt(priceCeil)}</span>
                </div>
              </div>
            )}
          </div>
        )}

        {items.length === 0 ? (
          <div className="text-center py-20 rounded-2xl" style={{ border: `1px dashed ${BORDER}` }}>
            <p className="text-[#585C66] mb-5">No listings found for this filter yet.</p>
            <button onClick={() => setView({ name: "post" })} className="font-extrabold text-sm px-5 py-2.5 rounded-full" style={{ background: LIME, color: INK }}>Post the first listing in this category</button>
          </div>
        ) : showMap ? (
          <MapView items={items} setView={setView} myLocation={geo.coords} />
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {items.map((ad) => <AdCard key={ad.id} ad={ad} onOpen={(ad) => setView({ name: "detail", ad })} compareIds={compareIds} onToggleCompare={onToggleCompare} wishlistIds={wishlistIds} onToggleWishlist={onToggleWishlist} />)}
          </div>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Ad detail                                                          */
/* ------------------------------------------------------------------ */

function Panel({ children, style }) {
  return <div className="rounded-2xl p-5 md:p-6 mb-5" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW, ...style }}>{children}</div>;
}

const AMENITY_POOL = [
  { icon: BookOpen, label: "School" },
  { icon: Navigation, label: "Metro station" },
  { icon: ShieldCheck, label: "Hospital" },
  { icon: Package, label: "Shopping center" },
  { icon: Globe2, label: "City park" },
];

function NeighborhoodPanel({ ad, cat }) {
  const items = useMemo(() => {
    const h = hashId(ad.id);
    return AMENITY_POOL.map((a, i) => {
      const dist = ((h >> (i * 3)) % 18) / 10 + 0.1;
      return { ...a, distance: dist < 1 ? `${Math.round(dist * 1000)} m` : `${dist.toFixed(1)} km` };
    }).sort((a, b) => parseFloat(a.distance) - parseFloat(b.distance)).slice(0, 4);
  }, [ad.id]);
  return (
    <Panel>
      <Eyebrow color={cat.color}>Nearby amenities</Eyebrow>
      <div className="grid grid-cols-2 gap-3">
        {items.map((a) => (
          <div key={a.label} className="flex items-center gap-2.5 rounded-xl p-3" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
            <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ background: `${cat.color}18`, color: cat.color }}><a.icon size={15} /></div>
            <div className="min-w-0">
              <div className="text-xs text-[#14181F] font-bold truncate">{a.label}</div>
              <div className="text-[10px] text-[#585C66]">{a.distance}</div>
            </div>
          </div>
        ))}
      </div>
      <p className="text-[10px] text-[#585C66] mt-3">Distances are approximate and for display only.</p>
    </Panel>
  );
}

function AuctionPanel({ ad, cat, user, setAd, setView, showToast, fmt }) {
  const { d, h, m, s, over } = useCountdown(ad.auction.endsAt);
  const [bidAmount, setBidAmount] = useState("");
  const bids = ad.auction.bids || [];
  const topBidder = bids[0]?.bidder;

  const submitBid = () => {
    if (!user) { setView({ name: "auth" }); return; }
    const val = Number(bidAmount);
    if (!val || val <= ad.auction.currentBid) { showToast("Your bid must be higher than the current bid"); return; }
    const bid = { id: "bid" + Date.now(), bidder: user.name, amount: val, at: Date.now() };
    setAd({ ...ad, auction: { ...ad.auction, currentBid: val, bids: [bid, ...bids] } });
    setBidAmount("");
    showToast("Your bid was submitted");
  };

  return (
    <div className="mb-5">
      <div className="flex items-center gap-1.5 mb-2">
        <span className="w-1.5 h-1.5 rounded-full" style={{ background: over ? "#585C66" : "#F43F5E" }} />
        <span className="text-[11px] font-extrabold" style={{ color: over ? "#585C66" : "#F43F5E", fontFamily: "JetBrains Mono" }}>{over ? "Auction ended" : "Active auction"}</span>
      </div>
      <div className="font-black text-3xl text-[#14181F] mb-1" style={{ fontFamily: "JetBrains Mono" }}>{fmt(ad.auction.currentBid)}</div>
      <div className="text-xs text-[#585C66] mb-3">{bids.length > 0 ? `Latest bid from ${topBidder}` : "No bids yet — Starting price"}</div>

      {!over ? (
        <div className="grid grid-cols-4 gap-1.5 mb-4">
          {[["day", d], ["hour", h], ["min", m], ["sec", s]].map(([label, val]) => (
            <div key={label} className="rounded-lg py-2 text-center" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
              <div className="text-base font-black text-[#14181F]" style={{ fontFamily: "JetBrains Mono" }}>{String(val).padStart(2, "0")}</div>
              <div className="text-[9px] text-[#585C66]">{label}</div>
            </div>
          ))}
        </div>
      ) : (
        <div className="rounded-lg p-3 mb-4 text-center text-xs font-bold" style={{ background: `${cat.color}14`, color: cat.color }}>
          {topBidder ? `Winner: ${topBidder}` : "No bids yet"}
        </div>
      )}

      {!over && (
        <div className="flex items-center gap-1.5 mb-4">
          <input value={bidAmount} onChange={(e) => setBidAmount(e.target.value)} type="number" placeholder={`over ${fmt(ad.auction.currentBid)}`}
            className="flex-1 min-w-0 rounded-full px-3.5 py-2.5 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}`, fontFamily: "JetBrains Mono" }} />
          <button onClick={submitBid} className="font-extrabold text-sm px-4 py-2.5 rounded-full shrink-0" style={{ background: cat.color, color: INK }}>Place bid</button>
        </div>
      )}

      {bids.length > 0 && (
        <div className="space-y-1.5 mb-2">
          {bids.slice(0, 3).map((b) => (
            <div key={b.id} className="flex items-center justify-between text-xs">
              <span className="text-[#585C66]">{b.bidder}</span>
              <span className="font-bold text-[#14181F]" style={{ fontFamily: "JetBrains Mono" }}>{fmt(b.amount)}</span>
            </div>
          ))}
        </div>
      )}
      <div className="pt-3" style={{ borderTop: `1px solid ${BORDER}` }} />
    </div>
  );
}

function NotFoundView({ setView }) {
  return (
    <div className="max-w-md mx-auto px-4 py-24 text-center">
      <div className="text-[64px] font-black mb-2 leading-none" style={{ color: BORDER, fontFamily: SERIF }}>404</div>
      <h1 className="text-xl font-bold text-[#14181F] mb-2" style={{ fontFamily: SERIF }}>This page doesn't exist</h1>
      <p className="text-sm text-[#585C66] mb-7">The listing or page you're looking for may have been removed, or the link is broken.</p>
      <div className="flex items-center justify-center gap-2">
        <button onClick={() => setView({ name: "home" })} className="font-extrabold text-sm px-5 py-2.5 rounded-full" style={{ background: LIME, color: "#fff" }}>Back to home</button>
        <button onClick={() => setView({ name: "support" })} className="font-bold text-sm px-5 py-2.5 rounded-full" style={{ border: `1px solid ${BORDER}`, color: "#14181F" }}>Contact us</button>
      </div>
    </div>
  );
}

function DetailView({ ad: initialAd, listings = [], setView, user, showToast, compareIds, onToggleCompare, wishlistIds, onToggleWishlist }) {
  const { fmt, lang } = useLang();
  const [ad, setAd] = useState(initialAd);
  const [phoneShown, setPhoneShown] = useState(false);
  const [newStars, setNewStars] = useState(0);
  const [newComment, setNewComment] = useState("");
  const [chatInput, setChatInput] = useState("");
  const [showShare, setShowShare] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [reportSent, setReportSent] = useState(false);
  const [buyerName, setBuyerName] = useState("");
  const [buyerStars, setBuyerStars] = useState(0);
  const [buyerComment, setBuyerComment] = useState("");
  const [messages, setMessages] = useState(() => [
    { id: "m0", from: "them", text: "Hi! This listing is still available and ready to view.", at: Date.now() - 3600000 },
  ]);
  const cat = catOf(ad.category);
  const coords = CITY_COORDS[ad.city];
  const gallery = ad.images && ad.images.length ? ad.images : [ad.img];
  const [activeImg, setActiveImg] = useState(0);
  const [galleryLoaded, setGalleryLoaded] = useState(false);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  useEffect(() => { setGalleryLoaded(false); }, [activeImg, ad.id]);
  useEffect(() => {
    if (!lightboxOpen) return;
    const isRtl = lang === "fa";
    const onKey = (e) => {
      if (e.key === "Escape") { setLightboxOpen(false); return; }
      if (gallery.length <= 1) return;
      const forwardKey = isRtl ? "ArrowLeft" : "ArrowRight";
      const backKey = isRtl ? "ArrowRight" : "ArrowLeft";
      if (e.key === forwardKey) setActiveImg((i) => (i + 1) % gallery.length);
      else if (e.key === backKey) setActiveImg((i) => (i - 1 + gallery.length) % gallery.length);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lightboxOpen, lang, gallery.length]);
  const isOwner = user && user.name === ad.owner;
  const shareUrl = `https://spenta.market/ad/${ad.id}`;

  const similar = listings
    .filter((l) => l.id !== ad.id && l.category === ad.category)
    .sort((a, b) => (a.city === ad.city ? -1 : 0) - (b.city === ad.city ? -1 : 0))
    .slice(0, 4);

  const buyerAggregate = (() => {
    const items = ad.buyerReviews?.items || [];
    if (items.length === 0) return null;
    const avg = items.reduce((s, r) => s + r.stars, 0) / items.length;
    return { avg, count: items.length };
  })();

  const submitBuyerReview = () => {
    if (!buyerName.trim() || !buyerStars) return;
    const item = { id: "b" + Date.now(), buyerName: buyerName.trim(), stars: buyerStars, text: buyerComment.trim() };
    const items = [item, ...(ad.buyerReviews?.items || [])];
    setAd({ ...ad, buyerReviews: { items } });
    setBuyerName(""); setBuyerStars(0); setBuyerComment("");
    showToast("Your rating for this buyer was submitted");
  };

  const copyLink = async () => {
    try { await navigator.clipboard.writeText(shareUrl); showToast("Link copied"); } catch (e) { showToast("Copy failed — Copy the link manually"); }
  };

  const submitReport = (reason) => {
    setReportSent(true);
    showToast("Your report has been submitted to the SPENTA team");
  };

  const [bidModalOpen, setBidModalOpen] = useState(false);
  const [bidValue, setBidValue] = useState("");
  const sendChat = (text) => {
    if (!user) { setView({ name: "auth" }); return; }
    if (!text.trim()) return;
    setMessages((m) => [...m, { id: "m" + Date.now(), from: "me", text: text.trim(), at: Date.now() }]);
    setChatInput("");
  };
  const openBidModal = () => {
    if (!user) { setView({ name: "auth" }); return; }
    setBidValue("");
    setBidModalOpen(true);
  };
  const confirmBid = () => {
    const val = Number(bidValue);
    if (!bidValue || isNaN(val) || val <= 0) return;
    setMessages((m) => [...m, { id: "m" + Date.now(), from: "me", offer: val, at: Date.now() }]);
    setBidModalOpen(false);
  };
  const attachPhoto = () => showToast("Photo attached");
  const voiceMsg = () => showToast("Voice message sent");
  const reportUser = () => showToast("Your report has been submitted to the SPENTA team");
  const blockUser = () => showToast(`${ad.owner} blocked`);

  const submitReview = () => {
    if (!user) { setView({ name: "auth" }); return; }
    if (!newStars || !newComment.trim()) return;
    const item = { id: "r" + Date.now(), user: user.name, stars: newStars, text: newComment.trim() };
    const items = [item, ...(ad.reviews?.items || [])];
    const count = (ad.reviews?.count || 0) + 1;
    const avg = ((ad.reviews?.avg || 0) * (ad.reviews?.count || 0) + newStars) / count;
    setAd({ ...ad, reviews: { avg, count, items } });
    setNewStars(0);
    setNewComment("");
    showToast("Your review was submitted");
  };

  const reviews = ad.reviews || { avg: 0, count: 0, items: [] };

  const lotNo = String(ad.id).replace(/[^0-9]/g, "").slice(-4).padStart(4, "0");

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 pb-24">
      <div className="print-cert" style={{ fontFamily: SERIF, color: "#14181F", padding: "24px 8px" }}>
        <div className="flex items-center justify-between pb-4 mb-6" style={{ borderBottom: `2px solid ${INK}` }}>
          <span className="font-black text-xl" style={{ letterSpacing: "0.04em" }}>SPENTA</span>
          <span className="text-xs" style={{ fontFamily: "JetBrains Mono" }}>LOT №{lotNo}</span>
        </div>
        <SmartImg src={gallery[0]} alt={ad.title} style={{ width: "100%", maxHeight: 360, objectFit: "cover", marginBottom: 20, border: `1px solid ${BORDER}` }} />
        <div className="text-xs font-bold uppercase mb-1.5" style={{ color: "#585C66", letterSpacing: "0.12em" }}>{catLabel(cat, "en")} · {ad.city}</div>
        <h1 className="text-3xl font-bold mb-3">{ad.title}</h1>
        <div className="text-2xl font-bold mb-5 pb-3" style={{ borderBottom: `1px solid ${BORDER}` }}>{ad.price ? fmt(ad.price) : "Negotiable"}</div>
        {ad.description && <p className="text-sm leading-relaxed mb-6" style={{ color: "#3A3F4D" }}>{ad.description}</p>}
        {ad.fields && Object.keys(ad.fields).length > 0 && (
          <table style={{ width: "100%", fontSize: 12, marginBottom: 24, borderCollapse: "collapse" }}>
            <tbody>
              {Object.entries(ad.fields).filter(([, v]) => v).map(([k, v]) => (
                <tr key={k} style={{ borderBottom: `1px solid ${BORDER}` }}>
                  <td style={{ padding: "6px 0", color: "#585C66", width: "40%" }}>{k}</td>
                  <td style={{ padding: "6px 0", fontWeight: 600 }}>{String(v)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        <div className="flex items-center justify-between pt-4 text-[10px]" style={{ borderTop: `1px solid ${BORDER}`, color: "#585C66", fontFamily: "JetBrains Mono" }}>
          <span>spenta.market/ad/{ad.id}</span>
          <span>Printed {new Date().toLocaleDateString()}</span>
        </div>
      </div>

      <div className="no-print">
      <Crumbs items={[
        { label: "Home", onClick: () => setView({ name: "home" }) },
        { label: cat.label, onClick: () => setView({ name: "category", category: ad.category }) },
        { label: ad.title },
      ]} />

      <div className="grid md:grid-cols-5 gap-6">
        <div className="md:col-span-3">
          <div className="relative rounded-2xl overflow-hidden mb-3" style={{ border: `1px solid ${BORDER}` }}>
            {!galleryLoaded && <div className="absolute inset-0 skeleton-pulse" style={{ background: `linear-gradient(90deg, ${cat.color}0f 25%, ${cat.color}22 37%, ${cat.color}0f 63%)`, backgroundSize: "400% 100%" }} />}
            <SmartImg src={gallery[activeImg]} alt={ad.title || ""} onLoad={() => setGalleryLoaded(true)} onClick={() => setLightboxOpen(true)} className="w-full h-72 md:h-80 object-cover cursor-zoom-in" style={{ opacity: galleryLoaded ? 1 : 0, transition: "opacity .35s ease" }} />
            {ad.stamp && (
              <span className="absolute top-3 left-3 text-[11px] font-extrabold px-3 py-1.5 rounded-full flex items-center gap-1" style={{ background: ad.stamp === "featured" ? LIME : "#fff", color: INK }}>
                <Sparkles size={11} /> {ad.stamp === "featured" ? "Featured" : "Verified"}
              </span>
            )}
            {gallery.length > 1 && (
              <>
                <button onClick={() => setActiveImg((activeImg - 1 + gallery.length) % gallery.length)} className="absolute top-1/2 -translate-y-1/2 right-2 w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "rgba(20,24,31,.55)", color: "#fff" }}><ChevronRight size={16} /></button>
                <button onClick={() => setActiveImg((activeImg + 1) % gallery.length)} className="absolute top-1/2 -translate-y-1/2 left-2 w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "rgba(20,24,31,.55)", color: "#fff" }}><ChevronLeft size={16} /></button>
                <span className="absolute bottom-2 left-1/2 -translate-x-1/2 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1" style={{ background: "rgba(20,24,31,.55)", color: "#fff" }}>
                  <ImageIcon size={10} /> {activeImg + 1} / {gallery.length}
                </span>
              </>
            )}
          </div>
          {gallery.length > 1 && (
            <div className="flex gap-2 mb-6">
              {gallery.map((src, i) => (
                <button key={i} onClick={() => setActiveImg(i)} className="rounded-lg overflow-hidden shrink-0" style={{ width: 64, height: 48, border: `2px solid ${i === activeImg ? LIME : BORDER}`, opacity: i === activeImg ? 1 : 0.7 }}>
                  <SmartImg src={src} alt={`${ad.title || ""} ${i + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}

          <div className="flex items-center gap-2 mb-2 text-xs font-bold" style={{ color: cat.color }}><cat.icon size={13} /> {cat.label}</div>
          <h1 className="text-2xl md:text-3xl font-black text-[#14181F] mb-3" style={{ fontFamily: "Vazirmatn" }}>{ad.title}</h1>
          <div className="flex items-center gap-4 text-sm text-[#585C66] mb-6 flex-wrap">
            <span className="flex items-center gap-1"><MapPin size={13} />{ad.city}</span>
            <span className="flex items-center gap-1"><Clock size={13} />a few days ago</span>
            {reviews.count > 0 && (
              <span className="flex items-center gap-1.5">
                <Stars value={reviews.avg} />
                <span className="text-[#14181F] font-bold">{reviews.avg.toFixed(1)}</span>
                <span>({reviews.count} review)</span>
              </span>
            )}
          </div>

          {ad.description && (
            <Panel><Eyebrow color={cat.color}>Description</Eyebrow><p className="text-[#2E3340] text-sm leading-relaxed">{ad.description}</p></Panel>
          )}

          {ad.price > 0 && <PriceTrendChart ad={ad} color={cat.color} fmt={fmt} />}

          <Panel>
            <Eyebrow color={cat.color}>Details</Eyebrow>
            <div className="grid grid-cols-2 gap-y-3 text-sm">
              {Object.entries(ad.fields || {}).map(([k, v]) => {
                const def = FIELDS_BY_CATEGORY[ad.category]?.find((f) => f.key === k);
                return (
                  <div key={k} className="flex justify-between ps-4" style={{ borderBottom: `1px solid ${BORDER}`, paddingBottom: 8 }}>
                    <span className="text-[#585C66]">{def?.label || k}</span>
                    <span className="text-[#14181F] font-bold">{v}</span>
                  </div>
                );
              })}
            </div>
          </Panel>

          {ad.category === "realestate" && <NeighborhoodPanel ad={ad} cat={cat} />}

          {coords && (
            <Panel>
              <Eyebrow color={cat.color}>Location</Eyebrow>
              <div className="rounded-xl overflow-hidden mb-3" style={{ border: `1px solid ${BORDER}` }}>
                <iframe title="map" width="100%" height="220" loading="lazy"
                  style={{ border: 0, display: "block" }}
                  src={`https://www.openstreetmap.org/export/embed.html?bbox=${coords.lng - 0.06}%2C${coords.lat - 0.05}%2C${coords.lng + 0.06}%2C${coords.lat + 0.05}&layer=mapnik&marker=${coords.lat}%2C${coords.lng}`} />
              </div>
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span className="text-sm text-[#585C66] flex items-center gap-1.5"><MapPin size={13} /> {ad.city}</span>
                <a href={`https://www.openstreetmap.org/?mlat=${coords.lat}&mlon=${coords.lng}#map=13/${coords.lat}/${coords.lng}`} target="_blank" rel="noreferrer" className="text-xs font-bold flex items-center gap-1" style={{ color: cat.color }}>
                  Open large map <ExternalLink size={12} />
                </a>
              </div>
            </Panel>
          )}

          <Panel>
            <Eyebrow color={cat.color}>Reviews & Ratings</Eyebrow>
            {reviews.count > 0 ? (
              <div className="flex items-center gap-3 mb-5">
                <span className="text-3xl font-black text-[#14181F]" style={{ fontFamily: "JetBrains Mono" }}>{reviews.avg.toFixed(1)}</span>
                <div><Stars value={reviews.avg} size={15} /><p className="text-[11px] text-[#585C66] mt-1">from {reviews.count} review</p></div>
              </div>
            ) : (
              <p className="text-sm text-[#585C66] mb-5">No reviews yet — Be the first.</p>
            )}
            <div className="space-y-4 mb-5">
              {reviews.items.map((r) => (
                <div key={r.id} className="pb-4" style={{ borderBottom: `1px solid ${BORDER}` }}>
                  <div className="flex items-center gap-2.5 mb-1.5">
                    <span className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-extrabold" style={{ background: `${cat.color}22`, color: cat.color }}>{r.user.slice(0,1)}</span>
                    <span className="text-sm text-[#14181F] font-bold">{r.user}</span>
                    <Stars value={r.stars} size={11} />
                  </div>
                  <p className="text-sm text-[#3A3F4D] pe-10">{r.text}</p>
                </div>
              ))}
            </div>
            <div className="rounded-xl p-4" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
              <p className="text-xs text-[#585C66] font-bold mb-2">Submit your review</p>
              <div className="mb-3"><Stars value={newStars} size={18} interactive onChange={setNewStars} /></div>
              <textarea value={newComment} onChange={(e) => setNewComment(e.target.value)} placeholder="How was your experience with this listing or seller?"
                className="w-full rounded-lg p-3 text-sm text-[#14181F] placeholder:text-[#585C66] outline-none resize-none h-20 mb-3" style={{ background: SURFACE, border: `1px solid ${BORDER}` }} />
              <button onClick={submitReview} disabled={!newStars || !newComment.trim()} className="text-xs font-extrabold px-4 py-2 rounded-full disabled:opacity-30" style={{ background: cat.color, color: INK }}>Submit review</button>
            </div>
          </Panel>
        </div>

        <div className="md:col-span-2">
          <div className="rounded-2xl p-5 sticky top-24" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
            <div className="flex items-center justify-between mb-1">
              <Eyebrow color={cat.color}>Price</Eyebrow>
              <div className="flex items-center gap-1.5">
                <button onClick={() => window.print()} title="Download as PDF" aria-label="Download as PDF" className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: SURFACE, border: `1px solid ${BORDER}`, color: "#585C66" }}><Download size={13} /></button>
                <button onClick={() => setShowShare(!showShare)} title="Sharing" className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: SURFACE, border: `1px solid ${BORDER}`, color: "#585C66" }}><Share2 size={13} /></button>
                <button onClick={() => setShowReport(!showReport)} title="Report listing" className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: SURFACE, border: `1px solid ${BORDER}`, color: "#585C66" }}><Flag size={13} /></button>
              </div>
            </div>
            {ad.auction?.active ? (
              <AuctionPanel ad={ad} cat={cat} user={user} setAd={setAd} setView={setView} showToast={showToast} fmt={fmt} />
            ) : (
              <>
                <div className="font-black text-3xl text-[#14181F] mb-1" style={{ fontFamily: "JetBrains Mono" }}>{ad.price ? fmt(ad.price) : "Negotiable"}</div>
                <div className="text-xs font-bold mb-5" style={{ color: cat.color }}>{cat.model === "commission" ? cat.rate : "listed with a flat subscription"}</div>
              </>
            )}

            {showShare && (
              <div className="rounded-xl p-4 mb-4 text-center" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
                <img src={`https://api.qrserver.com/v1/create-qr-code/?size=140x140&data=${encodeURIComponent(shareUrl)}`} alt="QR" className="mx-auto mb-3 rounded-lg" width={120} height={120} />
                <div className="flex items-center gap-1.5 rounded-full px-3 py-2 mb-3" style={{ background: CARD, border: `1px solid ${BORDER}` }}>
                  <span className="flex-1 text-[11px] text-[#585C66] truncate" style={{ direction: "ltr" }}>{shareUrl}</span>
                  <button onClick={copyLink} className="shrink-0"><Copy size={13} color={LIME} /></button>
                </div>
                <div className="flex items-center justify-center gap-2">
                  <a href={`https://wa.me/?text=${encodeURIComponent(ad.title + " — " + shareUrl)}`} target="_blank" rel="noreferrer" className="text-[11px] font-bold px-3 py-1.5 rounded-full" style={{ background: `${cat.color}18`, color: cat.color }}>WhatsApp</a>
                  <a href={`https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(ad.title)}`} target="_blank" rel="noreferrer" className="text-[11px] font-bold px-3 py-1.5 rounded-full" style={{ background: `${cat.color}18`, color: cat.color }}>Telegram</a>
                </div>
              </div>
            )}
            {showReport && (
              <div className="rounded-xl p-4 mb-4" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
                {reportSent ? (
                  <p className="text-xs text-[#585C66] text-center py-2">Your report has been submitted — thanks for helping out.</p>
                ) : (
                  <>
                    <p className="text-xs text-[#14181F] font-bold mb-2.5">Why are you reporting this listing?</p>
                    <div className="flex flex-wrap gap-1.5">
                      {["Prohibited item", "Unrealistic price", "Duplicate photo/belongs to someone else", "Possible scam", "Other"].map((r) => (
                        <button key={r} onClick={() => submitReport(r)} className="text-[11px] font-bold px-3 py-1.5 rounded-full" style={{ background: CARD, border: `1px solid ${BORDER}`, color: "#14181F" }}>{r}</button>
                      ))}
                    </div>
                  </>
                )}
              </div>
            )}

            <button onClick={() => setView({ name: "seller", owner: ad.owner })} className="w-full flex items-center gap-2.5 pt-4 mb-2.5 text-start" style={{ borderTop: `1px solid ${BORDER}` }}>
              <span className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-extrabold shrink-0" style={{ background: LIME, color: INK }}>{ad.owner.slice(0,1)}</span>
              <div className="flex-1 min-w-0">
                <div className="text-sm text-[#14181F] font-bold flex items-center gap-1">{ad.owner} <ChevronLeft size={12} className="text-[#585C66]" /></div>
                <div className="text-[11px] text-[#585C66] flex items-center gap-1"><ShieldCheck size={11} /> View seller profile</div>
              </div>
            </button>
            <div className="mb-4"><TrustBadge owner={ad.owner} /></div>
            <button onClick={() => setPhoneShown(true)} className="w-full flex items-center justify-center gap-2 font-extrabold text-sm py-3 rounded-full mb-3 transition" style={{ background: SURFACE2, color: INK, border: `1px solid ${BORDER}` }}>
              <Phone size={15} />{phoneShown ? "0912 000 0000" : "Show phone number"}
            </button>

            <div className="rounded-xl p-3 mb-3" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-[10px] text-[#585C66] font-bold">Chat with {ad.owner}</span>
                <div className="flex items-center gap-2.5">
                  <button onClick={reportUser} className="text-[10px] text-[#585C66] hover:text-[#14181F] font-bold">Report</button>
                  <button onClick={blockUser} className="text-[10px] text-[#585C66] hover:text-[#14181F] font-bold">Block</button>
                </div>
              </div>

              <div className="space-y-2 max-h-52 overflow-y-auto mb-2.5 ps-1">
                {messages.map((m) => (
                  <div key={m.id} className={`flex ${m.from === "me" ? "justify-end" : "justify-start"}`}>
                    <div className="max-w-[80%] rounded-2xl px-3 py-2 text-xs leading-relaxed" style={m.from === "me" ? { background: LIME, color: INK } : { background: SURFACE2, color: INK, border: `1px solid ${BORDER}` }}>
                      {m.offer ? <span className="font-extrabold flex items-center gap-1"><Percent size={11} /> Bid: {fmt(m.offer)}</span> : m.text}
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-1.5 mb-2">
                <button onClick={attachPhoto} title="Attach photo" className="w-8 h-8 rounded-full flex items-center justify-center shrink-0" style={{ background: SURFACE2, border: `1px solid ${BORDER}`, color: "#585C66" }}><Camera size={13} /></button>
                <button onClick={voiceMsg} title="Voice message" className="w-8 h-8 rounded-full flex items-center justify-center shrink-0" style={{ background: SURFACE2, border: `1px solid ${BORDER}`, color: "#585C66" }}><Mic size={13} /></button>
                <button onClick={openBidModal} title="Bid" className="h-8 px-3 rounded-full flex items-center gap-1 text-[10px] font-bold shrink-0" style={{ background: `${cat.color}18`, color: cat.color }}><Percent size={11} /> Bid</button>
              </div>

              <div className="flex items-center gap-1.5">
                <input value={chatInput} onChange={(e) => setChatInput(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") sendChat(chatInput); }} placeholder="Hi, is this listing still available?"
                  className="flex-1 min-w-0 rounded-full px-3.5 py-2.5 text-sm text-[#14181F] placeholder:text-[#585C66] outline-none" style={{ background: SURFACE2, border: `1px solid ${BORDER}` }} />
                <button onClick={() => sendChat(chatInput)} className="w-10 h-10 rounded-full flex items-center justify-center shrink-0" style={{ background: LIME, color: INK }}><Send size={15} /></button>
              </div>
            </div>

            {isOwner && (
              <div className="rounded-xl p-3" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
                <p className="text-[10px] text-[#585C66] font-bold mb-2.5">Rate the buyer (This listing is yours)</p>
                {buyerAggregate && (
                  <div className="flex items-center gap-2 mb-3">
                    <Stars value={buyerAggregate.avg} size={12} />
                    <span className="text-[11px] text-[#585C66]">Average {buyerAggregate.avg.toFixed(1)} from {buyerAggregate.count} buyer</span>
                  </div>
                )}
                <input value={buyerName} onChange={(e) => setBuyerName(e.target.value)} placeholder="Buyer's name" className="w-full rounded-lg px-3 py-2 text-xs text-[#14181F] outline-none mb-2" style={{ background: CARD, border: `1px solid ${BORDER}` }} />
                <div className="mb-2"><Stars value={buyerStars} size={15} interactive onChange={setBuyerStars} /></div>
                <textarea value={buyerComment} onChange={(e) => setBuyerComment(e.target.value)} placeholder="Your experience with this buyer (Optional)" className="w-full rounded-lg p-2.5 text-xs text-[#14181F] outline-none resize-none h-16 mb-2.5" style={{ background: CARD, border: `1px solid ${BORDER}` }} />
                <button onClick={submitBuyerReview} disabled={!buyerName.trim() || !buyerStars} className="text-[11px] font-extrabold px-3.5 py-2 rounded-full disabled:opacity-30" style={{ background: LIME, color: INK }}>Submit rating</button>
              </div>
            )}
          </div>
        </div>
      </div>

      {similar.length > 0 && (
        <div className="mt-12">
          <Eyebrow color={cat.color}>Similar listings</Eyebrow>
          <h2 className="font-black text-lg mb-4" style={{ color: "#14181F", fontFamily: "Vazirmatn" }}>You might also like</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {similar.map((s) => <AdCard key={s.id} ad={s} onOpen={(s) => setView({ name: "detail", ad: s })} compareIds={compareIds} onToggleCompare={onToggleCompare} wishlistIds={wishlistIds} onToggleWishlist={onToggleWishlist} />)}
          </div>
        </div>
      )}
      </div>

      {bidModalOpen && (
        <div role="dialog" aria-modal="true" aria-label="Place a bid" className="fixed inset-0 z-[100] flex items-center justify-center p-4" style={{ background: "rgba(8,9,13,.6)" }} onClick={() => setBidModalOpen(false)}>
          <div className="w-full max-w-xs rounded-2xl p-6" style={{ background: CARD, boxShadow: "0 30px 60px -20px rgba(0,0,0,.4)" }} onClick={(e) => e.stopPropagation()}>
            <h3 className="text-base font-bold text-[#14181F] mb-1" style={{ fontFamily: SERIF }}>Place a bid</h3>
            <p className="text-xs text-[#585C66] mb-4">Your bid must be higher than the current bid</p>
            <input autoFocus type="number" min={1} value={bidValue} onChange={(e) => setBidValue(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") confirmBid(); }} placeholder="Enter your bid" className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none mb-4" style={{ background: SURFACE, border: `1px solid ${BORDER}`, direction: "ltr" }} />
            <div className="flex gap-2">
              <button onClick={() => setBidModalOpen(false)} className="flex-1 text-[#14181F] text-sm font-bold py-2.5 rounded-full" style={{ border: `1px solid ${BORDER}` }}>Cancel</button>
              <button onClick={confirmBid} disabled={!bidValue || isNaN(Number(bidValue)) || Number(bidValue) <= 0} className="flex-1 font-extrabold text-sm py-2.5 rounded-full disabled:opacity-30" style={{ background: LIME, color: "#fff" }}>Submit</button>
            </div>
          </div>
        </div>
      )}

      {lightboxOpen && (
        <div
          role="dialog" aria-modal="true" aria-label="Image viewer"
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center"
          style={{ background: "rgba(8,9,13,.94)" }}
          onClick={() => setLightboxOpen(false)}
        >
          <button
            onClick={(e) => { e.stopPropagation(); setLightboxOpen(false); }}
            aria-label="Close image viewer"
            className="absolute top-4 end-4 w-10 h-10 rounded-full flex items-center justify-center"
            style={{ background: "rgba(255,255,255,.12)", color: "#fff" }}
          ><X size={18} /></button>
          <SmartImg src={gallery[activeImg]} alt={ad.title || ""} onClick={(e) => e.stopPropagation()} className="max-w-[92vw] max-h-[80vh] object-contain rounded-lg" />
          {gallery.length > 1 && (
            <div className="flex items-center gap-3 mt-5" onClick={(e) => e.stopPropagation()}>
              <button
                onClick={() => setActiveImg((i) => (i - 1 + gallery.length) % gallery.length)}
                aria-label="Previous image"
                className="w-9 h-9 rounded-full flex items-center justify-center"
                style={{ background: "rgba(255,255,255,.12)", color: "#fff" }}
              >{lang === "fa" ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}</button>
              <span className="text-xs font-bold" style={{ color: "#fff" }}>{activeImg + 1} / {gallery.length}</span>
              <button
                onClick={() => setActiveImg((i) => (i + 1) % gallery.length)}
                aria-label="Next image"
                className="w-9 h-9 rounded-full flex items-center justify-center"
                style={{ background: "rgba(255,255,255,.12)", color: "#fff" }}
              >{lang === "fa" ? <ChevronLeft size={18} /> : <ChevronRight size={18} />}</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Compare                                                             */
/* ------------------------------------------------------------------ */

function CompareBar({ compareIds, listings, setView, clear }) {
  if (compareIds.length === 0) return null;
  const ads = compareIds.map((id) => listings.find((l) => l.id === id)).filter(Boolean);
  if (ads.length === 0) return null;
  const cat = catOf(ads[0].category);
  return (
    <div className="fixed start-1/2 -translate-x-1/2 z-40 flex items-center gap-3 rounded-full ps-2 pe-4 py-2 shadow-2xl" style={{ bottom: 96, background: SURFACE, border: `1px solid ${cat.color}77` }}>
      <div className="flex -space-x-2.5 space-x-reverse">
        {ads.map((ad) => <img key={ad.id} src={ad.img} alt={ad.title || ""} className="w-8 h-8 rounded-full object-cover" style={{ border: `2px solid ${SURFACE}` }} />)}
      </div>
      <span className="text-xs text-[#14181F] font-bold whitespace-nowrap">{ads.length} listing {cat.label}</span>
      <button onClick={() => setView({ name: "compare" })} className="text-xs font-extrabold px-3.5 py-1.5 rounded-full whitespace-nowrap flex items-center gap-1" style={{ background: cat.color, color: INK }}>
        <Scale size={13} /> Compare
      </button>
      <button onClick={clear} aria-label="Clear comparison" className="text-[#585C66] hover:text-[#14181F] shrink-0"><X size={15} /></button>
    </div>
  );
}

function CompareView({ compareIds, listings, setView, onToggleCompare }) {
  const { fmt } = useLang();
  const ads = compareIds.map((id) => listings.find((l) => l.id === id)).filter(Boolean);
  if (ads.length === 0) {
    return (
      <div className="max-w-md mx-auto px-4 py-24 text-center">
        <Scale size={30} className="mx-auto mb-4 text-[#585C66]" />
        <p className="text-[#14181F] font-semibold mb-4">You haven't selected any listings to compare yet.</p>
        <p className="text-xs text-[#585C66] mb-6">On any listing card, tap the scale icon to add it to your comparison list.</p>
        <button onClick={() => setView({ name: "home" })} className="font-extrabold text-sm px-5 py-2.5 rounded-full" style={{ background: LIME, color: INK }}>Back to home</button>
      </div>
    );
  }
  const cat = catOf(ads[0].category);
  const fieldDefs = FIELDS_BY_CATEGORY[ads[0].category] || [];
  const rows = [
    { label: "Price", render: (ad) => (ad.price ? fmt(ad.price) : "Negotiable") },
    { label: "City", render: (ad) => ad.city },
    { label: "score", render: (ad) => (ad.reviews?.count ? `${ad.reviews.avg.toFixed(1)} out of 5 (${ad.reviews.count} review)` : "No reviews") },
    { label: "Revenue model", render: () => (cat.model === "commission" ? cat.rate : "flat subscription") },
    { label: "Listing status", render: (ad) => (ad.stamp === "featured" ? "Featured" : ad.stamp === "verified" ? "Verified" : "Standard") },
    ...fieldDefs.map((f) => ({ label: f.label, render: (ad) => ad.fields?.[f.key] ?? "—" })),
  ];
  return (
    <div className="max-w-6xl mx-auto px-4 py-10 pb-24">
      <Crumbs items={[{ label: "Home", onClick: () => setView({ name: "home" }) }, { label: `Compare ${cat.label}` }]} />
      <div className="flex items-center gap-3.5 mb-7">
        <CatIcon cat={cat} size={22} wrap={46} />
        <div><h1 className="text-2xl font-black text-[#14181F]" style={{ fontFamily: "Vazirmatn" }}>Comparing listings in {cat.label}</h1><p className="text-sm text-[#585C66]">{ads.length} Selected listings, side by side</p></div>
      </div>
      <div className="overflow-x-auto rounded-2xl" style={{ border: `1px solid ${BORDER}` }}>
        <table className="w-full text-sm" style={{ borderCollapse: "collapse" }}>
          <thead>
            <tr>
              <th className="p-3" style={{ background: SURFACE, minWidth: 130 }} />
              {ads.map((ad) => (
                <th key={ad.id} className="p-3 text-start align-top" style={{ background: SURFACE, minWidth: 190, borderInlineEnd: `1px solid ${BORDER}` }}>
                  <div className="relative rounded-xl overflow-hidden mb-2.5" style={{ border: `1px solid ${BORDER}` }}>
                    <SmartImg src={ad.img} alt={ad.title || ""} className="w-full h-24 object-cover" />
                    <button onClick={() => onToggleCompare(ad)} aria-label="Remove from comparison" className="absolute top-1.5 left-1.5 w-6 h-6 rounded-full flex items-center justify-center" style={{ background: "rgba(0,0,0,.6)", color: "#fff" }}><X size={12} /></button>
                  </div>
                  <button onClick={() => setView({ name: "detail", ad })} className="text-[#14181F] font-bold text-[13px] leading-snug line-clamp-2 text-start hover:underline block">{ad.title}</button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, i) => (
              <tr key={row.label} style={{ background: i % 2 === 0 ? SURFACE2 : "transparent" }}>
                <td className="p-3 text-xs font-bold text-[#585C66] whitespace-nowrap" style={{ borderInlineEnd: `1px solid ${BORDER}` }}>{row.label}</td>
                {ads.map((ad) => <td key={ad.id} className="p-3 text-[#14181F] font-semibold text-[13px]" style={{ borderInlineEnd: `1px solid ${BORDER}` }}>{row.render(ad)}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Post-ad flow                                                       */
/* ------------------------------------------------------------------ */

function PostAdView({ setView, user, onPublish, onUpdate, editingAd = null, listings = [] }) {
  const { fmt, t } = useLang();
  const isEditing = !!editingAd;
  const [step, setStep] = useState(isEditing ? 2 : 1);
  const [category, setCategory] = useState(editingAd ? editingAd.category : null);
  const [form, setForm] = useState(editingAd
    ? { title: editingAd.title || "", price: String(editingAd.price ?? ""), city: editingAd.city || CITIES[0], description: editingAd.description || "" }
    : { title: "", price: "", city: CITIES[0], description: "" });
  const [fields, setFields] = useState(editingAd ? (editingAd.fields || {}) : {});
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [auctionOn, setAuctionOn] = useState(editingAd ? !!editingAd.auction?.active : false);
  const [auctionDays, setAuctionDays] = useState(3);

  if (!user) {
    return (
      <div className="max-w-md mx-auto px-4 py-24 text-center">
        <p className="text-[#14181F] font-semibold mb-4">You need to log in first to post a listing.</p>
        <button onClick={() => setView({ name: "auth" })} className="font-extrabold text-sm px-5 py-2.5 rounded-full" style={{ background: LIME, color: INK }}>Log in / Sign up</button>
      </div>
    );
  }

  const cat = category ? catOf(category) : null;
  const accent = cat ? cat.color : LIME;
  const steps = [t("stepCategory"), t("stepDetails"), t("stepReview")];

  const priceSuggestion = useMemo(() => {
    if (!category) return null;
    const sameCat = listings.filter((l) => l.category === category && l.price > 0).map((l) => l.price).sort((a, b) => a - b);
    if (sameCat.length < 3) return null;
    return { min: sameCat[Math.floor(sameCat.length * 0.25)], max: sameCat[Math.floor(sameCat.length * 0.75)] };
  }, [category, listings]);

  const [images, setImages] = useState(editingAd?.images ? editingAd.images.map((url) => ({ name: "", dataUrl: url })) : []); // array of { name, dataUrl }
  const [imgError, setImgError] = useState("");
  const [errors, setErrors] = useState({});
  const MAX_IMAGES = 6;
  const MAX_FILE_MB = 4;

  const handleFiles = (fileList) => {
    setImgError("");
    const files = Array.from(fileList || []).slice(0, MAX_IMAGES - images.length);
    if (!files.length) return;
    files.forEach((file) => {
      if (!file.type.startsWith("image/")) { setImgError("Only image files are accepted."); return; }
      if (file.size > MAX_FILE_MB * 1024 * 1024) { setImgError(`Photo size must not exceed ${MAX_FILE_MB} MB.`); return; }
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          const MAX_DIM = 1280;
          let { width, height } = img;
          if (width > MAX_DIM || height > MAX_DIM) {
            const scale = MAX_DIM / Math.max(width, height);
            width = Math.round(width * scale);
            height = Math.round(height * scale);
          }
          const canvas = document.createElement("canvas");
          canvas.width = width; canvas.height = height;
          const ctx = canvas.getContext("2d");
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL("image/jpeg", 0.78);
          setImages((prev) => (prev.length >= MAX_IMAGES ? prev : [...prev, { name: file.name, dataUrl }]));
        };
        img.onerror = () => setImgError("Photo processing failed.");
        img.src = reader.result;
      };
      reader.onerror = () => setImgError("Failed to read the file.");
      reader.readAsDataURL(file);
    });
  };
  const removeImage = (idx) => setImages((prev) => prev.filter((_, i) => i !== idx));

  const validateStep2 = () => {
    const errs = {};
    if (!form.title.trim()) errs.title = "Title is required.";
    else if (form.title.trim().length < 5) errs.title = "Title should be at least 5 characters.";
    if (form.price && Number(form.price) <= 0) errs.price = "Price must be greater than zero.";
    if (images.length === 0) errs.images = "Add at least one photo.";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };
  const goToStep3 = () => { if (validateStep2()) setStep(3); };

  const submit = () => {
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setDone(true);
      const uploaded = images.map((im) => im.dataUrl);
      const finalImages = uploaded.length ? uploaded : [`https://picsum.photos/seed/${Date.now()}/800/560`, `https://picsum.photos/seed/${Date.now()}b/800/560`, `https://picsum.photos/seed/${Date.now()}c/800/560`];
      if (isEditing) {
        onUpdate(editingAd.id, {
          category, title: form.title, price: Number(form.price) || 0,
          city: form.city, description: form.description, img: finalImages[0], images: finalImages,
          fields, status: "pending", // edits go back through review
          auction: auctionOn ? { active: true, startPrice: Number(form.price) || 0, currentBid: editingAd.auction?.currentBid ?? (Number(form.price) || 0), endsAt: editingAd.auction?.endsAt || Date.now() + auctionDays * 86400000, bids: editingAd.auction?.bids || [] } : null,
        });
      } else {
        onPublish({
          id: "u" + Date.now(), category, title: form.title, price: Number(form.price) || 0,
          city: form.city, description: form.description, owner: user.name, img: finalImages[0],
          images: finalImages,
          fields, stamp: null, status: "pending", createdAt: Date.now(),
          reviews: { avg: 0, count: 0, items: [] },
          auction: auctionOn ? { active: true, startPrice: Number(form.price) || 0, currentBid: Number(form.price) || 0, endsAt: Date.now() + auctionDays * 86400000, bids: [] } : null,
        });
      }
    }, 800);
  };

  if (done) {
    return (
      <div className="max-w-md mx-auto px-4 py-24 text-center">
        <Confetti onDone={() => {}} />
        <div className="w-20 h-20 mx-auto rounded-2xl flex items-center justify-center mb-6 animate-[popIn_.4s_ease]" style={{ background: LIME }}>
          <Check size={36} color={INK} strokeWidth={3} />
        </div>
        <h2 className="text-2xl font-black text-[#14181F] mb-2" style={{ fontFamily: "Vazirmatn" }}>{t("doneTitle")}</h2>
        <p className="text-sm text-[#585C66] mb-7">{t("doneDesc")}</p>
        <button onClick={() => setView({ name: "dashboard" })} className="font-extrabold text-sm px-5 py-2.5 rounded-full" style={{ background: LIME, color: INK }}>{t("viewStatusBtn")}</button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-10 pb-24">
      <Eyebrow color={accent}>{t("postAdTitle")}</Eyebrow>
      <h1 className="text-3xl font-black text-[#14181F] mb-2" style={{ fontFamily: "Vazirmatn" }}>{t("postAdTitle")}</h1>
      <p className="text-xs text-[#585C66] mb-7">{t("postAdSubtitle")}</p>
      <div className="flex items-center gap-2 mb-9">
        {steps.map((s, i) => (
          <React.Fragment key={s}>
            <div className="flex items-center gap-1.5 text-xs font-bold" style={{ color: i + 1 <= step ? accent : "#585C66" }}>
              <span className="w-6 h-6 rounded-full flex items-center justify-center text-[11px] font-extrabold" style={i + 1 <= step ? { background: accent, color: INK } : { border: `1px solid ${BORDER}` }}>
                {i + 1 < step ? <Check size={12} /> : i + 1}
              </span>
              <span className="hidden sm:inline">{s}</span>
            </div>
            {i < steps.length - 1 && <div className="flex-1 h-px" style={{ background: BORDER }} />}
          </React.Fragment>
        ))}
      </div>

      {step === 1 && (
        <div>
          <p className="text-sm text-[#585C66] mb-5 font-medium">{t("choosePrompt")}</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-8">
            {CAT_LIST.map((c) => {
              const Icon = c.icon;
              const active = category === c.id;
              return (
                <button key={c.id} onClick={() => setCategory(c.id)} className="flex flex-col items-center gap-2.5 py-6 rounded-2xl transition"
                  style={active ? { background: `${c.color}1c`, border: `1.5px solid ${c.color}`, boxShadow: CARD_SHADOW } : { background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
                  <Icon size={22} color={active ? c.color : "#585C66"} />
                  <span className="text-sm text-[#14181F] font-bold">{c.label}</span>
                </button>
              );
            })}
          </div>
          <button disabled={!category} onClick={() => setStep(2)} className="w-full font-extrabold text-sm py-3.5 rounded-full disabled:opacity-30 transition" style={{ background: accent, color: INK }}>{t("continueBtn")}</button>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-4">
          <Field label={t("titleLabel")}>
            <input value={form.title} onChange={(e) => { setForm({ ...form, title: e.target.value }); if (errors.title) setErrors({ ...errors, title: null }); }} className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${errors.title ? "#F43F5E" : BORDER}` }} placeholder="e.g. Two-bedroom apartment, city center" />
            {errors.title && <p className="text-[11px] mt-1.5" style={{ color: "#F43F5E" }}>{errors.title}</p>}
          </Field>
          <Field label={t("descLabel")}>
            <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none resize-none h-24" style={{ background: SURFACE, border: `1px solid ${BORDER}` }} placeholder="Add more details about your listing..." />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label={t("priceLabel")}>
              <input type="number" value={form.price} onChange={(e) => { setForm({ ...form, price: e.target.value }); if (errors.price) setErrors({ ...errors, price: null }); }} className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${errors.price ? "#F43F5E" : BORDER}`, fontFamily: "JetBrains Mono" }} placeholder="leave empty for negotiable" />
              {errors.price && <p className="text-[11px] mt-1.5" style={{ color: "#F43F5E" }}>{errors.price}</p>}
            </Field>
            <Field label={t("cityLabel")}>
              <select value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
                {CITIES.map((c) => <option key={c}>{c}</option>)}
              </select>
            </Field>
          </div>
          {priceSuggestion && (
            <div className="flex items-center justify-between gap-2 rounded-xl px-3.5 py-2.5" style={{ background: `${LIME}12`, border: `1px solid ${LIME}44` }}>
              <span className="text-[11px] text-[#14181F]">
                <Sparkles size={11} className="inline -mt-0.5" /> Typical price range for similar listings: <b>{fmt(priceSuggestion.min)}</b> to <b>{fmt(priceSuggestion.max)}</b>
              </span>
              <button onClick={() => setForm({ ...form, price: String(Math.round((priceSuggestion.min + priceSuggestion.max) / 2)) })} className="text-[10px] font-extrabold px-2.5 py-1 rounded-full shrink-0" style={{ background: LIME, color: INK }}>use</button>
            </div>
          )}
          {FIELDS_BY_CATEGORY[category].map((f) => (
            <Field key={f.key} label={f.label}>
              {f.type === "select" ? (
                <select value={fields[f.key] || ""} onChange={(e) => setFields({ ...fields, [f.key]: e.target.value })} className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
                  <option value="">Choose</option>
                  {f.options.map((o) => <option key={o}>{o}</option>)}
                </select>
              ) : (
                <input type={f.type} value={fields[f.key] || ""} onChange={(e) => setFields({ ...fields, [f.key]: e.target.value })} className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}` }} />
              )}
            </Field>
          ))}

          <div className="rounded-xl p-4" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
            <button onClick={() => setAuctionOn(!auctionOn)} className="w-full flex items-center gap-3 text-start">
              <span className="w-10 h-6 rounded-full relative shrink-0 transition-colors" style={{ background: auctionOn ? LIME : BORDER }}>
                <span className="absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all" style={{ [auctionOn ? "right" : "left"]: 2 }} />
              </span>
              <span className="flex-1">
                <span className="text-sm text-[#14181F] font-bold block">Auction mode</span>
                <span className="text-[11px] text-[#585C66]">Instead of a fixed price, buyers place bids on your listing</span>
              </span>
            </button>
            {auctionOn && (
              <div className="mt-3 pt-3" style={{ borderTop: `1px solid ${BORDER}` }}>
                <label className="text-xs text-[#585C66] font-bold block mb-2">Auction duration</label>
                <div className="flex gap-2">
                  {[1, 3, 7].map((d) => (
                    <button key={d} onClick={() => setAuctionDays(d)} className="flex-1 text-xs font-bold py-2 rounded-lg" style={auctionDays === d ? { background: LIME, color: INK } : { background: CARD, border: `1px solid ${BORDER}`, color: "#585C66" }}>{d} day</button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div>
            <label className="text-xs text-[#585C66] font-bold block mb-2">Listing photo (at least 1 required, up to {MAX_IMAGES})</label>
            {images.length > 0 && (
              <div className="grid grid-cols-3 gap-2 mb-2">
                {images.map((im, i) => (
                  <div key={i} className="relative rounded-lg overflow-hidden" style={{ border: `1px solid ${BORDER}` }}>
                    <img src={im.dataUrl} alt={im.name} className="w-full h-20 object-cover" />
                    <button type="button" onClick={() => removeImage(i)} aria-label="Remove photo" className="absolute top-1 left-1 w-5 h-5 rounded-full flex items-center justify-center" style={{ background: "rgba(0,0,0,.6)", color: "#fff" }}><X size={11} /></button>
                  </div>
                ))}
              </div>
            )}
            {images.length < MAX_IMAGES && (
              <label className="rounded-xl py-6 flex flex-col items-center gap-2 text-[#585C66] text-xs cursor-pointer" style={{ border: `1px dashed ${errors.images ? "#F43F5E" : BORDER}` }}>
                <Camera size={20} /> Add photo
                <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => { handleFiles(e.target.files); e.target.value = ""; if (errors.images) setErrors({ ...errors, images: null }); }} />
              </label>
            )}
            {imgError && <p className="text-[11px] mt-1.5" style={{ color: "#F43F5E" }}>{imgError}</p>}
            {errors.images && <p className="text-[11px] mt-1.5" style={{ color: "#F43F5E" }}>{errors.images}</p>}
          </div>
          <div className="flex gap-2 pt-2">
            <button onClick={() => setStep(1)} className="flex-1 text-[#14181F] text-sm font-bold py-3.5 rounded-full" style={{ border: `1px solid ${BORDER}` }}>{t("backBtn")}</button>
            <button onClick={goToStep3} className="flex-1 font-extrabold text-sm py-3.5 rounded-full" style={{ background: accent, color: INK }}>{t("continueBtn")}</button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div>
          {cat.model === "commission" && (
            <div className="rounded-2xl p-5 mb-6 flex items-start gap-3" style={{ background: `${cat.color}14`, border: `1px solid ${cat.color}55` }}>
              <Percent size={18} style={{ color: cat.color }} className="mt-0.5 shrink-0" />
              <div><p className="text-sm text-[#14181F] font-bold mb-1">This category has a fee</p>
                <p className="text-xs text-[#585C66] leading-relaxed">Posting is free. A portion of the final amount ({cat.rate}) is only deducted as a brokerage fee once the deal actually closes through SPENTA.</p>
              </div>
            </div>
          )}
          <div className="rounded-2xl p-5 mb-6 flex items-start gap-3" style={{ background: `${LIME}14`, border: `1px solid ${LIME}55` }}>
            <ShieldCheck size={18} style={{ color: LIME }} className="mt-0.5 shrink-0" />
            <div>
              <p className="text-sm text-[#14181F] font-bold mb-1">Reviewed before publishing</p>
              <p className="text-xs text-[#585C66] leading-relaxed">For marketplace safety, every listing is reviewed by the SPENTA will be reviewed and approved.</p>
            </div>
          </div>
          <div className="rounded-2xl p-5 mb-6" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
            <p className="text-xs text-[#585C66] font-bold mb-3">Listing summary</p>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-[#585C66]">category</span><span className="text-[#14181F] font-bold">{cat.label}</span></div>
              <div className="flex justify-between"><span className="text-[#585C66]">Title</span><span className="text-[#14181F] font-bold truncate max-w-[60%]">{form.title}</span></div>
              <div className="flex justify-between"><span className="text-[#585C66]">Price</span><span className="text-[#14181F] font-bold">{form.price ? fmt(form.price) : "Negotiable"}</span></div>
              <div className="flex justify-between"><span className="text-[#585C66]">City</span><span className="text-[#14181F] font-bold">{form.city}</span></div>
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setStep(2)} className="flex-1 text-[#14181F] text-sm font-bold py-3.5 rounded-full" style={{ border: `1px solid ${BORDER}` }}>{t("backBtn")}</button>
            <button onClick={submit} disabled={submitting} className="flex-1 flex items-center justify-center gap-2 font-extrabold text-sm py-3.5 rounded-full" style={{ background: accent, color: INK }}>
              {submitting && <Loader2 size={16} className="animate-spin" />}
              {submitting ? t("submittingBtn") : t("submitReviewBtn")}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function Field({ label, children }) {
  return <div><label className="text-xs text-[#585C66] font-bold block mb-2">{label}</label>{children}</div>;
}

/* ------------------------------------------------------------------ */
/*  Auth                                                                */
/* ------------------------------------------------------------------ */

async function hashPassword(pw) {
  try {
    const enc = new TextEncoder().encode(pw);
    const buf = await crypto.subtle.digest("SHA-256", enc);
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
  } catch (e) {
    return "plain:" + pw; // fallback if SubtleCrypto unavailable
  }
}

function AuthView({ setUser, setView }) {
  const { t } = useLang();
  const [tab, setTab] = useState("login");
  const [step, setStep] = useState(1);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [city, setCity] = useState(CITIES[0]);
  const [address, setAddress] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [pendingUser, setPendingUser] = useState(null);

  const switchTab = (tabKey) => { setTab(tabKey); setStep(1); setError(""); };

  const validateStep1 = () => {
    if (!name.trim()) { setError("Enter your name."); return false; }
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes("@")) { setError("Enter your email."); return false; }
    if (password.length < 4) { setError("Password must be at least 4 characters."); return false; }
    setError("");
    return true;
  };

  const goToStep2 = () => { if (validateStep1()) setStep(2); };

  const finishSignup = async () => {
    setError("");
    if (!agreed) { setError("You must accept the Terms & Conditions to sign up."); return; }
    const cleanEmail = email.trim().toLowerCase();
    setBusy(true);
    try {
      let creds = {};
      try {
        const res = await window.storage.get("credentials", false);
        creds = JSON.parse(res.value) || {};
      } catch (e) {}
      if (creds[cleanEmail]) { setError("This email is already registered. Log in instead."); setBusy(false); return; }
      const hash = await hashPassword(password);
      creds[cleanEmail] = hash;
      try { await window.storage.set("credentials", JSON.stringify(creds), false); } catch (e) {}
      setPendingUser({ name: name.trim(), email: cleanEmail, phone: phone.trim(), city, address: address.trim(), postalCode: postalCode.trim(), bio: "" });
      setOtpSent(true);
      setStep(3);
    } finally {
      setBusy(false);
    }
  };

  const confirmOtp = () => {
    if (otp.trim().length < 4) { setError("Enter the 4-digit code."); return; }
    setUser({ ...pendingUser, verificationStatus: "pending" });
    setView({ name: "home" });
  };

  const login = async () => {
    setError("");
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail) { setError("Enter your email."); return; }
    if (password.length < 4) { setError("Password must be at least 4 characters."); return; }
    setBusy(true);
    try {
      let creds = {};
      try {
        const res = await window.storage.get("credentials", false);
        creds = JSON.parse(res.value) || {};
      } catch (e) {}
      if (!creds[cleanEmail]) { setError("No account found with this email. Sign up first."); setBusy(false); return; }
      const hash = await hashPassword(password);
      if (creds[cleanEmail] !== hash) { setError("Wrong password."); setBusy(false); return; }
      setUser({ name: name.trim() || cleanEmail.split("@")[0], email: cleanEmail, phone: phone.trim(), city, bio: "" });
      setView({ name: "home" });
    } finally {
      setBusy(false);
    }
  };

  const signupSteps = ["Account", "Contact & Address", "Verify"];

  return (
    <div className="min-h-[calc(100vh-56px)] flex">
      <div className="hidden md:flex md:w-[42%] shrink-0 flex-col justify-between p-10 relative overflow-hidden" style={{ background: `radial-gradient(ellipse 130% 90% at 15% -10%, #1E2430 0%, ${INK} 60%)` }}>
        <span className="lot-corner lot-corner-tl" style={{ borderColor: GOLD, opacity: 1, top: 24, insetInlineStart: 24 }} />
        <span className="lot-corner lot-corner-br" style={{ borderColor: GOLD, opacity: 1, bottom: 24, insetInlineEnd: 24 }} />
        <span className="font-black text-xl" style={{ color: "#F7F4EC", fontFamily: SERIF }}>SPENTA</span>
        <div>
          <h2 className="text-3xl font-bold mb-4 leading-tight" style={{ color: "#F7F4EC", fontFamily: SERIF }}>One global showcase for everything</h2>
          <div className="space-y-3.5">
            {[[ShieldCheck, "Identity-verified sellers"], [Globe2, "Listings across every continent"], [BadgeCheck, "Reviewed before publishing"]].map(([Icon, label]) => (
              <div key={label} className="flex items-center gap-3">
                <span className="w-8 h-8 rounded-full flex items-center justify-center shrink-0" style={{ border: `1px solid rgba(229,185,78,.4)`, color: GOLD }}><Icon size={14} /></span>
                <span className="text-sm" style={{ color: "rgba(247,244,236,.75)" }}>{label}</span>
              </div>
            ))}
          </div>
        </div>
        <span className="text-[11px]" style={{ color: "rgba(247,244,236,.35)" }}>© SPENTA</span>
      </div>

      <div className="flex-1 flex items-center justify-center px-4 py-14">
        <div className="w-full max-w-sm">
          <div className="text-center mb-8 md:hidden"><Logo size="lg" tagline /></div>
          <div className="flex rounded-full p-1 mb-7" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
            {["login", "signup"].map((tabKey) => (
              <button key={tabKey} onClick={() => switchTab(tabKey)} className="flex-1 text-sm py-2.5 rounded-full font-extrabold transition" style={tab === tabKey ? { background: LIME, color: "#fff" } : { color: "#585C66" }}>{tabKey === "login" ? t("loginTab") : t("signupTab")}</button>
            ))}
          </div>

          {tab === "signup" && (
            <div className="flex items-center gap-1.5 mb-7">
              {signupSteps.map((s, i) => (
                <React.Fragment key={s}>
                  <span className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-extrabold shrink-0" style={i + 1 <= step ? { background: LIME, color: "#fff" } : { border: `1px solid ${BORDER}`, color: "#585C66" }}>
                    {i + 1 < step ? <Check size={11} /> : i + 1}
                  </span>
                  {i < signupSteps.length - 1 && <div className="flex-1 h-px" style={{ background: BORDER }} />}
                </React.Fragment>
              ))}
            </div>
          )}

          {tab === "login" && (
            <div className="space-y-3 mb-2">
              <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder={t("emailLabel")} type="email" className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}`, direction: "ltr" }} />
              <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder={t("passwordLabel")} type="password" className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}` }} />
            </div>
          )}

          {tab === "signup" && step === 1 && (
            <div className="space-y-3 mb-2">
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder={t("fullNameLabel")} className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}` }} />
              <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder={t("emailLabel")} type="email" className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}`, direction: "ltr" }} />
              <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder={t("passwordLabel")} type="password" className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}` }} />
            </div>
          )}

          {tab === "signup" && step === 2 && (
            <div className="space-y-3 mb-2">
              <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder={t("phoneLabel")} type="tel" className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}`, direction: "ltr" }} />
              <select value={city} onChange={(e) => setCity(e.target.value)} className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
                {CITIES.map((c) => <option key={c}>{c}</option>)}
              </select>
              <input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Street address" className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}` }} />
              <input value={postalCode} onChange={(e) => setPostalCode(e.target.value)} placeholder="Postal / ZIP code" className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}`, direction: "ltr" }} />
              <label className="flex items-start gap-2 pt-1 cursor-pointer select-none">
                <input type="checkbox" checked={agreed} onChange={(e) => setAgreed(e.target.checked)} className="mt-0.5 shrink-0" />
                <span className="text-[11.5px] text-[#585C66] leading-relaxed">
                  I accept SPENTA's <button type="button" onClick={() => setView({ name: "terms" })} className="font-bold hover:underline" style={{ color: LIME }}>Terms & Conditions</button> and <button type="button" onClick={() => setView({ name: "privacy" })} className="font-bold hover:underline" style={{ color: LIME }}>Privacy Policy</button>.
                </span>
              </label>
            </div>
          )}

          {tab === "signup" && step === 3 && (
            <div className="text-center py-3 mb-2">
              <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: `${LIME}18`, color: LIME }}><Phone size={22} /></div>
              <p className="text-sm text-[#14181F] font-bold mb-1">Verify your phone number</p>
              <p className="text-xs text-[#585C66] mb-5">We sent a demo code to <span style={{ direction: "ltr", display: "inline-block" }}>{phone || "your number"}</span> — enter <b>0000</b> to continue.</p>
              <input value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 4))} placeholder="0000" maxLength={4} className="w-full text-center text-2xl font-black tracking-[0.5em] rounded-xl px-3.5 py-3 outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}`, fontFamily: "JetBrains Mono", direction: "ltr" }} />
            </div>
          )}

          {error && <p className="text-[12px] mb-4 mt-1" style={{ color: "#F43F5E" }}>{error}</p>}

          <div className="flex gap-2 mt-4">
            {tab === "signup" && step === 2 && (
              <button onClick={() => setStep(1)} className="font-bold text-sm px-5 py-3.5 rounded-full" style={{ border: `1px solid ${BORDER}`, color: "#14181F" }}>Back</button>
            )}
            <button
              onClick={tab === "login" ? login : step === 1 ? goToStep2 : step === 2 ? finishSignup : confirmOtp}
              disabled={busy || (tab === "signup" && step === 2 && !agreed)}
              className="flex-1 flex items-center justify-center gap-2 font-extrabold text-sm py-3.5 rounded-full disabled:opacity-30"
              style={{ background: LIME, color: "#fff" }}
            >
              {busy && <Loader2 size={16} className="animate-spin" />}
              {tab === "login" ? t("loginSubmitBtn") : step === 1 ? "Continue" : step === 2 ? t("signupSubmitBtn") : "Confirm & finish"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Dashboard                                                          */
/* ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ */
/*  Wishlist                                                            */
/* ------------------------------------------------------------------ */

function WishlistView({ wishlistIds, listings, setView, compareIds, onToggleCompare, onToggleWishlist }) {
  const ads = wishlistIds.map((id) => listings.find((l) => l.id === id)).filter(Boolean);
  return (
    <div className="max-w-6xl mx-auto px-4 py-10 pb-24">
      <Crumbs items={[{ label: "Home", onClick: () => setView({ name: "home" }) }, { label: "Wishlist" }]} />
      <div className="flex items-center gap-3.5 mb-8">
        <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: "#F43F5E22", color: "#F43F5E" }}><Heart size={22} fill="#F43F5E" /></div>
        <div><h1 className="text-2xl font-black text-[#14181F]" style={{ fontFamily: "Vazirmatn" }}>My Wishlist</h1><p className="text-sm text-[#585C66]">{ads.length} Saved listing</p></div>
      </div>
      {ads.length === 0 ? (
        <div className="text-center py-20 rounded-2xl" style={{ border: `1px dashed ${BORDER}` }}>
          <Heart size={28} className="mx-auto mb-4 text-[#585C66]" />
          <p className="text-[#585C66] mb-5">You haven't saved any listings yet.</p>
          <button onClick={() => setView({ name: "home" })} className="font-extrabold text-sm px-5 py-2.5 rounded-full" style={{ background: LIME, color: INK }}>Browsing listings</button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {ads.map((ad) => <AdCard key={ad.id} ad={ad} onOpen={(ad) => setView({ name: "detail", ad })} compareIds={compareIds} onToggleCompare={onToggleCompare} wishlistIds={wishlistIds} onToggleWishlist={onToggleWishlist} />)}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Saved searches                                                      */
/* ------------------------------------------------------------------ */

function SavedSearchesView({ savedSearches, listings, setView, recomputeMatches, onRemove, onOpen }) {
  return (
    <div className="max-w-2xl mx-auto px-4 py-10 pb-24">
      <Crumbs items={[{ label: "Home", onClick: () => setView({ name: "home" }) }, { label: "Saved Searches" }]} />
      <div className="flex items-center gap-3.5 mb-8">
        <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: `${LIME}22`, color: LIME }}><Bell size={22} /></div>
        <div><h1 className="text-2xl font-black text-[#14181F]" style={{ fontFamily: "Vazirmatn" }}>Saved Searches</h1><p className="text-sm text-[#585C66]">We'll notify you when a matching listing appears</p></div>
      </div>

      {savedSearches.length === 0 ? (
        <div className="text-center py-16 rounded-2xl" style={{ border: `1px dashed ${BORDER}` }}>
          <p className="text-[#585C66] text-sm mb-5">You haven't saved any searches yet. On each category page, tap «Save this search».</p>
          <button onClick={() => setView({ name: "home" })} className="font-extrabold text-sm px-5 py-2.5 rounded-full" style={{ background: LIME, color: INK }}>Browsing categories</button>
        </div>
      ) : (
        <div className="space-y-2.5">
          {savedSearches.map((s) => {
            const cat = catOf(s.categoryId);
            const count = recomputeMatches(s);
            const hasNew = count > s.seenCount;
            return (
              <div key={s.id} className="flex items-center gap-3 rounded-2xl p-4" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
                <CatIcon cat={cat} size={17} wrap={38} />
                <button onClick={() => { onOpen(s.id); setView({ name: "category", category: s.categoryId }); }} className="flex-1 min-w-0 text-start">
                  <div className="text-sm text-[#14181F] font-bold flex items-center gap-2 truncate">
                    {s.label}
                    {hasNew && <span className="w-2 h-2 rounded-full shrink-0" style={{ background: "#F43F5E" }} />}
                  </div>
                  <div className="text-[11px] text-[#585C66]">{count} Matching listing {hasNew && <span style={{ color: LIME }}> · {count - s.seenCount} New</span>}</div>
                </button>
                <button onClick={() => onRemove(s.id)} aria-label="Remove saved search" className="text-[#585C66] hover:text-[#14181F] shrink-0"><X size={16} /></button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Admin — approval queue                                              */
/* ------------------------------------------------------------------ */

function AdminView({ pendingListings, setView, onDecide }) {
  const { fmt } = useLang();
  return (
    <div className="max-w-3xl mx-auto px-4 py-10 pb-24">
      <Crumbs items={[{ label: "Home", onClick: () => setView({ name: "home" }) }, { label: "Admin panel" }]} />
      <div className="flex items-center gap-3.5 mb-8">
        <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: "#EAB30822", color: "#EAB308" }}><ShieldCheck size={22} /></div>
        <div><h1 className="text-2xl font-black text-[#14181F]" style={{ fontFamily: "Vazirmatn" }}>Review Queue</h1><p className="text-sm text-[#585C66]">{pendingListings.length} Listing pending review</p></div>
      </div>

      {pendingListings.length === 0 ? (
        <div className="text-center py-20 rounded-2xl" style={{ border: `1px dashed ${BORDER}` }}><p className="text-[#585C66] text-sm">Everything reviewed — Queue is empty.</p></div>
      ) : (
        <div className="space-y-3">
          {pendingListings.map((ad) => {
            const cat = catOf(ad.category);
            return (
              <div key={ad.id} className="rounded-2xl p-4 flex items-start gap-4" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
                <SmartImg src={ad.img} alt={ad.title || ""} className="w-20 h-20 rounded-xl object-cover shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 text-[11px] font-bold mb-1" style={{ color: cat.color }}><cat.icon size={11} /> {cat.label}</div>
                  <div className="text-sm text-[#14181F] font-bold truncate mb-1">{ad.title}</div>
                  <div className="text-xs text-[#585C66] mb-2">{ad.owner} · {ad.city} · {ad.price ? fmt(ad.price) : "Negotiable"}</div>
                  <div className="flex gap-2">
                    <button onClick={() => onDecide(ad.id, "approved")} className="flex items-center gap-1 text-xs font-extrabold px-3 py-1.5 rounded-full" style={{ background: LIME, color: INK }}><Check size={12} /> Verify</button>
                    <button onClick={() => onDecide(ad.id, "rejected")} className="flex items-center gap-1 text-xs font-extrabold px-3 py-1.5 rounded-full" style={{ background: SURFACE2, color: "#F43F5E", border: "1px solid #F43F5E44" }}><X size={12} /> Dismiss</button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Seller profile                                                      */
/* ------------------------------------------------------------------ */

function SellerView({ owner, listings, setView, compareIds, onToggleCompare, wishlistIds, onToggleWishlist }) {
  const ads = listings.filter((l) => l.owner === owner);
  const reviewed = ads.filter((a) => a.reviews?.count > 0);
  const totalReviews = reviewed.reduce((s, a) => s + a.reviews.count, 0);
  const avgRating = totalReviews > 0 ? reviewed.reduce((s, a) => s + a.reviews.avg * a.reviews.count, 0) / totalReviews : 0;
  const cats = [...new Set(ads.map((a) => a.category))];

  const buyerItems = listings.flatMap((l) => (l.buyerReviews?.items || []).filter((r) => r.buyerName === owner));
  const buyerAvg = buyerItems.length > 0 ? buyerItems.reduce((s, r) => s + r.stars, 0) / buyerItems.length : 0;
  const isStorefront = ads.length >= 3;
  const bannerCat = ads[0] ? catOf(ads[0].category) : null;

  return (
    <div className="max-w-6xl mx-auto px-4 py-10 pb-24">
      <Crumbs items={[{ label: "Home", onClick: () => setView({ name: "home" }) }, { label: owner }]} />

      {isStorefront && (
        <div className="relative h-32 md:h-40 rounded-2xl overflow-hidden mb-[-56px]" style={{ border: `1px solid ${BORDER}` }}>
          <SmartImg src={`https://picsum.photos/seed/${owner}-banner/1200/300`} alt="" role="presentation" className="w-full h-full object-cover" />
          <div className="absolute inset-0" style={{ background: `linear-gradient(180deg, ${bannerCat?.color || LIME}22, rgba(20,24,31,.45))` }} />
          <span className="absolute top-3 left-3 text-[10px] font-extrabold px-2.5 py-1 rounded-full flex items-center gap-1" style={{ background: LIME, color: INK }}>
            <Sparkles size={9} /> Dedicated showcase
          </span>
        </div>
      )}

      <div className={`rounded-2xl p-6 mb-8 flex flex-wrap items-center gap-5 relative ${isStorefront ? "pt-14" : ""}`} style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
        <span className={`rounded-full flex items-center justify-center font-black shrink-0 ${isStorefront ? "w-20 h-20 text-3xl" : "w-16 h-16 text-2xl"}`} style={{ background: LIME, color: INK, border: isStorefront ? `4px solid ${CARD}` : "none" }}>{owner.slice(0, 1)}</span>
        <div className="flex-1 min-w-[180px]">
          <div className="flex items-center gap-1.5 mb-1">
            <h1 className="text-xl font-black text-[#14181F]" style={{ fontFamily: "Vazirmatn" }}>{owner}</h1>
            <BadgeCheck size={16} color={LIME} />
          </div>
          <p className="text-xs text-[#585C66] mb-2">{isStorefront ? "Active SPENTA seller" : "SPENTA seller"}</p>
          <TrustBadge owner={owner} />
        </div>
        <div className="flex items-center gap-5">
          <div className="text-center">
            <div className="text-lg font-black text-[#14181F]" style={{ fontFamily: "JetBrains Mono" }}>{ads.length}</div>
            <div className="text-[10px] text-[#585C66] font-bold">Active listing</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-black text-[#14181F] flex items-center gap-1 justify-center" style={{ fontFamily: "JetBrains Mono" }}>
              {totalReviews > 0 ? avgRating.toFixed(1) : "—"}
              {totalReviews > 0 && <Star size={13} fill="#FBBF24" color="#FBBF24" />}
            </div>
            <div className="text-[10px] text-[#585C66] font-bold">{totalReviews} Review as seller</div>
          </div>
          {buyerItems.length > 0 && (
            <div className="text-center">
              <div className="text-lg font-black text-[#14181F] flex items-center gap-1 justify-center" style={{ fontFamily: "JetBrains Mono" }}>
                {buyerAvg.toFixed(1)}
                <Star size={13} fill="#FBBF24" color="#FBBF24" />
              </div>
              <div className="text-[10px] text-[#585C66] font-bold">{buyerItems.length} Review as buyer</div>
            </div>
          )}
        </div>
      </div>

      <Eyebrow>listings {owner}</Eyebrow>
      {cats.length > 1 && (
        <p className="text-xs text-[#585C66] mb-4">active in {cats.length} different categories: {cats.map((id) => catOf(id).label).join(", ")}</p>
      )}
      {ads.length === 0 ? (
        <div className="text-center py-16 rounded-2xl" style={{ border: `1px dashed ${BORDER}` }}><p className="text-[#585C66] text-sm">No listings found for this user.</p></div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {ads.map((ad) => <AdCard key={ad.id} ad={ad} onOpen={(ad) => setView({ name: "detail", ad })} compareIds={compareIds} onToggleCompare={onToggleCompare} wishlistIds={wishlistIds} onToggleWishlist={onToggleWishlist} />)}
        </div>
      )}
    </div>
  );
}

function ProfileEditor({ user, onSave }) {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ name: user.name || "", email: user.email || "", phone: user.phone || "", city: user.city || CITIES[0], address: user.address || "", postalCode: user.postalCode || "", bio: user.bio || "" });
  const save = () => { onSave({ ...user, ...form }); setEditing(false); };
  if (!editing) {
    return (
      <div className="rounded-2xl p-5 mb-8" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
        <div className="flex items-center justify-between mb-4">
          <Eyebrow>Account info</Eyebrow>
          <button onClick={() => setEditing(true)} className="text-xs font-extrabold px-3.5 py-1.5 rounded-full" style={{ background: `${LIME}18`, color: LIME }}>Edit profile</button>
        </div>
        <div className="grid sm:grid-cols-2 gap-3 text-sm">
          <div><span className="text-[#585C66] text-xs block mb-1">Name</span><span className="text-[#14181F] font-bold">{user.name}</span></div>
          <div><span className="text-[#585C66] text-xs block mb-1">Email</span><span className="text-[#14181F] font-bold" style={{ direction: "ltr", display: "inline-block" }}>{user.email || "—"}</span></div>
          <div><span className="text-[#585C66] text-xs block mb-1">Phone number</span><span className="text-[#14181F] font-bold" style={{ direction: "ltr", display: "inline-block" }}>{user.phone || "—"}</span></div>
          <div><span className="text-[#585C66] text-xs block mb-1">City</span><span className="text-[#14181F] font-bold">{user.city || "—"}</span></div>
          <div><span className="text-[#585C66] text-xs block mb-1">Address</span><span className="text-[#14181F] font-bold">{user.address || "—"}</span></div>
          <div><span className="text-[#585C66] text-xs block mb-1">Postal code</span><span className="text-[#14181F] font-bold" style={{ direction: "ltr", display: "inline-block" }}>{user.postalCode || "—"}</span></div>
          {user.bio && <div className="sm:col-span-2"><span className="text-[#585C66] text-xs block mb-1">About me</span><span className="text-[#14181F]">{user.bio}</span></div>}
        </div>
      </div>
    );
  }
  return (
    <div className="rounded-2xl p-5 mb-8" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
      <Eyebrow>Edit profile</Eyebrow>
      <div className="space-y-3 mb-4">
        <Field label="Full name">
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full rounded-xl px-3.5 py-2.5 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}` }} />
        </Field>
        <Field label="Email">
          <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} type="email" className="w-full rounded-xl px-3.5 py-2.5 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}`, direction: "ltr" }} />
        </Field>
        <Field label="Phone number">
          <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} type="tel" className="w-full rounded-xl px-3.5 py-2.5 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}`, direction: "ltr" }} />
        </Field>
        <Field label="City">
          <select value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="w-full rounded-xl px-3.5 py-2.5 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
            {CITIES.map((c) => <option key={c}>{c}</option>)}
          </select>
        </Field>
        <Field label="Street address">
          <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="w-full rounded-xl px-3.5 py-2.5 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}` }} />
        </Field>
        <Field label="Postal / ZIP code">
          <input value={form.postalCode} onChange={(e) => setForm({ ...form, postalCode: e.target.value })} className="w-full rounded-xl px-3.5 py-2.5 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}`, direction: "ltr" }} />
        </Field>
        <Field label="About me">
          <textarea value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} className="w-full rounded-xl px-3.5 py-2.5 text-sm text-[#14181F] outline-none resize-none h-20" style={{ background: SURFACE, border: `1px solid ${BORDER}` }} />
        </Field>
      </div>
      <div className="flex gap-2">
        <button onClick={() => setEditing(false)} className="flex-1 text-[#14181F] text-sm font-bold py-2.5 rounded-full" style={{ border: `1px solid ${BORDER}` }}>Cancel</button>
        <button onClick={save} disabled={!form.name.trim()} className="flex-1 font-extrabold text-sm py-2.5 rounded-full disabled:opacity-30" style={{ background: LIME, color: "#fff" }}>Save changes</button>
      </div>
    </div>
  );
}

const STATUS_META = {
  approved: { label: "Verified", color: "#22C55E" },
  pending: { label: "Pending review", color: "#EAB308" },
  rejected: { label: "Rejected", color: "#F43F5E" },
};

const ID_TYPES = ["Passport", "National ID", "Driver's License"];

function VerificationCard({ user, onSave, showToast }) {
  const [open, setOpen] = useState(false);
  const [idType, setIdType] = useState(ID_TYPES[0]);
  const [idNumber, setIdNumber] = useState("");
  const [address, setAddress] = useState(user.address || "");
  const [postalCode, setPostalCode] = useState(user.postalCode || "");
  const [fileName, setFileName] = useState("");
  const lotNo = String(user.email || user.name).split("").reduce((h, c) => (h * 31 + c.charCodeAt(0)) >>> 0, 7).toString().slice(-6).padStart(6, "0");
  const isVerified = user.verificationStatus === "verified";
  const isPending = user.verificationStatus === "pending";
  const [justVerified, setJustVerified] = useState(false);

  const submitRequest = () => {
    if (!idNumber.trim() || !address.trim()) return;
    onSave({ ...user, address: address.trim(), postalCode: postalCode.trim(), verificationStatus: "pending" });
    setOpen(false);
    showToast("Identity verification request submitted");
    setTimeout(() => {
      onSave({ ...user, address: address.trim(), postalCode: postalCode.trim(), verificationStatus: "verified" });
      showToast("Your identity is verified! 🎉");
      setJustVerified(true);
    }, 4000);
  };

  return (
    <div className="mb-8">
      {justVerified && <Confetti onDone={() => setJustVerified(false)} />}
      {/* the membership card */}
      <div
        className="relative rounded-2xl p-6 overflow-hidden mb-4"
        style={{
          background: `radial-gradient(ellipse 130% 100% at 15% -10%, #1E2430 0%, ${INK} 60%)`,
          minHeight: 190,
          boxShadow: "0 24px 50px -20px rgba(20,24,31,.5)",
        }}
      >
        <span className="lot-corner lot-corner-tl" style={{ borderColor: GOLD, opacity: 1, top: 14, insetInlineStart: 14 }} />
        <span className="lot-corner lot-corner-tr" style={{ borderColor: GOLD, opacity: 1, top: 14, insetInlineEnd: 14 }} />
        <span className="lot-corner lot-corner-bl" style={{ borderColor: GOLD, opacity: 1, bottom: 14, insetInlineStart: 14 }} />
        <span className="lot-corner lot-corner-br" style={{ borderColor: GOLD, opacity: 1, bottom: 14, insetInlineEnd: 14 }} />

        <div className="flex items-start justify-between mb-8">
          <div>
            <div className="text-[10px] font-bold uppercase mb-0.5" style={{ color: GOLD, letterSpacing: "0.16em" }}>SPENTA</div>
            <div className="text-[9px]" style={{ color: "rgba(247,244,236,.4)", fontFamily: "JetBrains Mono" }}>MEMBERSHIP CARD</div>
          </div>
          <span
            className="text-[9px] font-extrabold uppercase px-2.5 py-1 rounded-full flex items-center gap-1"
            style={{
              letterSpacing: "0.08em",
              color: isVerified ? "#22C55E" : isPending ? "#EAB308" : "rgba(247,244,236,.5)",
              background: isVerified ? "rgba(34,197,94,.15)" : isPending ? "rgba(234,179,8,.15)" : "rgba(247,244,236,.08)",
            }}
          >
            {isVerified ? <BadgeCheck size={11} /> : isPending ? <Loader2 size={11} className="animate-spin" /> : <ShieldCheck size={11} />}
            {isVerified ? "Verified" : isPending ? "Pending" : "Unverified"}
          </span>
        </div>

        <div className="w-9 h-7 rounded flex items-center justify-center mb-4" style={{ background: `linear-gradient(135deg, ${GOLD}, #B8892E)` }}>
          <div className="w-6 h-4 rounded-sm" style={{ border: "1px solid rgba(20,24,31,.35)" }} />
        </div>

        <div className="text-lg font-bold mb-0.5" style={{ color: "#F7F4EC", fontFamily: SERIF }}>{user.name}</div>
        <div className="flex items-center justify-between">
          <span className="text-xs" style={{ color: "rgba(247,244,236,.5)", fontFamily: "JetBrains Mono", letterSpacing: "0.05em" }}>№ {lotNo}</span>
          <span className="text-xs" style={{ color: "rgba(247,244,236,.5)" }}>{user.city || "—"}</span>
        </div>
      </div>

      {isVerified ? (
        <div className="rounded-2xl p-4 flex items-center gap-3" style={{ background: `#22C55E14`, border: `1px solid #22C55E44` }}>
          <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0" style={{ background: "#22C55E22", color: "#22C55E" }}><BadgeCheck size={20} /></div>
          <div><div className="text-sm text-[#14181F] font-bold">Your identity is verified</div><div className="text-[11px] text-[#585C66]">This badge also appears on your public profile</div></div>
        </div>
      ) : isPending ? (
        <div className="rounded-2xl p-4 flex items-center gap-3" style={{ background: `#EAB30814`, border: `1px solid #EAB30844` }}>
          <Loader2 size={18} className="animate-spin shrink-0" color="#EAB308" />
          <div><div className="text-sm text-[#14181F] font-bold">Your request is under review</div><div className="text-[11px] text-[#585C66]">It usually takes just a moment (Demo version)</div></div>
        </div>
      ) : (
        <div className="rounded-2xl p-5" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
          <div className="flex items-center justify-between mb-1">
            <Eyebrow>Identity verification</Eyebrow>
            {!open && <button onClick={() => setOpen(true)} className="text-xs font-extrabold px-3.5 py-1.5 rounded-full" style={{ background: `${LIME}18`, color: LIME }}>Verify now</button>}
          </div>
          <p className="text-xs text-[#585C66]">With identity verification, a badge ✓ and buyers trust your listings more.</p>
          {open && (
            <div className="mt-4 pt-4 space-y-3" style={{ borderTop: `1px solid ${BORDER}` }}>
              <div className="grid grid-cols-2 gap-3">
                <select value={idType} onChange={(e) => setIdType(e.target.value)} className="w-full rounded-xl px-3.5 py-2.5 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}` }}>
                  {ID_TYPES.map((t) => <option key={t}>{t}</option>)}
                </select>
                <input value={idNumber} onChange={(e) => setIdNumber(e.target.value)} placeholder="Document number" className="w-full rounded-xl px-3.5 py-2.5 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}` }} />
              </div>
              <input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Street address" className="w-full rounded-xl px-3.5 py-2.5 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}` }} />
              <input value={postalCode} onChange={(e) => setPostalCode(e.target.value)} placeholder="Postal / ZIP code" className="w-full rounded-xl px-3.5 py-2.5 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}`, direction: "ltr" }} />
              <label className="flex items-center gap-2.5 rounded-xl px-3.5 py-2.5 cursor-pointer" style={{ background: SURFACE, border: `1px dashed ${BORDER}` }}>
                <ImageIcon size={16} color="#585C66" />
                <span className="text-xs text-[#585C66] flex-1">{fileName || "Upload ID photo (optional in this version)"}</span>
                <input type="file" className="hidden" onChange={(e) => setFileName(e.target.files?.[0]?.name || "")} />
              </label>
              <div className="flex gap-2">
                <button onClick={() => setOpen(false)} className="flex-1 text-[#14181F] text-sm font-bold py-2.5 rounded-full" style={{ border: `1px solid ${BORDER}` }}>Cancel</button>
                <button onClick={submitRequest} disabled={!idNumber.trim() || !address.trim()} className="flex-1 font-extrabold text-sm py-2.5 rounded-full disabled:opacity-30" style={{ background: LIME, color: "#fff" }}>Send request</button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Dashboard({ user, setUser, listings, setView, compareIds, onToggleCompare, wishlistIds, onToggleWishlist, onSaveProfile, showToast, onDelete, onRenew }) {
  const mine = listings.filter((l) => l.owner === user.name);
  const approvedActive = mine.filter((l) => l.status === "approved" && !isExpired(l));
  const approvedExpired = mine.filter((l) => l.status === "approved" && isExpired(l));
  const pending = mine.filter((l) => l.status === "pending");
  const [confirmDelete, setConfirmDelete] = useState(null);
  const stats = [
    { label: "Active listing", value: approvedActive.length, icon: ShieldCheck, color: LIME },
    { label: "Pending review", value: pending.length, icon: Clock, color: "#EAB308" },
    { label: "Total listings", value: mine.length, icon: Package, color: "#06B6D4" },
  ];
  const ownerActions = (ad) => (
    <div className="flex items-center gap-1.5 mt-2">
      <button onClick={() => setView({ name: "post", editingAd: ad })} className="flex-1 flex items-center justify-center gap-1 text-[11px] font-bold py-1.5 rounded-full" style={{ border: `1px solid ${BORDER}`, color: "#14181F" }}><Pencil size={11} /> Edit</button>
      {isExpired(ad) && (
        <button onClick={() => onRenew(ad.id)} className="flex-1 flex items-center justify-center gap-1 text-[11px] font-bold py-1.5 rounded-full" style={{ background: LIME, color: INK }}><RefreshCw size={11} /> Renew</button>
      )}
      {confirmDelete === ad.id ? (
        <button onClick={() => { onDelete(ad.id); setConfirmDelete(null); }} className="flex-1 flex items-center justify-center gap-1 text-[11px] font-bold py-1.5 rounded-full" style={{ background: "#F43F5E", color: "#fff" }}>Are you sure?</button>
      ) : (
        <button onClick={() => setConfirmDelete(ad.id)} className="w-8 h-8 flex items-center justify-center rounded-full shrink-0" style={{ border: `1px solid ${BORDER}`, color: "#F43F5E" }}><Trash2 size={13} /></button>
      )}
    </div>
  );
  return (
    <div className="max-w-4xl mx-auto px-4 py-10 pb-24">
      <div className="flex items-center justify-between mb-8 pb-6" style={{ borderBottom: `1px solid ${BORDER}` }}>
        <div>
          <div className="text-[10px] font-bold uppercase mb-1.5" style={{ color: LIME, letterSpacing: "0.14em" }}>Welcome back</div>
          <div className="text-[#14181F] font-bold text-2xl" style={{ fontFamily: SERIF }}>{user.name}</div>
        </div>
        <button onClick={() => { setUser(null); setView({ name: "home" }); }} className="flex items-center gap-1.5 text-xs font-bold px-3.5 py-2 rounded-full" style={{ border: `1px solid ${BORDER}`, color: "#585C66" }}><LogOut size={13} /> Log out</button>
      </div>

      <VerificationCard user={user} onSave={onSaveProfile} showToast={showToast} />
      <ProfileEditor user={user} onSave={onSaveProfile} />

      <div className="grid sm:grid-cols-3 gap-px mb-12" style={{ background: BORDER_SOFT, border: `1px solid ${BORDER_SOFT}` }}>
        {stats.map((s, i) => (
          <div key={s.label} className="p-5" style={{ background: CARD }}>
            <div className="flex items-center justify-between mb-3">
              <span className="text-[9px] font-bold" style={{ color: "#8B8E99", fontFamily: "JetBrains Mono" }}>{String(i + 1).padStart(2, "0")}</span>
              <s.icon size={15} style={{ color: s.color }} />
            </div>
            <div className="text-2xl font-bold text-[#14181F] mb-1" style={{ fontFamily: SERIF }}>{s.value}</div>
            <div className="flex items-center gap-1.5">
              <span className="w-4 h-px" style={{ background: s.color }} />
              <span className="text-[10px] font-bold" style={{ color: "#585C66" }}>{s.label}</span>
            </div>
          </div>
        ))}
      </div>

      {approvedActive.length > 0 && <DashboardInsights listings={approvedActive} />}

      <div className="flex items-center justify-between mb-5">
        <div><Eyebrow>My Listings</Eyebrow></div>
        <button onClick={() => setView({ name: "post" })} className="flex items-center gap-1.5 font-extrabold text-xs px-3.5 py-2 rounded-full" style={{ background: LIME, color: INK }}><Plus size={13} /> New listing</button>
      </div>

      {mine.length === 0 ? (
        <div className="text-center py-16 rounded-2xl" style={{ border: `1px dashed ${BORDER}` }}><p className="text-[#585C66] text-sm">You haven't posted any listings yet.</p></div>
      ) : (
        <>
          {pending.length > 0 && (
            <div className="space-y-2 mb-6">
              {pending.map((ad) => (
                <div key={ad.id} className="rounded-2xl p-3" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
                  <div className="flex items-center gap-3">
                    <SmartImg src={ad.img} alt={ad.title || ""} className="w-12 h-12 rounded-xl object-cover shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm text-[#14181F] font-bold truncate">{ad.title}</div>
                      <div className="text-[11px] flex items-center gap-1 font-bold" style={{ color: STATUS_META.pending.color }}><Clock size={11} /> Pending review by the SPENTA team</div>
                    </div>
                  </div>
                  {ownerActions(ad)}
                </div>
              ))}
            </div>
          )}
          {approvedExpired.length > 0 && (
            <div className="space-y-2 mb-6">
              {approvedExpired.map((ad) => (
                <div key={ad.id} className="rounded-2xl p-3" style={{ background: CARD, border: `1px solid #EAB30855`, boxShadow: CARD_SHADOW }}>
                  <div className="flex items-center gap-3">
                    <SmartImg src={ad.img} alt={ad.title || ""} className="w-12 h-12 rounded-xl object-cover shrink-0" style={{ opacity: 0.6 }} />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm text-[#14181F] font-bold truncate">{ad.title}</div>
                      <div className="text-[11px] flex items-center gap-1 font-bold" style={{ color: "#EAB308" }}><Clock size={11} /> Expired — is no longer shown on the site</div>
                    </div>
                  </div>
                  {ownerActions(ad)}
                </div>
              ))}
            </div>
          )}
          {approvedActive.length > 0 && (
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
              {approvedActive.map((ad) => (
                <div key={ad.id}>
                  <AdCard ad={ad} onOpen={(ad) => setView({ name: "detail", ad })} compareIds={compareIds} onToggleCompare={onToggleCompare} wishlistIds={wishlistIds} onToggleWishlist={onToggleWishlist} />
                  {ownerActions(ad)}
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Support                                                             */
/* ------------------------------------------------------------------ */

const FAQ = [
  { q: "How do I post a listing?", a: "Tap the «Post a Free Ad» button, pick a category, fill in the details, and confirm the display plan or fee model." },
  { q: "How is the fee calculated?", a: "For real estate, vehicles and motorcycles, a percentage of the amount is only deducted once a deal actually closes through SPENTA. For other categories, you just pay a flat subscription fee." },
  { q: "How does listing comparison work?", a: "Tap the scale icon on any listing card to add it to your comparison list. Only listings in the same category can be compared." },
  { q: "How do I contact the seller?", a: "From the listing page, send a message or reveal the phone number." },
];

function FaqItem({ item }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-2xl overflow-hidden" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
      <button onClick={() => setOpen(!open)} className="w-full flex items-center justify-between p-4 text-start">
        <span className="text-sm font-bold text-[#14181F]">{item.q}</span>
        <ChevronDown size={16} className="text-[#585C66] transition-transform" style={{ transform: open ? "rotate(180deg)" : "none" }} />
      </button>
      {open && <div className="px-4 pb-4 text-sm text-[#585C66] leading-relaxed">{item.a}</div>}
    </div>
  );
}

const FIAT_SYMBOLS = "EUR,GBP,AED,TRY,CAD,MYR,CHF,JPY,CNY,AUD";
const CRYPTO_IDS = "bitcoin,ethereum,tether,binancecoin,solana,ripple,dogecoin,cardano";
const GOLD_IDS = "pax-gold,tether-gold";
const COIN_META = {
  bitcoin: { symbol: "BTC", name: "Bitcoin" },
  ethereum: { symbol: "ETH", name: "Ethereum" },
  tether: { symbol: "USDT", name: "Tether" },
  binancecoin: { symbol: "BNB", name: "BNB" },
  solana: { symbol: "SOL", name: "Solana" },
  ripple: { symbol: "XRP", name: "XRP" },
  dogecoin: { symbol: "DOGE", name: "Dogecoin" },
  cardano: { symbol: "ADA", name: "Cardano" },
};
const CURRENCY_META = {
  EUR: { flag: "🇪🇺", name: "Euro" }, GBP: { flag: "🇬🇧", name: "British Pound" },
  AED: { flag: "🇦🇪", name: "UAE Dirham" }, TRY: { flag: "🇹🇷", name: "Turkish Lira" },
  CAD: { flag: "🇨🇦", name: "Canadian Dollar" }, MYR: { flag: "🇲🇾", name: "Malaysian Ringgit" },
  CHF: { flag: "🇨🇭", name: "Swiss Franc" }, JPY: { flag: "🇯🇵", name: "Japanese Yen" },
  CNY: { flag: "🇨🇳", name: "Chinese Yuan" }, AUD: { flag: "🇦🇺", name: "Australian Dollar" },
};

function MarketDataView({ setView }) {
  const [fiat, setFiat] = useState(null);
  const [crypto, setCrypto] = useState(null);
  const [gold, setGold] = useState(null);
  const [status, setStatus] = useState("loading"); // loading | ok | error
  const [lastUpdated, setLastUpdated] = useState(null);
  const [secondsAgo, setSecondsAgo] = useState(0);

  const loadAll = async () => {
    try {
      const [fiatRes, cryptoRes] = await Promise.all([
        fetch(`https://api.frankfurter.app/latest?from=USD&to=${FIAT_SYMBOLS}`),
        fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${CRYPTO_IDS},${GOLD_IDS}&vs_currencies=usd&include_24hr_change=true`),
      ]);
      if (!fiatRes.ok || !cryptoRes.ok) throw new Error("bad response");
      const fiatData = await fiatRes.json();
      const cryptoData = await cryptoRes.json();
      setFiat(fiatData.rates);
      setCrypto(CRYPTO_IDS.split(",").map((id) => ({ id, ...COIN_META[id], price: cryptoData[id]?.usd, change: cryptoData[id]?.usd_24h_change })));
      setGold({
        paxg: cryptoData["pax-gold"]?.usd,
        xaut: cryptoData["tether-gold"]?.usd,
      });
      setStatus("ok");
      setLastUpdated(Date.now());
    } catch (e) {
      setStatus("error");
    }
  };

  useEffect(() => {
    loadAll();
    const poll = setInterval(loadAll, 60000);
    return () => clearInterval(poll);
  }, []);

  useEffect(() => {
    const tick = setInterval(() => { if (lastUpdated) setSecondsAgo(Math.floor((Date.now() - lastUpdated) / 1000)); }, 1000);
    return () => clearInterval(tick);
  }, [lastUpdated]);

  const goldAvg = gold && gold.paxg && gold.xaut ? (gold.paxg + gold.xaut) / 2 : gold?.paxg || gold?.xaut;

  return (
    <div>
      <div className="py-9" style={{ background: `radial-gradient(ellipse 130% 100% at 50% 0%, #171B24 0%, #0A0C10 100%)`, borderBottom: `1px solid rgba(229,185,78,.18)` }}>
        <div className="max-w-5xl mx-auto px-4">
          <Crumbs items={[{ label: "Home", onClick: () => setView({ name: "home" }) }, { label: "Currency & Gold Market" }]} dark />
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-4">
              <span className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0" style={{ background: "rgba(229,185,78,.12)", border: `1px solid rgba(229,185,78,.3)` }}>
                <Coins size={22} color={GOLD} />
              </span>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold" style={{ color: "#F7F4EC", fontFamily: SERIF }}>Currency & Gold Market</h1>
                <p className="text-sm mt-1" style={{ color: "rgba(247,244,236,.6)" }}>Live rates for major currencies, tokenized gold, and top cryptocurrencies</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-full" style={{ background: status === "ok" ? "rgba(34,197,94,.12)" : "rgba(247,244,236,.08)", color: status === "ok" ? "#22C55E" : "rgba(247,244,236,.5)" }}>
              <span className={`w-1.5 h-1.5 rounded-full ${status === "ok" ? "animate-pulse" : ""}`} style={{ background: status === "ok" ? "#22C55E" : "#8B8E99" }} />
              {status === "loading" ? "Connecting…" : status === "error" ? "Connection issue" : `Updated ${secondsAgo}s ago`}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-10 pb-24">
        {status === "error" && (
          <div className="rounded-2xl p-5 mb-8 flex items-center gap-3" style={{ background: "#F43F5E14", border: `1px solid #F43F5E44` }}>
            <Info size={18} color="#F43F5E" className="shrink-0" />
            <div>
              <div className="text-sm font-bold text-[#14181F]">Couldn't reach live market data</div>
              <div className="text-xs text-[#585C66]">This may be a temporary network issue. <button onClick={loadAll} className="font-bold underline">Try again</button></div>
            </div>
          </div>
        )}

        <Eyebrow>Gold</Eyebrow>
        <p className="text-xs text-[#585C66] mb-4">Sourced from tokenized gold (PAX Gold & Tether Gold), each backed 1:1 by physical gold — used here as a real-time proxy for spot gold price, not an official LBMA feed.</p>
        <div className="grid sm:grid-cols-3 gap-3 mb-10">
          <div className="rounded-2xl p-5 sm:col-span-1" style={{ background: `linear-gradient(135deg, #B8892E, ${GOLD})`, color: INK }}>
            <div className="text-[10px] font-bold uppercase mb-1" style={{ letterSpacing: "0.1em" }}>Gold · USD per troy oz</div>
            <div className="text-3xl font-bold" style={{ fontFamily: SERIF }}>{goldAvg ? `$${goldAvg.toFixed(2)}` : "—"}</div>
          </div>
          {[["paxg", "PAX Gold (PAXG)"], ["xaut", "Tether Gold (XAUT)"]].map(([key, label]) => (
            <div key={key} className="rounded-2xl p-5" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
              <div className="text-[11px] font-bold text-[#585C66] mb-1">{label}</div>
              <div className="text-xl font-bold text-[#14181F]" style={{ fontFamily: "JetBrains Mono" }}>{gold?.[key] ? `$${gold[key].toFixed(2)}` : "—"}</div>
            </div>
          ))}
        </div>

        <Eyebrow>Currencies</Eyebrow>
        <p className="text-xs text-[#585C66] mb-4">All prices on SPENTA are in US Dollars ($). Here's what $1 is worth in other currencies, and vice versa.</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 mb-10">
          {Object.keys(CURRENCY_META).map((code) => (
            <div key={code} className="rounded-xl p-3.5" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}` }}>
              <div className="flex items-center gap-1.5 mb-2">
                <span>{CURRENCY_META[code].flag}</span>
                <span className="text-[11px] font-bold text-[#585C66]">{code}</span>
              </div>
              <div className="mb-1">
                <div className="text-[9px] text-[#8B8E99]">$1 =</div>
                <div className="text-base font-bold text-[#14181F]" style={{ fontFamily: "JetBrains Mono" }}>{fiat?.[code] ? `${fiat[code].toFixed(code === "JPY" ? 1 : 3)} ${code}` : "—"}</div>
              </div>
              <div style={{ borderTop: `1px solid ${BORDER_SOFT}`, paddingTop: 4 }}>
                <div className="text-[9px] text-[#8B8E99]">1 {code} =</div>
                <div className="text-[13px] font-bold" style={{ color: "#585C66", fontFamily: "JetBrains Mono" }}>{fiat?.[code] ? `$${(1 / fiat[code]).toFixed(4)}` : "—"}</div>
              </div>
            </div>
          ))}
        </div>

        <Eyebrow>Cryptocurrency · price in USD</Eyebrow>
        <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-3">
          {(crypto || CRYPTO_IDS.split(",").map((id) => ({ id, ...COIN_META[id] }))).map((c) => {
            const up = c.change >= 0;
            return (
              <div key={c.id} className="rounded-2xl p-4" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-[#14181F]">{c.symbol}</span>
                  <span className="text-[10px] text-[#8B8E99]">{c.name}</span>
                </div>
                <div className="text-lg font-bold text-[#14181F] mb-1" style={{ fontFamily: "JetBrains Mono" }}>{c.price != null ? `$${c.price.toLocaleString(undefined, { maximumFractionDigits: c.price < 1 ? 4 : 2 })}` : "—"}</div>
                {c.change != null && (
                  <span className="text-[11px] font-bold flex items-center gap-1" style={{ color: up ? "#22C55E" : "#F43F5E" }}>
                    {up ? "▲" : "▼"} {Math.abs(c.change).toFixed(2)}%
                  </span>
                )}
              </div>
            );
          })}
        </div>

        <p className="text-[11px] text-[#8B8E99] mt-8">Fiat rates via the European Central Bank (Frankfurter). Crypto & gold prices via CoinGecko. Refreshes automatically every 60 seconds. For informational purposes only — not financial advice.</p>
      </div>
    </div>
  );
}

function SupportView({ setView, showToast }) {
  const [msg, setMsg] = useState("");
  const [email, setEmail] = useState("");
  const submit = () => { if (!msg.trim()) return; setMsg(""); setEmail(""); showToast("Your request has been sent to the support team"); };
  return (
    <div className="max-w-2xl mx-auto px-4 py-10 pb-24">
      <Crumbs items={[{ label: "Home", onClick: () => setView({ name: "home" }) }, { label: "Support" }]} />
      <div className="flex items-center gap-3.5 mb-8">
        <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: `${LIME}22`, color: LIME }}><LifeBuoy size={22} /></div>
        <div><h1 className="text-2xl font-black text-[#14181F]" style={{ fontFamily: "Vazirmatn" }}>Support panel</h1><p className="text-sm text-[#585C66]">Whatever question you have, the SPENTA team is with you</p></div>
      </div>
      <Eyebrow>Frequently Asked Questions</Eyebrow>
      <div className="space-y-2.5 mb-9">{FAQ.map((f) => <FaqItem key={f.q} item={f} />)}</div>
      <Eyebrow>Direct contact</Eyebrow>
      <div className="grid sm:grid-cols-2 gap-3 mb-5">
        <a href="mailto:support@spenta.market" className="flex items-center gap-3 rounded-2xl p-4" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
          <span className="w-10 h-10 rounded-full flex items-center justify-center shrink-0" style={{ background: `${LIME}18`, color: LIME }}><Mail size={17} /></span>
          <div><div className="text-xs text-[#585C66]">Email</div><div className="text-sm font-bold text-[#14181F]" style={{ direction: "ltr" }}>support@spenta.market</div></div>
        </a>
        <a href="tel:+18005550199" className="flex items-center gap-3 rounded-2xl p-4" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
          <span className="w-10 h-10 rounded-full flex items-center justify-center shrink-0" style={{ background: `${LIME}18`, color: LIME }}><Phone size={17} /></span>
          <div><div className="text-xs text-[#585C66]">Phone</div><div className="text-sm font-bold text-[#14181F]" style={{ direction: "ltr" }}>+1 (800) 555-0199</div></div>
        </a>
      </div>
      <div className="rounded-2xl p-5" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
        <div className="grid sm:grid-cols-2 gap-3 mb-3">
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Your email" type="email" className="w-full rounded-xl px-3.5 py-3 text-sm text-[#14181F] outline-none" style={{ background: SURFACE, border: `1px solid ${BORDER}`, direction: "ltr" }} />
          <div className="flex items-center gap-2 text-xs text-[#585C66]"><Mail size={13} /> We usually reply within a few hours</div>
        </div>
        <textarea value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Write your message..." className="w-full rounded-xl p-3.5 text-sm text-[#14181F] placeholder:text-[#585C66] outline-none resize-none h-28 mb-3" style={{ background: SURFACE, border: `1px solid ${BORDER}` }} />
        <button onClick={submit} disabled={!msg.trim()} className="flex items-center gap-2 font-extrabold text-sm px-5 py-2.5 rounded-full disabled:opacity-30" style={{ background: LIME, color: INK }}><Send size={14} /> Send message</button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Magazine                                                            */
/* ------------------------------------------------------------------ */

const MAGAZINE_ARTICLES = [
  {
    id: "global-2026",
    tag: "Market trend",
    title: "The Global Marketplace in 2026: Why Borders No Longer Stop a Deal",
    excerpt: "How platforms like SPENTA have reduced the distance between a seller in Istanbul and a buyer in Vancouver to a few clicks.",
    img: "https://picsum.photos/seed/mag1/900/600",
    paragraphs: [
      "Until just a few years ago, buying a car from another country or renting a home in a city we'd never seen felt complicated and risky. Today, with more transparent pricing, identity verification systems, and direct contact between buyers and sellers, that distance has shrunk dramatically.",
      "What sets today's global marketplace apart from a decade ago is structured trust — not blind trust. When every listing is reviewed before publishing and every seller has a transparent score, the risk of dealing with a stranger on the other side of the world drops significantly.",
      "SPENTA was built from day one on that exact premise: a truly global marketplace, not a local listings site claiming to be global. Right now you can compare a property in Dubai with one in Berlin, or apply to a remote job opening across three continents at once.",
    ],
  },
  {
    id: "safe-deal",
    tag: "Buying guide",
    title: "7 Tips for a Safe Deal in an Online Marketplace",
    excerpt: "Before you send the first dollar, go through this short checklist.",
    img: "https://picsum.photos/seed/mag2/900/600",
    paragraphs: [
      "1. Always talk to the seller through the platform's in-app chat before any financial commitment — Conversations outside the platform usually can't be tracked.",
      "2. Prioritize verified listings and sellers with a transparent trust score; these scores are calculated from clear criteria like identity and phone verification.",
      "3. For high-value items (car, real estate), always consider an in-person viewing or a local representative, even if the distance is far.",
      "4. Keep every price agreement written in the same chat, so you have a record to refer back to if there's a dispute.",
      "5. If something in a listing seems suspicious — Unrealistic price, duplicate photo — use the report button — it helps keep the whole marketplace healthy.",
    ],
  },
  {
    id: "great-listing",
    tag: "Selling guide",
    title: "Behind a Successful Listing: How to Write One People Actually See",
    excerpt: "The difference between a listing that sells in a day and one that sits unanswered for weeks usually comes down to the details.",
    img: "https://picsum.photos/seed/mag3/900/600",
    paragraphs: [
      "A precise, specific title is half the job. Instead of «Apartment for sale», write it «New two-bedroom apartment near the metro, Istanbul» — Key details are what actually surfaces in search.",
      "Clear, plentiful photos build trust. Listings with several photos from different angles noticeably get more views and messages.",
      "Honest descriptions — even about flaws — build more trust than descriptions that sound too perfect — Buyers notice the difference.",
      "And finally: reply to messages quickly. Sellers who respond within a few hours convert views into deals at a noticeably higher rate.",
    ],
  },
  {
    id: "sellers-spotlight",
    tag: "About",
    title: "Conversations with top sellers SPENTA: From Tehran to Vancouver",
    excerpt: "Several active sellers shared their experience of selling in a truly global marketplace.",
    img: "https://picsum.photos/seed/mag4/900/600",
    paragraphs: [
      "For many active sellers on SPENTA, the most exciting part is reaching buyers they'd never reach in a local market — From a car seller in Dubai who found his buyer in London, to a property owner in Vancouver who found her tenant across the ocean.",
      "The common thread in all these experiences? Patience in building a reputation. Trust scores and positive reviews aren't built overnight, but once they are, they dramatically speed up the sales cycle.",
      "In upcoming issues of the Magazine, we'll publish fuller conversations with top sellers in each category.",
    ],
  },
];

function MagazineView({ setView }) {
  return (
    <div className="max-w-5xl mx-auto px-4 py-10 pb-24">
      <Crumbs items={[{ label: "Home", onClick: () => setView({ name: "home" }) }, { label: "SPENTA Magazine" }]} />
      <div className="text-center mb-10">
        <Eyebrow>Magazine</Eyebrow>
        <h1 className="text-3xl md:text-4xl font-black text-[#14181F] mb-2" style={{ fontFamily: SERIF, fontWeight: 800 }}>The SPENTA Magazine</h1>
        <p className="text-sm text-[#585C66] max-w-md mx-auto">Stories, guides, and a look at global market trends</p>
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        {MAGAZINE_ARTICLES.map((a) => (
          <button key={a.id} onClick={() => setView({ name: "article", articleId: a.id })} className="text-start rounded-2xl overflow-hidden text-start" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
            <SmartImg src={a.img} alt={a.title || ""} className="w-full h-44 object-cover" />
            <div className="p-5">
              <span className="text-[10px] font-extrabold px-2 py-1 rounded-full" style={{ background: `${LIME}18`, color: LIME }}>{a.tag}</span>
              <h3 className="text-lg font-black text-[#14181F] mt-2.5 mb-2 leading-snug" style={{ fontFamily: SERIF }}>{a.title}</h3>
              <p className="text-xs text-[#585C66] leading-relaxed line-clamp-2">{a.excerpt}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function ArticleView({ articleId, setView }) {
  const article = MAGAZINE_ARTICLES.find((a) => a.id === articleId) || MAGAZINE_ARTICLES[0];
  const others = MAGAZINE_ARTICLES.filter((a) => a.id !== article.id).slice(0, 3);
  return (
    <div className="max-w-2xl mx-auto px-4 py-10 pb-24">
      <Crumbs items={[{ label: "Home", onClick: () => setView({ name: "home" }) }, { label: "Magazine", onClick: () => setView({ name: "magazine" }) }, { label: article.title }]} />
      <span className="text-[10px] font-extrabold px-2 py-1 rounded-full" style={{ background: `${LIME}18`, color: LIME }}>{article.tag}</span>
      <h1 className="text-2xl md:text-3xl font-black text-[#14181F] mt-3 mb-5 leading-snug" style={{ fontFamily: SERIF, fontWeight: 800 }}>{article.title}</h1>
      <SmartImg src={article.img} alt={article.title || ""} className="w-full h-64 object-cover rounded-2xl mb-6" style={{ border: `1px solid ${BORDER}` }} />
      <div className="space-y-4 mb-10">
        {article.paragraphs.map((p, i) => <p key={i} className="text-sm text-[#2E3340] leading-[2]">{p}</p>)}
      </div>

      {others.length > 0 && (
        <div>
          <Eyebrow>Read more</Eyebrow>
          <div className="space-y-2.5">
            {others.map((a) => (
              <button key={a.id} onClick={() => setView({ name: "article", articleId: a.id })} className="w-full flex items-center gap-3 rounded-xl p-3 text-start" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
                <SmartImg src={a.img} alt={a.title || ""} className="w-14 h-14 rounded-lg object-cover shrink-0" />
                <span className="text-sm text-[#14181F] font-bold flex-1">{a.title}</span>
                <ChevronLeft size={14} className="text-[#585C66]" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  About & Careers                                                     */
/* ------------------------------------------------------------------ */

function Bar({ label, value, max, color }) {
  const pct = max > 0 ? Math.max(4, (value / max) * 100) : 0;
  return (
    <div className="mb-3">
      <div className="flex items-center justify-between text-xs mb-1.5">
        <span className="text-[#14181F] font-bold">{label}</span>
        <span className="text-[#585C66] font-bold" style={{ fontFamily: "JetBrains Mono" }}>{value}</span>
      </div>
      <div className="h-2.5 rounded-full overflow-hidden" style={{ background: SURFACE }}>
        <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}

function MarketStatsView({ listings, setView }) {
  const byCategory = CAT_LIST.map((c) => ({ ...c, count: listings.filter((l) => l.category === c.id).length })).sort((a, b) => b.count - a.count);
  const byCity = CITIES.map((c) => ({ city: c, count: listings.filter((l) => l.city === c).length })).sort((a, b) => b.count - a.count);
  const maxCat = Math.max(...byCategory.map((c) => c.count), 1);
  const maxCity = Math.max(...byCity.map((c) => c.count), 1);
  const totalReviews = listings.reduce((s, l) => s + (l.reviews?.count || 0), 0);
  const featuredCount = listings.filter((l) => l.stamp).length;

  const summary = [
    { label: "Active listing", value: listings.length, icon: Package },
    { label: "Active city", value: new Set(listings.map((l) => l.city)).size, icon: Globe2 },
    { label: "review submitted", value: totalReviews, icon: Star },
    { label: "Featured listing", value: featuredCount, icon: Sparkles },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-10 pb-24">
      <Crumbs items={[{ label: "Home", onClick: () => setView({ name: "home" }) }, { label: "Market stats" }]} />
      <div className="text-center mb-10">
        <Eyebrow>transparency</Eyebrow>
        <h1 className="text-3xl font-black text-[#14181F] mb-2" style={{ fontFamily: SERIF, fontWeight: 800 }}>SPENTA Live Market Stats</h1>
        <p className="text-sm text-[#585C66] max-w-md mx-auto">A clear look at the size and makeup of the market — Right now</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-10">
        {summary.map((s) => (
          <div key={s.label} className="rounded-2xl p-5 text-center" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
            <div className="w-9 h-9 rounded-lg flex items-center justify-center mx-auto mb-2.5" style={{ background: `${LIME}18`, color: LIME }}><s.icon size={16} /></div>
            <div className="text-xl font-black text-[#14181F]" style={{ fontFamily: "JetBrains Mono" }}><CountUp value={s.value} /></div>
            <div className="text-[10px] text-[#585C66] font-bold mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <div className="rounded-2xl p-5" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
          <Eyebrow>Most popular categories</Eyebrow>
          {byCategory.map((c) => <Bar key={c.id} label={c.label} value={c.count} max={maxCat} color={c.color} />)}
        </div>
        <div className="rounded-2xl p-5" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
          <Eyebrow color={CYAN}>Most active cities</Eyebrow>
          {byCity.map((c) => <Bar key={c.city} label={c.city} value={c.count} max={maxCity} color={CYAN} />)}
        </div>
      </div>
    </div>
  );
}

function AboutView({ setView, listings }) {
  const cities = new Set(listings.map((l) => l.city)).size;
  const stats = [
    { label: "Active listing", value: listings.length },
    { label: "Active city", value: cities },
    { label: "Category", value: CAT_LIST.length },
  ];
  return (
    <div className="max-w-2xl mx-auto px-4 py-10 pb-24">
      <Crumbs items={[{ label: "Home", onClick: () => setView({ name: "home" }) }, { label: "About us" }]} />
      <div className="flex items-center gap-3.5 mb-8">
        <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: `${LIME}22`, color: LIME }}><Info size={22} /></div>
        <div><h1 className="text-2xl font-black text-[#14181F]" style={{ fontFamily: "Vazirmatn" }}>About SPENTA</h1><p className="text-sm text-[#585C66]">One global showcase for everything</p></div>
      </div>

      <div className="rounded-2xl p-5 mb-6" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
        <p className="text-sm text-[#2E3340] leading-relaxed mb-4">
          SPENTA is a global online marketplace with a simple goal: anything you want to buy, sell, or rent — A home, a car, a motorcycle, a job, goods or services — in a single showcase, with no border or language limits.
        </p>
        <p className="text-sm text-[#2E3340] leading-relaxed">
          Our role is purely to connect: the seller posts their listing, the visitor contacts them directly, and the deal happens between the two of them. SPENTA only provides a secure channel for this contact.
        </p>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-6">
        {stats.map((s) => (
          <div key={s.label} className="rounded-2xl p-4 text-center" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
            <div className="text-xl font-black text-[#14181F]" style={{ fontFamily: "JetBrains Mono" }}>{s.value}</div>
            <div className="text-[10px] text-[#585C66] font-bold mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      <button onClick={() => setView({ name: "support" })} className="w-full flex items-center justify-center gap-2 font-extrabold text-sm py-3 rounded-full" style={{ background: LIME, color: INK }}>
        <Mail size={15} /> Contact the team SPENTA
      </button>
    </div>
  );
}

const LEGAL_CONTENT = {
  terms: {
    title: "Terms & Conditions",
    icon: Scale,
    sections: [
      { h: "1. General", p: "By using SPENTA you agree to these terms. SPENTA is only the intermediary platform between sellers and visitors and is not a party to the final deal between them." },
      { h: "2. Posting a listing", p: "The seller is responsible for the accuracy of their listing's information, photos, and price. Fake, misleading, duplicate listings or ones that violate local law will be removed, and the account may be restricted." },
      { h: "3. Fees", p: "In fee-based categories, a percentage is only deducted once a deal actually closes through SPENTA. Posting a listing is always free." },
      { h: "4. Liability", p: "SPENTA is not responsible for the accuracy of listings, product/service quality, or the outcome of deals between users. We recommend verifying the other party's identity and terms before any deal." },
      { h: "5. Account suspension", p: "SPENTA reserves the right to suspend or delete accounts that violate these terms." },
    ],
  },
  privacy: {
    title: "Privacy",
    icon: ShieldCheck,
    sections: [
      { h: "1. Data we collect", p: "Name, email, phone number, city, and any information you provide when signing up or posting a listing." },
      { h: "2. How we use your data", p: "This information is used only to display listings, connect buyers and sellers, and improve your experience on the site." },
      { h: "3. Sharing", p: "Your phone number and email are shown only on the listings you publish yourself; they're never shared with third parties without your consent." },
      { h: "4. Security", p: "A password is used to log in. We recommend choosing a strong, unique password." },
      { h: "5. Account deletion", p: "You can request account and data deletion at any time via the Contact Us page." },
    ],
  },
};

function LegalView({ setView, kind = "terms" }) {
  const content = LEGAL_CONTENT[kind] || LEGAL_CONTENT.terms;
  const Icon = content.icon;
  return (
    <div className="max-w-2xl mx-auto px-4 py-10 pb-24">
      <Crumbs items={[{ label: "Home", onClick: () => setView({ name: "home" }) }, { label: content.title }]} />
      <div className="flex items-center gap-3.5 mb-8">
        <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: `${LIME}22`, color: LIME }}><Icon size={22} /></div>
        <div><h1 className="text-2xl font-black text-[#14181F]" style={{ fontFamily: "Vazirmatn" }}>{content.title}</h1><p className="text-sm text-[#585C66]">Last updated: 2026</p></div>
      </div>
      <div className="rounded-2xl p-5 space-y-5" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
        {content.sections.map((s) => (
          <div key={s.h}>
            <h2 className="text-sm font-extrabold text-[#14181F] mb-1.5">{s.h}</h2>
            <p className="text-[13px] text-[#585C66] leading-relaxed">{s.p}</p>
          </div>
        ))}
      </div>
      <div className="flex gap-2 mt-4">
        <button onClick={() => setView({ name: "terms" })} className="flex-1 text-xs font-bold py-2.5 rounded-full" style={kind === "terms" ? { background: LIME, color: INK } : { border: `1px solid ${BORDER}`, color: "#585C66" }}>Terms & Conditions</button>
        <button onClick={() => setView({ name: "privacy" })} className="flex-1 text-xs font-bold py-2.5 rounded-full" style={kind === "privacy" ? { background: LIME, color: INK } : { border: `1px solid ${BORDER}`, color: "#585C66" }}>Privacy</button>
      </div>
    </div>
  );
}

function CareersView({ setView, showToast }) {
  const roles = [
    { title: "Frontend Developer", type: "Remote" },
    { title: "Customer Support Specialist", type: "On-site" },
    { title: "Growth & Marketing Specialist", type: "Hybrid" },
  ];
  const apply = () => showToast("Send us your resume via the Contact Us page");
  return (
    <div className="max-w-2xl mx-auto px-4 py-10 pb-24">
      <Crumbs items={[{ label: "Home", onClick: () => setView({ name: "home" }) }, { label: "Careers" }]} />
      <div className="flex items-center gap-3.5 mb-8">
        <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: `${LIME}22`, color: LIME }}><Briefcase size={22} /></div>
        <div><h1 className="text-2xl font-black text-[#14181F]" style={{ fontFamily: "Vazirmatn" }}>Work with SPENTA</h1><p className="text-sm text-[#585C66]">Join a team building a global marketplace</p></div>
      </div>

      <p className="text-sm text-[#2E3340] leading-relaxed mb-6">
        We're always looking for curious, energetic people. Even if you don't see the exact role you're after, send us your resume anyway — We'll reach out to you first when the right opportunity opens up.
      </p>

      <Eyebrow>Open positions</Eyebrow>
      <div className="space-y-2.5 mb-8">
        {roles.map((r) => (
          <div key={r.title} className="flex items-center justify-between rounded-2xl p-4" style={{ background: CARD, border: `1px solid ${BORDER_SOFT}`, boxShadow: CARD_SHADOW }}>
            <div><div className="text-sm text-[#14181F] font-bold mb-0.5">{r.title}</div><div className="text-[11px] text-[#585C66]">{r.type}</div></div>
            <button onClick={apply} className="text-xs font-extrabold px-3.5 py-1.5 rounded-full" style={{ background: LIME, color: INK }}>Send resume</button>
          </div>
        ))}
      </div>

      <button onClick={() => setView({ name: "support" })} className="w-full flex items-center justify-center gap-2 font-extrabold text-sm py-3 rounded-full" style={{ border: `1px solid ${BORDER}`, color: INK }}>
        <Mail size={15} /> Send your resume via the Contact Us page
      </button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Footer & floating buttons                                          */
/* ------------------------------------------------------------------ */

function Footer({ setView }) {
  const { t } = useLang();
  return (
    <footer className="py-8" style={{ borderTop: `1px solid ${BORDER}` }}>
      <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#585C66]">
        <div className="flex items-center gap-1.5"><Globe2 size={13} /> SPENTA — {t("footerTagline")}</div>
        <div className="flex items-center gap-4">
          <button onClick={() => setView({ name: "terms" })} className="hover:underline">Terms & Conditions</button>
          <button onClick={() => setView({ name: "privacy" })} className="hover:underline">Privacy</button>
          <span>{t("footerVersion")}</span>
        </div>
      </div>
    </footer>
  );
}

function BottomNav({ view, setView, user, wishlistCount, onMenuClick }) {
  const active = (name) => view.name === name;
  const tabs = [
    { key: "home", icon: HomeIcon, label: "Home", onClick: () => setView({ name: "home" }) },
    { key: "menu", icon: SlidersIcon, label: "Browse", onClick: onMenuClick },
    { key: "post", icon: Plus, label: "Sell", onClick: () => setView({ name: "post" }), center: true },
    { key: "wishlist", icon: Heart, label: "Saved", onClick: () => setView({ name: "wishlist" }), badge: wishlistCount },
    { key: "dashboard", icon: User, label: user ? "Account" : "Sign in", onClick: () => setView({ name: user ? "dashboard" : "auth" }) },
  ];
  return (
    <nav className="sm:hidden fixed bottom-0 inset-x-0 z-40 flex items-stretch" style={{ background: `${INK}F5`, backdropFilter: "blur(10px)", borderTop: `1px solid rgba(247,244,236,.1)`, paddingBottom: "env(safe-area-inset-bottom)" }}>
      {tabs.map((tItem) =>
        tItem.center ? (
          <button key={tItem.key} onClick={tItem.onClick} className="flex-1 flex flex-col items-center justify-center relative">
            <span className="w-12 h-12 rounded-full flex items-center justify-center -mt-5 shadow-lg" style={{ background: GOLD, color: INK }}>
              <tItem.icon size={22} strokeWidth={3} />
            </span>
            <span className="text-[9px] font-bold mt-1" style={{ color: "rgba(247,244,236,.55)" }}>{tItem.label}</span>
          </button>
        ) : (
          <button key={tItem.key} onClick={tItem.onClick} className="flex-1 flex flex-col items-center justify-center gap-1 py-2.5 relative" aria-current={active(tItem.key) ? "page" : undefined}>
            <span className="relative">
              <tItem.icon size={19} strokeWidth={active(tItem.key) ? 2.5 : 2} color={active(tItem.key) ? GOLD : "rgba(247,244,236,.55)"} />
              {!!tItem.badge && (
                <span className="absolute -top-1.5 -end-2 min-w-[14px] h-3.5 px-1 rounded-full text-[8px] font-extrabold flex items-center justify-center" style={{ background: "#F43F5E", color: "#fff" }}>{tItem.badge}</span>
              )}
            </span>
            <span className="text-[9px] font-bold" style={{ color: active(tItem.key) ? GOLD : "rgba(247,244,236,.55)" }}>{tItem.label}</span>
          </button>
        )
      )}
    </nav>
  );
}

function FloatingButtons({ setView }) {
  const [showTop, setShowTop] = useState(false);
  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 400);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <div className="fixed bottom-20 sm:bottom-5 inset-x-0 z-40 flex items-center justify-end sm:justify-between px-5 pointer-events-none gap-3">
      <div className="hidden sm:block" />
      <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="pointer-events-auto w-11 h-11 rounded-full flex items-center justify-center shadow-2xl transition"
        style={{ background: showTop ? PAPER : `${SURFACE}CC`, color: showTop ? INK : "#D8D2C0", border: `1px solid ${BORDER}`, opacity: showTop ? 1 : 0.5 }} aria-label="Back to top"><ArrowUp size={18} /></button>
      <button onClick={() => setView({ name: "support" })} className="pointer-events-auto flex items-center gap-2 font-extrabold text-sm px-4 py-3 rounded-full shadow-2xl" style={{ background: SURFACE, color: INK, border: `1px solid ${BORDER}` }}>
        <LifeBuoy size={17} style={{ color: LIME }} /><span className="hidden sm:inline">Support</span>
      </button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  App                                                                  */
/* ------------------------------------------------------------------ */

function CookieConsentBanner({ setView }) {
  const { lang } = useLang();
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    (async () => {
      try {
        await window.storage.get("cookieConsent", false);
      } catch (e) {
        setVisible(true);
      }
    })();
  }, []);
  const accept = async () => {
    setVisible(false);
    try { await window.storage.set("cookieConsent", "1", false); } catch (e) {}
  };
  if (!visible) return null;
  return (
    <div className="fixed bottom-0 inset-x-0 z-50 p-3 sm:p-4" dir={lang === "fa" ? "rtl" : "ltr"}>
      <div className="max-w-3xl mx-auto rounded-2xl p-4 flex flex-col sm:flex-row items-center gap-3" style={{ background: INK, color: "#F7F4EC", boxShadow: "0 -10px 28px -14px rgba(0,0,0,.35)" }}>
        <Cookie size={20} className="shrink-0" style={{ color: GOLD }} />
        <p className="text-[12.5px] leading-relaxed flex-1">
          We use cookies to make the site work better. By continuing to use SPENTA, you agree
          {" "}with our <button onClick={() => setView({ name: "privacy" })} className="underline font-bold" style={{ color: "inherit" }}>Privacy Policy</button>.
        </p>
        <button onClick={accept} className="shrink-0 font-extrabold text-xs px-4 py-2 rounded-full" style={{ background: LIME, color: INK }}>Got it</button>
      </div>
    </div>
  );
}

function PwaInstallBanner() {
  const { lang } = useLang();
  const [promptEvent, setPromptEvent] = useState(null);
  const [dismissed, setDismissed] = useState(false);
  useEffect(() => {
    const onPrompt = (e) => { e.preventDefault(); setPromptEvent(e); };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);
  if (!promptEvent || dismissed) return null;
  const install = async () => {
    setDismissed(true);
    try { promptEvent.prompt(); await promptEvent.userChoice; } catch (e) {}
  };
  return (
    <div className="fixed bottom-20 sm:bottom-5 inset-x-0 z-50 px-3 sm:px-4" dir={lang === "fa" ? "rtl" : "ltr"}>
      <div className="max-w-md mx-auto rounded-2xl p-3.5 flex items-center gap-3" style={{ background: CARD, border: `1px solid ${BORDER}`, boxShadow: CARD_SHADOW }}>
        <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: LIME }}><Download size={18} color={INK} /></div>
        <div className="flex-1 min-w-0">
          <div className="text-[13px] font-extrabold text-[#14181F]">SPENTA Install</div>
          <div className="text-[11px] text-[#585C66]">Like an app — faster, no browser needed</div>
        </div>
        <button onClick={install} className="shrink-0 font-extrabold text-xs px-3.5 py-2 rounded-full" style={{ background: LIME, color: INK }}>Install</button>
        <button onClick={() => setDismissed(true)} aria-label="Dismiss install prompt" className="shrink-0 w-7 h-7 flex items-center justify-center rounded-full" style={{ color: "#585C66" }}><X size={14} /></button>
      </div>
    </div>
  );
}

function CommandPalette({ open, onClose, setView, user, themeMode, onToggleTheme, lang, setLang }) {
  const [query, setQuery] = useState("");
  const [activeIdx, setActiveIdx] = useState(0);
  const inputRef = useRef(null);

  const actions = useMemo(() => {
    const base = [
      { id: "home", label: "Go to Home", icon: HomeIcon, run: () => setView({ name: "home" }) },
      { id: "post", label: "Post a Free Ad", icon: Plus, run: () => setView({ name: "post" }) },
      { id: "dashboard", label: user ? "My Dashboard" : "Log in / Sign up", icon: User, run: () => setView({ name: user ? "dashboard" : "auth" }) },
      { id: "wishlist", label: "My Wishlist", icon: Heart, run: () => setView({ name: "wishlist" }) },
      { id: "compare", label: "Saved Searches", icon: Bell, run: () => setView({ name: "saved-searches" }) },
      ...CAT_LIST.map((c) => ({ id: "cat-" + c.id, label: `Browse ${catLabel(c, "en")}`, icon: c.icon, run: () => setView({ name: "category", category: c.id }) })),
      { id: "magazine", label: "SPENTA Magazine", icon: BookOpen, run: () => setView({ name: "magazine" }) },
      { id: "stats", label: "Live Market Stats", icon: Package, run: () => setView({ name: "stats" }) },
      { id: "support", label: "Support & FAQ", icon: LifeBuoy, run: () => setView({ name: "support" }) },
      { id: "theme", label: themeMode === "dark" ? "Switch to Light Mode" : "Switch to Dark Mode", icon: themeMode === "dark" ? Sun : Moon, run: () => onToggleTheme() },
      { id: "lang", label: lang === "fa" ? "Switch to English" : "تغییر به فارسی", icon: Globe2, run: () => setLang(lang === "fa" ? "en" : "fa") },
      { id: "terms", label: "Terms & Conditions", icon: Scale, run: () => setView({ name: "terms" }) },
    ];
    if (!query.trim()) return base;
    const q = query.trim().toLowerCase();
    return base.filter((a) => a.label.toLowerCase().includes(q));
  }, [query, user, themeMode, lang]);

  useEffect(() => { setActiveIdx(0); }, [query]);
  useEffect(() => { if (open) { setQuery(""); setActiveIdx(0); setTimeout(() => inputRef.current?.focus(), 30); } }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape") { onClose(); return; }
      if (e.key === "ArrowDown") { e.preventDefault(); setActiveIdx((i) => Math.min(i + 1, actions.length - 1)); }
      else if (e.key === "ArrowUp") { e.preventDefault(); setActiveIdx((i) => Math.max(i - 1, 0)); }
      else if (e.key === "Enter") { e.preventDefault(); const a = actions[activeIdx]; if (a) { a.run(); onClose(); } }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, actions, activeIdx, onClose]);

  if (!open) return null;
  return (
    <div role="dialog" aria-modal="true" aria-label="Command palette" className="fixed inset-0 z-[300] flex items-start justify-center pt-24 px-4" style={{ background: "rgba(8,9,13,.6)" }} onClick={onClose}>
      <div className="w-full max-w-lg rounded-2xl overflow-hidden" style={{ background: CARD, boxShadow: "0 40px 80px -20px rgba(0,0,0,.5)", animation: "popIn .18s ease" }} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-3 px-4 py-3.5" style={{ borderBottom: `1px solid ${BORDER}` }}>
          <Search size={16} className="text-[#585C66] shrink-0" />
          <input ref={inputRef} value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Type a command or search…" className="flex-1 bg-transparent outline-none text-sm text-[#14181F]" />
          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0" style={{ background: SURFACE, color: "#8B8E99", fontFamily: "JetBrains Mono" }}>ESC</span>
        </div>
        <div className="max-h-80 overflow-y-auto py-1.5">
          {actions.length === 0 ? (
            <p className="text-xs text-[#585C66] text-center py-8">No matching commands.</p>
          ) : actions.map((a, i) => (
            <button
              key={a.id}
              onClick={() => { a.run(); onClose(); }}
              onMouseEnter={() => setActiveIdx(i)}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-start"
              style={i === activeIdx ? { background: SURFACE } : {}}
            >
              <span className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0" style={{ background: i === activeIdx ? `${LIME}22` : SURFACE, color: i === activeIdx ? LIME : "#585C66" }}><a.icon size={13} /></span>
              <span className="text-sm text-[#14181F] font-medium flex-1">{a.label}</span>
              {i === activeIdx && <ArrowLeft size={12} className="text-[#8B8E99]" style={{ transform: "scaleX(-1)" }} />}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

class ErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { hasError: false }; }
  static getDerivedStateFromError() { return { hasError: true }; }
  componentDidCatch(error, info) { console.error("SPENTA crashed:", error, info); }
  render() {
    if (this.state.hasError) {
      return (
        <div dir="ltr" style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 16, fontFamily: "Inter, Vazirmatn, sans-serif", background: PAGE_BG, color: INK, padding: 24, textAlign: "center" }}>
          <div style={{ fontSize: 40 }}>😕</div>
          <div style={{ fontWeight: 800, fontSize: 18 }}>Something went wrong</div>
          <div style={{ fontSize: 13, color: MUTED, maxWidth: 380 }}>Something went wrong. Please try again; if it keeps happening, let the support team know.</div>
          <button onClick={() => { this.setState({ hasError: false }); window.location.reload?.(); }} style={{ background: LIME, color: INK, fontWeight: 800, fontSize: 14, padding: "10px 22px", borderRadius: 999, border: "none", cursor: "pointer" }}>Reload</button>
        </div>
      );
    }
    return this.props.children;
  }
}

function AppInner() {
  const [view, setView] = useState({ name: "home" });
  const [user, setUser] = useState(null);
  const [query, setQuery] = useState("");
  const [listings, setListings] = useState(SEED_LISTINGS);
  const [toast, setToast] = useState("");
  const [compareIds, setCompareIds] = useState([]);
  const [wishlistIds, setWishlistIds] = useState([]);
  const [recentIds, setRecentIds] = useState([]);
  const [menuOpen, setMenuOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [showSplash, setShowSplash] = useState(true);
  const [confettiOn, setConfettiOn] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setShowSplash(false), 900);
    return () => clearTimeout(t);
  }, []);
  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPaletteOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);
  const [selectedCity, setSelectedCity] = useState("All cities");
  const [savedSearches, setSavedSearches] = useState([]);
  const [lang, setLang] = useState("en");
  const t = (key) => I18N[lang]?.[key] ?? I18N.fa[key] ?? key;
  const [currency, setCurrency] = useState("USD");
  const fmt = (usd) => convertPrice(usd, currency);
  const [themeMode, setThemeMode] = useState("light");
  const [showOnboarding, setShowOnboarding] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        await window.storage.get("onboarded", false);
      } catch (e) {
        setShowOnboarding(true);
      }
    })();
  }, []);
  const finishOnboarding = async () => {
    setShowOnboarding(false);
    try { await window.storage.set("onboarded", "1", false); } catch (e) {}
  };

  useEffect(() => {
    (async () => {
      try {
        const res = await window.storage.get("savedSearches", false);
        const parsed = JSON.parse(res.value);
        if (Array.isArray(parsed)) setSavedSearches(parsed);
      } catch (e) {}
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const res = await window.storage.get("wishlist", false);
        const parsed = JSON.parse(res.value);
        if (Array.isArray(parsed)) setWishlistIds(parsed);
      } catch (e) {}
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const res = await window.storage.get("recentlyViewed", false);
        const parsed = JSON.parse(res.value);
        if (Array.isArray(parsed)) setRecentIds(parsed);
      } catch (e) {}
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const res = await window.storage.get("listings", true);
        const parsed = JSON.parse(res.value);
        if (Array.isArray(parsed) && parsed.length) setListings(parsed);
      } catch (e) {
        try { await window.storage.set("listings", JSON.stringify(SEED_LISTINGS), true); } catch (e2) {}
      }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const res = await window.storage.get("user", false);
        const parsed = JSON.parse(res.value);
        if (parsed && parsed.name) setUser(parsed);
      } catch (e) {}
    })();
  }, []);

  useEffect(() => { window.scrollTo({ top: 0, behavior: "smooth" }); }, [view.name]);

  const persistListings = async (next) => {
    setListings(next);
    try { await window.storage.set("listings", JSON.stringify(next), true); } catch (e) {}
  };

  const publish = async (ad) => {
    const withExpiry = { ...ad, expiresAt: ad.expiresAt || (Date.now() + AD_EXPIRY_MS) };
    await persistListings([withExpiry, ...listings]);
  };

  const updateListing = async (adId, patch) => {
    const next = listings.map((l) => (l.id === adId ? { ...l, ...patch } : l));
    await persistListings(next);
  };

  const deleteListing = async (adId) => {
    const next = listings.filter((l) => l.id !== adId);
    await persistListings(next);
    showToast("Listing deleted");
  };

  const renewListing = async (adId) => {
    await updateListing(adId, { expiresAt: Date.now() + AD_EXPIRY_MS });
    showToast("Listing renewed");
  };

  const decideListing = async (adId, decision) => {
    const next = listings.map((l) => (l.id === adId ? { ...l, status: decision } : l));
    showToast(decision === "approved" ? "Listing approved and published" : "Listing rejected");
    await persistListings(next);
  };

  const updateUser = async (u) => {
    setUser(u);
    try {
      if (u) await window.storage.set("user", JSON.stringify(u), false);
      else await window.storage.delete("user", false);
    } catch (e) {}
  };
  const saveProfile = async (updated) => {
    await updateUser(updated);
    showToast("Profile updated");
  };

  const showToast = (t) => { setToast(t); setTimeout(() => setToast(""), 2600); };

  const toggleCompare = (ad) => {
    if (compareIds.includes(ad.id)) { setCompareIds(compareIds.filter((id) => id !== ad.id)); return; }
    if (compareIds.length > 0) {
      const firstAd = listings.find((l) => l.id === compareIds[0]);
      if (firstAd && firstAd.category !== ad.category) { showToast("Only listings in the same category can be compared"); return; }
    }
    if (compareIds.length >= 4) { showToast("You can compare up to 4 listings at once"); return; }
    setCompareIds([...compareIds, ad.id]);
  };

  const toggleWishlist = async (ad) => {
    const next = wishlistIds.includes(ad.id) ? wishlistIds.filter((id) => id !== ad.id) : [...wishlistIds, ad.id];
    setWishlistIds(next);
    showToast(wishlistIds.includes(ad.id) ? "Removed from wishlist" : "Added to wishlist");
    try { await window.storage.set("wishlist", JSON.stringify(next), false); } catch (e) {}
  };

  const trackView = async (adId) => {
    const next = [adId, ...recentIds.filter((id) => id !== adId)].slice(0, 12);
    setRecentIds(next);
    try { await window.storage.set("recentlyViewed", JSON.stringify(next), false); } catch (e) {}
  };
  useEffect(() => {
    if (view.name === "detail" && view.ad) trackView(view.ad.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view.name, view.ad?.id]);

  const recomputeMatches = (s) => {
    let arr = listings.filter((l) => l.category === s.categoryId && l.status === "approved");
    if (s.city && s.city !== "All") arr = arr.filter((l) => l.city === s.city);
    if (s.priceMax) arr = arr.filter((l) => l.price === 0 || l.price <= s.priceMax);
    return arr.length;
  };

  const saveSearch = async ({ categoryId, city, priceMax, matchCount, label }) => {
    const finalLabel = label || `${catOf(categoryId).label}${city !== "All" ? " · " + city : ""}`;
    const next = [...savedSearches, { id: "ss" + Date.now(), label: finalLabel, categoryId, city, priceMax, seenCount: matchCount, createdAt: Date.now() }];
    setSavedSearches(next);
    showToast("Search saved — We'll notify you when a matching new listing appears");
    try { await window.storage.set("savedSearches", JSON.stringify(next), false); } catch (e) {}
  };

  const removeSearch = async (id) => {
    const next = savedSearches.filter((s) => s.id !== id);
    setSavedSearches(next);
    try { await window.storage.set("savedSearches", JSON.stringify(next), false); } catch (e) {}
  };

  const markSearchSeen = async (id) => {
    const next = savedSearches.map((s) => (s.id === id ? { ...s, seenCount: recomputeMatches(s) } : s));
    setSavedSearches(next);
    try { await window.storage.set("savedSearches", JSON.stringify(next), false); } catch (e) {}
  };

  const newMatchesCount = savedSearches.filter((s) => recomputeMatches(s) > s.seenCount).length;

  const approvedListings = listings.filter((l) => l.status === "approved" && !isExpired(l));
  const pendingListings = listings.filter((l) => l.status === "pending");

  let body;
  if (view.name === "home") body = <Home listings={approvedListings} setView={setView} query={query} setQuery={setQuery} compareIds={compareIds} onToggleCompare={toggleCompare} wishlistIds={wishlistIds} onToggleWishlist={toggleWishlist} selectedCity={selectedCity} onSelectCity={setSelectedCity} recentIds={recentIds} />;
  else if (view.name === "category" && view.category) body = <CategoryView key={view.category} categoryId={view.category} listings={approvedListings} setView={setView} compareIds={compareIds} onToggleCompare={toggleCompare} wishlistIds={wishlistIds} onToggleWishlist={toggleWishlist} onSaveSearch={saveSearch} />;
  else if (view.name === "detail" && view.ad) body = <DetailView key={view.ad.id} ad={view.ad} listings={approvedListings} setView={setView} user={user} showToast={showToast} compareIds={compareIds} onToggleCompare={toggleCompare} wishlistIds={wishlistIds} onToggleWishlist={toggleWishlist} />;
  else if (view.name === "post") body = <PostAdView setView={setView} user={user} onPublish={publish} onUpdate={updateListing} editingAd={view.editingAd || null} listings={approvedListings} />;
  else if (view.name === "auth") body = <AuthView setUser={updateUser} setView={setView} />;
  else if (view.name === "support") body = <SupportView setView={setView} showToast={showToast} />;
  else if (view.name === "about") body = <AboutView setView={setView} listings={approvedListings} />;
  else if (view.name === "terms") body = <LegalView setView={setView} kind="terms" />;
  else if (view.name === "privacy") body = <LegalView setView={setView} kind="privacy" />;
  else if (view.name === "careers") body = <CareersView setView={setView} showToast={showToast} />;
  else if (view.name === "magazine") body = <MagazineView setView={setView} />;
  else if (view.name === "stats") body = <MarketStatsView listings={approvedListings} setView={setView} />;
  else if (view.name === "market") body = <MarketDataView setView={setView} />;
  else if (view.name === "article") body = <ArticleView articleId={view.articleId} setView={setView} />;
  else if (view.name === "compare") body = <CompareView compareIds={compareIds} listings={approvedListings} setView={setView} onToggleCompare={toggleCompare} />;
  else if (view.name === "wishlist") body = <WishlistView wishlistIds={wishlistIds} listings={approvedListings} setView={setView} compareIds={compareIds} onToggleCompare={toggleCompare} onToggleWishlist={toggleWishlist} />;
  else if (view.name === "saved-searches") body = <SavedSearchesView savedSearches={savedSearches} listings={approvedListings} setView={setView} recomputeMatches={recomputeMatches} onRemove={removeSearch} onOpen={markSearchSeen} />
  else if (view.name === "seller") body = <SellerView owner={view.owner} listings={approvedListings} setView={setView} compareIds={compareIds} onToggleCompare={toggleCompare} wishlistIds={wishlistIds} onToggleWishlist={toggleWishlist} />;
  else if (view.name === "admin" && isAdminUser(user)) body = <AdminView pendingListings={pendingListings} setView={setView} onDecide={decideListing} />;
  else if (view.name === "admin") body = (
    <div className="max-w-md mx-auto px-4 py-24 text-center">
      <p className="text-[#14181F] font-semibold mb-2">Access to this section is restricted.</p>
      <p className="text-sm text-[#585C66] mb-6">Only admins can see the admin panel.</p>
      <button onClick={() => setView({ name: "home" })} className="font-extrabold text-sm px-5 py-2.5 rounded-full" style={{ background: LIME, color: INK }}>Back home</button>
    </div>
  );
  else if (view.name === "dashboard" && user) body = <Dashboard user={user} setUser={updateUser} listings={listings} setView={setView} compareIds={compareIds} onToggleCompare={toggleCompare} wishlistIds={wishlistIds} onToggleWishlist={toggleWishlist} onSaveProfile={saveProfile} showToast={showToast} onDelete={deleteListing} onRenew={renewListing} />;
  else body = <NotFoundView setView={setView} />;

  return (
    <LangContext.Provider value={{ lang, setLang, t, currency, setCurrency, fmt }}>
    <div dir={lang === "fa" ? "rtl" : "ltr"} lang={lang} className={`min-h-screen flex flex-col ${themeMode === "dark" ? "theme-dark" : ""}`} style={{ background: PAGE_BG, fontFamily: lang === "fa" ? "Vazirmatn" : "Inter, Vazirmatn, sans-serif", color: INK }}>
      <style>{`
        ${FONT_IMPORT}
        * { box-sizing: border-box; }
        body { margin: 0; }
        ::selection { background: ${LIME}; color: ${INK}; }
        @keyframes fadeIn { from { opacity:0; transform: translate(-50%, 8px);} to {opacity:1; transform: translate(-50%,0);} }
        @keyframes popIn { from { opacity:0; transform: scale(.6);} to {opacity:1; transform: scale(1);} }
        @keyframes dirRow { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: translateY(0); } }
        .dual-range { position: absolute; inset-inline: 0; width: 100%; height: 6px; background: transparent; pointer-events: none; -webkit-appearance: none; appearance: none; margin: 0; }
        .dual-range::-webkit-slider-thumb { pointer-events: auto; -webkit-appearance: none; appearance: none; width: 16px; height: 16px; border-radius: 50%; background: #fff; border: 3px solid currentColor; cursor: pointer; box-shadow: 0 1px 4px rgba(0,0,0,.3); }
        .dual-range::-moz-range-thumb { pointer-events: auto; width: 16px; height: 16px; border-radius: 50%; background: #fff; border: 3px solid currentColor; cursor: pointer; box-shadow: 0 1px 4px rgba(0,0,0,.3); }
        .dual-range::-webkit-slider-runnable-track { background: transparent; }
        .dual-range::-moz-range-track { background: transparent; }
        .lot-corner { position: absolute; width: 14px; height: 14px; border-style: solid; border-width: 0; z-index: 5; pointer-events: none; transition: opacity .3s ease; }
        .lot-corner-tl { top: 6px; inset-inline-start: 6px; border-top-width: 2px; border-inline-start-width: 2px; }
        .lot-corner-tr { top: 6px; inset-inline-end: 6px; border-top-width: 2px; border-inline-end-width: 2px; }
        .lot-corner-bl { bottom: 6px; inset-inline-start: 6px; border-bottom-width: 2px; border-inline-start-width: 2px; }
        .lot-corner-br { bottom: 6px; inset-inline-end: 6px; border-bottom-width: 2px; border-inline-end-width: 2px; }
        @keyframes heartPop { 0% { transform: scale(1); } 35% { transform: scale(1.35); } 100% { transform: scale(1); } }
        .heart-pop { animation: heartPop .35s ease; }
        @keyframes skeletonShimmer { 0% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
        .skeleton-pulse { animation: skeletonShimmer 1.4s ease-in-out infinite; }
        .line-clamp-1 { display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden; }
        .line-clamp-2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
        input, select, textarea, button { font-family: 'Vazirmatn', sans-serif; }
        input::placeholder, textarea::placeholder { color: #585C66; }

        .ticker-wrap { overflow: hidden; }
        .ticker-track { display: flex; align-items: center; gap: 2rem; width: max-content; padding: 0.65rem 1rem; white-space: nowrap; animation: marquee 34s linear infinite; will-change: transform; }
        .ticker-wrap:hover .ticker-track { animation-play-state: paused; }
        @keyframes marquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }

        .type-cursor { display: inline-block; color: ${CYAN}; animation: blink 1s steps(1) infinite; margin-right: 2px; }
        @keyframes blink { 50% { opacity: 0; } }

        .activity-fade { animation: actFade .5s ease; }
        @keyframes actFade { from { opacity: 0; transform: translateY(6px);} to { opacity:1; transform: translateY(0);} }

        .orbit-outer { position: relative; margin: 0 auto; }
        .orbit-center { position: absolute; inset: 0; z-index: 2; display: flex; flex-direction: column; align-items: center; justify-content: center; }
        .orbit-ring { position: absolute; inset: 0; }
        .orbit-ring-outer { animation: orbitSpin 42s linear infinite; }
        .orbit-ring-inner { animation: orbitSpin 26s linear infinite reverse; }
        .orbit-item { position: absolute; top: 50%; left: 50%; width: 0; height: 0; }
        .orbit-counter-outer { animation: orbitCounter 42s linear infinite; }
        .orbit-counter-inner { animation: orbitCounter 26s linear infinite reverse; }
        .orbit-chip {
          position: absolute; top: 0; left: 0; width: 40px; height: 40px; margin: -20px 0 0 -20px;
          border-radius: 9999px; border: 1.5px solid; display: flex; align-items: center; justify-content: center; cursor: pointer;
        }
        .orbit-thumb {
          position: absolute; top: 0; left: 0; width: 52px; height: 52px; margin: -26px 0 0 -26px;
          border-radius: 9999px; overflow: hidden; border: 2px solid; background: #000; cursor: pointer; display: block; padding: 0;
        }
        .orbit-thumb img { width: 100%; height: 100%; object-fit: cover; }
        @keyframes orbitSpin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes orbitCounter { from { transform: rotate(0deg); } to { transform: rotate(-360deg); } }

        .masonry { column-count: 2; column-gap: 16px; }
        @media (min-width: 640px) { .masonry { column-count: 3; } }
        @media (min-width: 768px) { .masonry { column-count: 4; } }
        @media (min-width: 1024px) { .masonry { column-count: 5; } }
        .masonry-item { break-inside: avoid; margin-bottom: 16px; }

        @keyframes pageFadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes heroFloat { 0%, 100% { margin-top: 0px; } 50% { margin-top: -10px; } }
        .hero-float { animation: heroFloat 4.5s ease-in-out infinite; }
        @keyframes splashDot { 0%, 80%, 100% { transform: scale(0.6); opacity: 0.4; } 40% { transform: scale(1); opacity: 1; } }
        .page-transition { animation: pageFadeIn .32s cubic-bezier(.22,1,.36,1); }
        @media (prefers-reduced-motion: reduce) {
          .page-transition { animation: none; }
          .hero-float { animation: none; }
          .ticker-track, .orbit-ring-outer, .orbit-ring-inner, .orbit-counter-outer, .orbit-counter-inner, .type-cursor { animation: none; }
        }

        .print-cert { display: none; }
        @media print {
          .no-print { display: none !important; }
          body, .theme-dark { background: #fff !important; filter: none !important; }
          .print-cert { display: block !important; }
        }

        a:focus-visible, button:focus-visible, input:focus-visible, select:focus-visible, textarea:focus-visible, [tabindex]:focus-visible {
          outline: 2px solid ${LIME};
          outline-offset: 2px;
          border-radius: 4px;
        }

        /* Dark mode: whole-page color inversion, with photos/maps/canvas re-inverted back to normal */
        .theme-dark { filter: invert(1) hue-rotate(180deg); background: ${PAGE_BG}; }
        .theme-dark img, .theme-dark iframe, .theme-dark canvas { filter: invert(1) hue-rotate(180deg); }
      `}</style>

      <div className="no-print">
        <Header setView={setView} user={user} query={query} setQuery={setQuery} wishlistCount={wishlistIds.length} menuOpen={menuOpen} onMenuClick={() => setMenuOpen((v) => !v)} newMatchesCount={newMatchesCount} themeMode={themeMode} onToggleTheme={() => setThemeMode((v) => (v === "light" ? "dark" : "light"))} savedSearches={savedSearches} recomputeMatches={recomputeMatches} onOpenSearch={markSearchSeen} listings={approvedListings} onOpenPalette={() => setPaletteOpen(true)} />
        <Ticker listings={approvedListings} setView={setView} />
      </div>
      <main className="flex-1 pb-16 sm:pb-0">
        <div key={view.name + (view.category || "") + (view.ad?.id || "") + (view.owner || "")} className="page-transition">{body}</div>
      </main>
      <div className="no-print">
        <Footer setView={setView} />
        <Toast text={toast} />
        <CompareBar compareIds={compareIds} listings={listings} setView={setView} clear={() => setCompareIds([])} />
        <FloatingButtons setView={setView} />
        <BottomNav view={view} setView={setView} user={user} wishlistCount={wishlistIds.length} onMenuClick={() => setMenuOpen(true)} />
        <SideDrawer open={menuOpen} onClose={() => setMenuOpen(false)} setView={setView} user={user} selectedCity={selectedCity} onSelectCity={setSelectedCity} />
        {showOnboarding && <OnboardingTour onClose={finishOnboarding} />}
        <PwaInstallBanner />
        <CookieConsentBanner setView={setView} />
        <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} setView={setView} user={user} themeMode={themeMode} onToggleTheme={() => setThemeMode((v) => (v === "light" ? "dark" : "light"))} lang={lang} setLang={setLang} />
      </div>
      <SplashScreen visible={showSplash} />
      {confettiOn && <Confetti onDone={() => setConfettiOn(false)} />}
    </div>
    </LangContext.Provider>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AppInner />
    </ErrorBoundary>
  );
}
